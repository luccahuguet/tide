use std::fs::{self, OpenOptions};
use std::io::{self, Write};
use std::path::{Path, PathBuf};

pub struct RotLog {
    dir: PathBuf,
    max_bytes: u64,
    size: u64,
}

impl RotLog {
    pub fn open(dir: &Path, max_bytes: u64) -> io::Result<RotLog> {
        fs::create_dir_all(dir)?;
        let size = match fs::metadata(dir.join("current.log")) {
            Ok(m) => m.len(),
            Err(e) if e.kind() == io::ErrorKind::NotFound => 0,
            Err(e) => return Err(e),
        };
        Ok(RotLog { dir: dir.to_path_buf(), max_bytes, size })
    }

    pub fn append(&mut self, line: &str) -> io::Result<()> {
        if line.contains('\n') {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "line contains newline",
            ));
        }
        let len = line.len() as u64 + 1;
        let cur = self.dir.join("current.log");
        if self.size > 0 && self.size + len > self.max_bytes {
            let old1 = self.dir.join("old.1.log");
            let old2 = self.dir.join("old.2.log");
            if old1.exists() {
                fs::rename(&old1, &old2)?;
            }
            fs::rename(&cur, &old1)?;
            self.size = 0;
        }
        let mut f = OpenOptions::new().create(true).append(true).open(&cur)?;
        let mut buf = Vec::with_capacity(len as usize);
        buf.extend_from_slice(line.as_bytes());
        buf.push(b'\n');
        f.write_all(&buf)?;
        self.size += len;
        Ok(())
    }
}

pub fn read_all(dir: &Path) -> io::Result<Vec<String>> {
    let mut out = Vec::new();
    for name in ["old.2.log", "old.1.log", "current.log"] {
        match fs::read_to_string(dir.join(name)) {
            Ok(s) => out.extend(s.lines().map(String::from)),
            Err(e) if e.kind() == io::ErrorKind::NotFound => {}
            Err(e) => return Err(e),
        }
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tmp(name: &str) -> PathBuf {
        let d = std::env::temp_dir().join(format!("rotlog_test_{}_{}", name, std::process::id()));
        let _ = fs::remove_dir_all(&d);
        fs::create_dir_all(&d).unwrap();
        d
    }

    fn rd(d: &Path, n: &str) -> String {
        fs::read_to_string(d.join(n)).unwrap()
    }

    #[test]
    fn cases_1_2() {
        let d = tmp("c12");
        let mut l = RotLog::open(&d, 10).unwrap();
        for s in ["aaaa", "bbbb", "cc"] {
            l.append(s).unwrap();
        }
        assert_eq!(rd(&d, "old.1.log"), "aaaa\nbbbb\n");
        assert_eq!(rd(&d, "current.log"), "cc\n");
        assert_eq!(read_all(&d).unwrap(), ["aaaa", "bbbb", "cc"]);
        l.append("dddddddd").unwrap();
        l.append("e").unwrap();
        assert_eq!(read_all(&d).unwrap(), ["cc", "dddddddd", "e"]);
    }

    #[test]
    fn case_3() {
        let d = tmp("c3");
        let mut l = RotLog::open(&d, 10).unwrap();
        l.append("x").unwrap();
        let e = l.append("a\nb").unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::InvalidInput);
        assert_eq!(rd(&d, "current.log"), "x\n");
        assert!(!d.join("old.1.log").exists());
    }

    #[test]
    fn case_4() {
        let d = tmp("c4");
        let mut l = RotLog::open(&d, 10).unwrap();
        let big = "z".repeat(20);
        l.append(&big).unwrap();
        assert_eq!(rd(&d, "current.log"), format!("{big}\n"));
        l.append("a").unwrap();
        assert_eq!(rd(&d, "old.1.log"), format!("{big}\n"));
        assert_eq!(rd(&d, "current.log"), "a\n");
    }

    #[test]
    fn case_5() {
        let d = tmp("c5");
        {
            let mut l = RotLog::open(&d, 10).unwrap();
            l.append("a").unwrap();
        }
        let mut l = RotLog::open(&d, 10).unwrap();
        l.append("b").unwrap();
        assert_eq!(rd(&d, "current.log"), "a\nb\n");
    }
}
