use std::collections::HashMap;

fn key_of(word: &str) -> Vec<u8> {
    let mut k: Vec<u8> = word.bytes().map(|b| b.to_ascii_lowercase()).collect();
    k.sort_unstable();
    k
}

/// An index of the anagram classes in one text.
pub struct AnagramIndex<'a> {
    /// Classes in order of first occurrence of their first word; each lists
    /// distinct words in order of first occurrence.
    classes: Vec<Vec<&'a str>>,
    by_key: HashMap<Vec<u8>, usize>,
}

impl<'a> AnagramIndex<'a> {
    pub fn new(text: &'a str) -> Self {
        let mut classes: Vec<Vec<&'a str>> = Vec::new();
        let mut by_key: HashMap<Vec<u8>, usize> = HashMap::new();
        let bytes = text.as_bytes();
        let mut i = 0;
        while i < bytes.len() {
            if bytes[i].is_ascii_alphabetic() {
                let start = i;
                while i < bytes.len() && bytes[i].is_ascii_alphabetic() {
                    i += 1;
                }
                let w = &text[start..i];
                let k = key_of(w);
                match by_key.get(&k) {
                    Some(&idx) => {
                        if !classes[idx].contains(&w) {
                            classes[idx].push(w);
                        }
                    }
                    None => {
                        by_key.insert(k, classes.len());
                        classes.push(vec![w]);
                    }
                }
            } else {
                i += 1;
            }
        }
        AnagramIndex { classes, by_key }
    }

    pub fn groups(&self) -> Vec<Vec<&'a str>> {
        self.classes
            .iter()
            .filter(|c| c.len() >= 2)
            .cloned()
            .collect()
    }

    pub fn partners(&self, word: &str) -> Vec<&'a str> {
        match self.by_key.get(&key_of(word)) {
            Some(&idx) => self.classes[idx]
                .iter()
                .copied()
                .filter(|w| *w != word)
                .collect(),
            None => Vec::new(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn case1() {
        let idx = AnagramIndex::new("listen silent enlist google tinsel");
        assert_eq!(
            idx.groups(),
            vec![vec!["listen", "silent", "enlist", "tinsel"]]
        );
    }

    #[test]
    fn case2() {
        let idx = AnagramIndex::new("Dusty study, night thing; dusty");
        assert_eq!(
            idx.groups(),
            vec![vec!["Dusty", "study", "dusty"], vec!["night", "thing"]]
        );
    }

    #[test]
    fn case3() {
        assert!(AnagramIndex::new("").groups().is_empty());
        assert!(AnagramIndex::new("abc def").groups().is_empty());
    }

    #[test]
    fn case4_and_5() {
        let text = String::from("listen silent enlist google tinsel");
        let g;
        let p;
        {
            let idx = AnagramIndex::new(&text);
            g = idx.groups();
            {
                let w = String::from("listen");
                p = idx.partners(&w);
            }
        }
        assert_eq!(g, vec![vec!["listen", "silent", "enlist", "tinsel"]]);
        assert_eq!(p, vec!["silent", "enlist", "tinsel"]);
        let r = text.as_bytes().as_ptr_range();
        assert!(r.contains(&p[0].as_ptr()));
    }

    #[test]
    fn partners_none() {
        let idx = AnagramIndex::new("abc");
        assert!(idx.partners("abc").is_empty());
        assert!(idx.partners("xyz").is_empty());
        assert_eq!(idx.partners("CBA"), vec!["abc"]);
    }
}
