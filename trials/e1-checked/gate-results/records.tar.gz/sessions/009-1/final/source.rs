use std::thread;
use std::time::{Duration, Instant};

#[derive(Debug, Clone, PartialEq)]
pub struct Report {
    pub calls: u32,
    pub last_ok: Option<u32>,
    pub elapsed: Duration,
}

pub fn watch(interval: Duration, misses: u32, mut probe: impl FnMut() -> bool) -> Report {
    assert!(misses > 0, "misses must be at least 1");
    let start = Instant::now();
    let mut calls: u32 = 0;
    let mut last_ok = None;
    let mut consecutive = 0u32;
    let mut tick: u128 = 0;
    loop {
        let call_at = start.elapsed();
        let ok = probe();
        let idx = calls;
        calls += 1;
        if ok {
            last_ok = Some(idx);
            consecutive = 0;
        } else {
            consecutive += 1;
            if consecutive >= misses {
                return Report { calls, last_ok, elapsed: call_at };
            }
        }
        let iv = interval.as_nanos();
        if iv == 0 {
            continue;
        }
        let now = start.elapsed().as_nanos();
        let ceil = now.div_ceil(iv);
        tick = (tick + 1).max(ceil);
        let target = start + nanos(tick * iv);
        let now_i = Instant::now();
        if target > now_i {
            thread::sleep(target - now_i);
        }
    }
}

fn nanos(n: u128) -> Duration {
    Duration::new((n / 1_000_000_000) as u64, (n % 1_000_000_000) as u32)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn within(d: Duration, ms: u64) {
        let lo = Duration::from_millis(ms);
        assert!(d >= lo && d < lo + Duration::from_millis(150), "{d:?} vs {ms}");
    }

    #[test]
    fn case1() {
        let seq = [true, true, false, true, false, false];
        let mut i = 0;
        let r = watch(Duration::from_millis(100), 2, || {
            let v = seq[i];
            i += 1;
            v
        });
        assert_eq!(r.calls, 6);
        assert_eq!(r.last_ok, Some(3));
        within(r.elapsed, 500);
    }

    #[test]
    fn case2() {
        let mut first = true;
        let r = watch(Duration::from_millis(100), 1, || {
            if first {
                first = false;
                thread::sleep(Duration::from_millis(250));
                true
            } else {
                false
            }
        });
        assert_eq!(r.calls, 2);
        assert_eq!(r.last_ok, Some(0));
        within(r.elapsed, 300);
    }

    #[test]
    fn case3() {
        let r = watch(Duration::from_millis(100), 1, || false);
        assert_eq!(r.calls, 1);
        assert_eq!(r.last_ok, None);
        within(r.elapsed, 0);
    }

    #[test]
    #[should_panic]
    fn case4() {
        watch(Duration::from_millis(100), 0, || true);
    }
}
