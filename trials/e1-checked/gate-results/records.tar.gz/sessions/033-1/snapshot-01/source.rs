use std::io::{self, BufRead, BufReader, Write};
use std::net::{Net, TcpListener, TcpStream};
use std::task::{TaskError, Tasks};

#[derive(Debug, Error)]
enum SrvError {
    #[error("{0}")]
    Io(#[from] io::Error),
    #[error("{0}")]
    Task(#[from] TaskError),
}

impl From<SrvError> for io::Error {
    fn from(e: SrvError) -> io::Error {
        match e {
            SrvError::Io(e) => e,
            SrvError::Task(t) => io::Error::other(t),
        }
    }
}

fn reverse_line(line: &str) -> String {
    line.chars().rev().collect()
}

/// Handles one connection; returns the number of lines answered.
fn handle(stream: TcpStream) -> io::Result<u64> {
    let mut reader = BufReader::new(&stream);
    let mut writer = &stream;
    let mut answered: u64 = 0;
    let mut buf = String::new();
    loop {
        buf.clear();
        let n = reader.read_line(&mut buf)?;
        if n == 0 {
            break;
        }
        let Some(line) = buf.strip_suffix('\n') else {
            // Unterminated final fragment: end of input.
            break;
        };
        if line == "QUIT" {
            break;
        }
        let mut reply = reverse_line(line);
        reply.push('\n');
        writer.write_all(reply.as_bytes())?;
        writer.flush()?;
        answered += 1;
    }
    Ok(answered)
}

/// Accepts exactly `clients` connections, handles them concurrently, and
/// returns the total number of lines answered.
pub fn serve(tasks: &Tasks, listener: &TcpListener, clients: usize) -> io::Result<u64> {
    let total = tasks.scope(|s| -> Result<u64, SrvError> {
        let mut handles = Vec::with_capacity(clients);
        for _ in 0..clients {
            let (stream, _) = listener.accept()?;
            handles.push(s.spawn(move || Ok(handle(stream)?)));
        }
        let mut total: u64 = 0;
        for h in handles {
            total += h.join()?;
        }
        Ok(total)
    })?;
    Ok(total)
}

/// Connects to `addr`, sends each line and reads its reply, then sends `QUIT`.
pub fn exchange(net: &Net, addr: &str, lines: &[&str]) -> io::Result<Vec<String>> {
    let stream = net.connect(addr)?;
    let mut reader = BufReader::new(&stream);
    let mut writer = &stream;
    let mut replies = Vec::with_capacity(lines.len());
    for line in lines {
        let mut msg = String::with_capacity(line.len() + 1);
        msg.push_str(line);
        msg.push('\n');
        writer.write_all(msg.as_bytes())?;
        writer.flush()?;
        let mut buf = String::new();
        let n = reader.read_line(&mut buf)?;
        if n == 0 {
            return Err(io::Error::new(
                io::ErrorKind::UnexpectedEof,
                "connection closed before reply",
            ));
        }
        let reply = buf.strip_suffix('\n').unwrap_or(&buf).to_string();
        replies.push(reply);
    }
    writer.write_all(b"QUIT\n")?;
    writer.flush()?;
    Ok(replies)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    #[test]
    fn reverses() {
        assert_eq!(reverse_line("héllo"), "olléh");
        assert_eq!(reverse_line(""), "");
    }

    #[sim_test(seeds = 20)]
    fn three_clients(sim: SimRoot) {
        let listener = sim.net.bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let tasks = &sim.tasks;
        let net = &sim.net;
        let a: &str = &addr;
        let l = &listener;
        let (n, r1, r2, r3) = tasks
            .scope(|s| -> Result<_, SrvError> {
                let srv = s.spawn(move || Ok(serve(tasks, l, 3)?));
                let c1 = s.spawn(move || Ok(exchange(net, a, &["abc", "héllo"])?));
                let c2 = s.spawn(move || Ok(exchange(net, a, &["x"])?));
                let c3 = s.spawn(move || Ok(exchange(net, a, &[])?));
                Ok((srv.join()?, c1.join()?, c2.join()?, c3.join()?))
            })
            .unwrap();
        assert_eq!(r1, vec!["cba".to_string(), "olléh".to_string()]);
        assert_eq!(r2, vec!["x".to_string()]);
        assert!(r3.is_empty());
        assert_eq!(n, 3);
    }

    #[sim_test(seeds = 20)]
    fn concurrent_connections(sim: SimRoot) {
        let listener = sim.net.bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let tasks = &sim.tasks;
        let net = &sim.net;
        let a: &str = &addr;
        let l = &listener;
        let done = sync_flag(tasks);
        let (tx, rx) = done;
        let (n, first, second) = tasks
            .scope(|s| -> Result<_, SrvError> {
                let srv = s.spawn(move || Ok(serve(tasks, l, 2)?));
                let c1 = s.spawn(move || {
                    let stream = net.connect(a)?;
                    let mut w = &stream;
                    w.write_all(b"hi\n")?;
                    let mut r = BufReader::new(&stream);
                    let mut buf = String::new();
                    r.read_line(&mut buf)?;
                    // Hold the connection until the second exchange returns.
                    let _ = rx.recv();
                    w.write_all(b"QUIT\n")?;
                    Ok(buf)
                });
                let c2 = s.spawn(move || {
                    let got = exchange(net, a, &["ab"])?;
                    let _ = tx.send(());
                    Ok(got)
                });
                Ok((srv.join()?, c1.join()?, c2.join()?))
            })
            .unwrap();
        assert_eq!(first, "ih\n");
        assert_eq!(second, vec!["ba".to_string()]);
        assert_eq!(n, 2);
    }

    fn sync_flag(
        tasks: &Tasks,
    ) -> (std::sync::mpsc::SyncSender<()>, std::sync::mpsc::Receiver<()>) {
        std::sync::mpsc::sync_channel(1, tasks)
    }
}
