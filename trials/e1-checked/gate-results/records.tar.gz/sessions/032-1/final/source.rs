use std::cmp::Reverse;
use std::collections::BinaryHeap;
use std::sync::mpsc::{sync_channel, Receiver, SyncSender};
use std::task::{TaskError, Tasks};

#[derive(Debug, PartialEq, Eq, Clone, Copy)]
pub enum MergeError {
    Unsorted { input: usize, index: usize },
}

enum Msg {
    Item(i64),
    Unsorted(usize),
}

/// Sends `items` in order; stops at the first item smaller than its predecessor.
fn produce(items: &[i64], tx: SyncSender<Msg>) {
    let mut prev: Option<i64> = None;
    for (i, &x) in items.iter().enumerate() {
        if let Some(p) = prev {
            if x < p {
                let _ = tx.send(Msg::Unsorted(i));
                return;
            }
        }
        if tx.send(Msg::Item(x)).is_err() {
            return;
        }
        prev = Some(x);
    }
}

fn record(errs: &mut Option<MergeError>, input: usize, index: usize) {
    let better = match errs {
        None => true,
        Some(MergeError::Unsorted { input: cur, .. }) => input < *cur,
    };
    if better {
        *errs = Some(MergeError::Unsorted { input, index });
    }
}

/// Receives the next item of input `i`, marking it done at its end or error.
fn pull(
    rxs: &[Receiver<Msg>],
    done: &mut [bool],
    err: &mut Option<MergeError>,
    i: usize,
) -> Option<i64> {
    if done[i] {
        return None;
    }
    match rxs[i].recv() {
        Ok(Msg::Item(x)) => Some(x),
        Ok(Msg::Unsorted(index)) => {
            done[i] = true;
            record(err, i, index);
            None
        }
        Err(_) => {
            done[i] = true;
            None
        }
    }
}

fn merge(rxs: &[Receiver<Msg>]) -> Result<Vec<i64>, MergeError> {
    let n = rxs.len();
    let mut done = vec![false; n];
    let mut err: Option<MergeError> = None;
    let mut heap: BinaryHeap<Reverse<(i64, usize)>> = BinaryHeap::new();
    let mut out = Vec::new();
    for i in 0..n {
        if let Some(x) = pull(rxs, &mut done, &mut err, i) {
            heap.push(Reverse((x, i)));
        }
    }
    while err.is_none() {
        let Some(Reverse((x, i))) = heap.pop() else {
            break;
        };
        out.push(x);
        if let Some(y) = pull(rxs, &mut done, &mut err, i) {
            heap.push(Reverse((y, i)));
        }
    }
    if err.is_some() {
        // Drain every remaining stream so all producers finish and every
        // unsorted input is seen; the smallest input index wins.
        for i in 0..n {
            while !done[i] {
                let _ = pull(rxs, &mut done, &mut err, i);
            }
        }
    }
    match err {
        Some(e) => Err(e),
        None => Ok(out),
    }
}

pub fn merge_streams(
    tasks: &Tasks,
    inputs: &[Vec<i64>],
    capacity: usize,
) -> Result<Vec<i64>, MergeError> {
    assert!(capacity > 0, "capacity must be positive");
    let result = tasks.scope(|s| {
        let mut rxs: Vec<Receiver<Msg>> = Vec::new();
        for input in inputs.iter() {
            let (tx, rx) = sync_channel::<Msg>(capacity, tasks);
            rxs.push(rx);
            let items: &[i64] = input;
            let _ = s.spawn(move || {
                produce(items, tx);
                Ok(())
            });
        }
        let merged = merge(&rxs);
        Ok::<_, TaskError>(merged)
    });
    match result {
        Ok(r) => r,
        Err(e) => panic!("merge scope failed: {e:?}"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn basic_cases() {
        for seed in 0..20u64 {
            let sim = Root::sim(seed);
            let inputs = vec![vec![1, 4, 9], vec![2, 3, 10], vec![], vec![5]];
            assert_eq!(
                merge_streams(&sim.tasks, &inputs, 1),
                Ok(vec![1, 2, 3, 4, 5, 9, 10])
            );
            assert_eq!(merge_streams(&sim.tasks, &[], 1), Ok(vec![]));
            let dups = vec![vec![1, 1, 2], vec![1, 2, 2]];
            assert_eq!(
                merge_streams(&sim.tasks, &dups, 3),
                Ok(vec![1, 1, 1, 2, 2, 2])
            );
        }
    }

    #[test]
    fn many_inputs() {
        for seed in 0..5u64 {
            let sim = Root::sim(seed);
            let mut inputs = Vec::new();
            for k in 0..8i64 {
                let v: Vec<i64> = (0..600i64).map(|j| j * (k + 1) - k * 50).collect();
                inputs.push(v);
            }
            let mut expect: Vec<i64> = inputs.iter().flatten().copied().collect();
            expect.sort();
            assert_eq!(merge_streams(&sim.tasks, &inputs, 2), Ok(expect));
        }
    }

    #[test]
    fn unsorted() {
        for seed in 0..20u64 {
            let sim = Root::sim(seed);
            let inputs = vec![vec![1, 2], vec![3, 1], vec![5, 0]];
            assert_eq!(
                merge_streams(&sim.tasks, &inputs, 1),
                Err(MergeError::Unsorted { input: 1, index: 1 })
            );
            let inputs = vec![vec![0, 1, 2, 3, 4, 5, 6], vec![9], vec![10, 11, 12, 13, 7]];
            assert_eq!(
                merge_streams(&sim.tasks, &inputs, 2),
                Err(MergeError::Unsorted { input: 2, index: 4 })
            );
        }
    }

    #[test]
    #[should_panic]
    fn zero_capacity() {
        let sim = Root::sim(1);
        let _ = merge_streams(&sim.tasks, &[vec![1]], 0);
    }
}
