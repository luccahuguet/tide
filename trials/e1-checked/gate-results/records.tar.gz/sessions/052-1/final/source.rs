use std::collections::HashMap;

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum TemplateError {
    #[error("unclosed placeholder at {pos}")]
    Unclosed { pos: usize },
    #[error("bad placeholder name at {pos}")]
    BadName { pos: usize },
    #[error("stray '}}' at {pos}")]
    StrayBrace { pos: usize },
    #[error("missing value for {name}")]
    Missing { name: String },
}

#[derive(Debug, Clone, PartialEq)]
enum Part<'a> {
    Lit(String),
    Var(&'a str),
}

#[derive(Debug, Clone, PartialEq)]
pub struct Template<'a> {
    parts: Vec<Part<'a>>,
}

fn is_name(s: &str) -> bool {
    let b = s.as_bytes();
    if b.is_empty() {
        return false;
    }
    let first = b[0];
    if !(first.is_ascii_alphabetic() || first == b'_') {
        return false;
    }
    b[1..].iter().all(|c| c.is_ascii_alphanumeric() || *c == b'_')
}

impl<'a> Template<'a> {
    pub fn parse(src: &'a str) -> Result<Template<'a>, TemplateError> {
        let b = src.as_bytes();
        let mut parts: Vec<Part<'a>> = Vec::new();
        let mut lit = String::new();
        let mut lit_start = 0usize;
        let mut i = 0usize;
        while i < b.len() {
            match b[i] {
                b'{' => {
                    lit.push_str(&src[lit_start..i]);
                    if i + 1 < b.len() && b[i + 1] == b'{' {
                        lit.push('{');
                        i += 2;
                    } else {
                        let close = match src[i + 1..].find('}') {
                            Some(off) => i + 1 + off,
                            None => return Err(TemplateError::Unclosed { pos: i }),
                        };
                        let name = &src[i + 1..close];
                        if !is_name(name) {
                            return Err(TemplateError::BadName { pos: i });
                        }
                        if !lit.is_empty() {
                            parts.push(Part::Lit(std::mem::take(&mut lit)));
                        }
                        parts.push(Part::Var(name));
                        i = close + 1;
                    }
                    lit_start = i;
                }
                b'}' => {
                    lit.push_str(&src[lit_start..i]);
                    if i + 1 < b.len() && b[i + 1] == b'}' {
                        lit.push('}');
                        i += 2;
                    } else {
                        return Err(TemplateError::StrayBrace { pos: i });
                    }
                    lit_start = i;
                }
                _ => i += 1,
            }
        }
        lit.push_str(&src[lit_start..]);
        if !lit.is_empty() {
            parts.push(Part::Lit(lit));
        }
        Ok(Template { parts })
    }

    pub fn names(&self) -> Vec<&'a str> {
        let mut out: Vec<&'a str> = Vec::new();
        for p in &self.parts {
            if let Part::Var(n) = p {
                if !out.contains(n) {
                    out.push(n);
                }
            }
        }
        out
    }

    pub fn render(&self, vars: &HashMap<&str, &str>) -> Result<String, TemplateError> {
        let mut out = String::new();
        for p in &self.parts {
            match p {
                Part::Lit(s) => out.push_str(s),
                Part::Var(n) => match vars.get(n) {
                    Some(v) => out.push_str(v),
                    None => {
                        return Err(TemplateError::Missing { name: n.to_string() });
                    }
                },
            }
        }
        Ok(out)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn vars<'a>(kv: &[(&'a str, &'a str)]) -> HashMap<&'a str, &'a str> {
        kv.iter().cloned().collect()
    }

    #[test]
    fn case1() {
        let t = Template::parse("Hi {name}, {{ok}} {name}!").unwrap();
        assert_eq!(t.names(), vec!["name"]);
        assert_eq!(t.render(&vars(&[("name", "Ann")])).unwrap(), "Hi Ann, {ok} Ann!");
    }

    #[test]
    fn case2() {
        let t = Template::parse("{{{x}}}").unwrap();
        assert_eq!(t.render(&vars(&[("x", "1")])).unwrap(), "{1}");
        let t = Template::parse("}}").unwrap();
        assert_eq!(t.render(&HashMap::new()).unwrap(), "}");
    }

    #[test]
    fn case3() {
        let t = Template::parse("{a}{b}").unwrap();
        let e = t.render(&vars(&[("a", "x")])).unwrap_err();
        assert_eq!(e, TemplateError::Missing { name: "b".to_string() });
        assert_eq!(e.to_string(), "missing value for b");
    }

    #[test]
    fn case4() {
        assert_eq!(Template::parse("x {y"), Err(TemplateError::Unclosed { pos: 2 }));
        assert_eq!(Template::parse("{1x}"), Err(TemplateError::BadName { pos: 0 }));
        assert_eq!(Template::parse("{}"), Err(TemplateError::BadName { pos: 0 }));
        assert_eq!(Template::parse("{ a }"), Err(TemplateError::BadName { pos: 0 }));
        assert_eq!(Template::parse("a } b"), Err(TemplateError::StrayBrace { pos: 2 }));
        assert_eq!(TemplateError::StrayBrace { pos: 2 }.to_string(), "stray '}' at 2");
        assert_eq!(TemplateError::Unclosed { pos: 2 }.to_string(), "unclosed placeholder at 2");
        assert_eq!(TemplateError::BadName { pos: 0 }.to_string(), "bad placeholder name at 0");
    }

    #[test]
    fn case5() {
        let src = String::from("{b} {a} {b}");
        let names;
        {
            let t = Template::parse(&src).unwrap();
            names = t.names();
        }
        assert_eq!(names, vec!["b", "a"]);
    }
}
