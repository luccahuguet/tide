//! A histogram computed in parallel.

const CHUNK: usize = 4096;

fn count_chunk(chunk: &[u32], edges: &[u32]) -> Vec<u64> {
    let buckets = edges.len() - 1;
    let mut counts = vec![0u64; buckets];
    for &v in chunk {
        // number of edges <= v
        let p = edges.partition_point(|&e| e <= v);
        if p >= 1 && p <= buckets {
            counts[p - 1] += 1;
        }
    }
    counts
}

/// Bucket `i` counts values `v` with `edges[i] <= v < edges[i + 1]`.
/// Panics if `edges` has fewer than two entries or does not increase strictly.
pub fn histogram(values: &[u32], edges: &[u32]) -> Vec<u64> {
    assert!(edges.len() >= 2, "edges must have at least two entries");
    assert!(
        edges.windows(2).all(|w| w[0] < w[1]),
        "edges must increase strictly"
    );
    let chunks: Vec<&[u32]> = values.chunks(CHUNK).collect();
    let partials: Vec<Vec<u64>> = chunks.par_map(|c| count_chunk(c, edges));
    let mut total = vec![0u64; edges.len() - 1];
    for part in &partials {
        for (t, p) in total.iter_mut().zip(part.iter()) {
            *t += *p;
        }
    }
    total
}

#[cfg(test)]
mod tests {
    use super::*;

    fn xorshift(state: &mut u64) -> u64 {
        let mut x = *state;
        x ^= x.wrapping_shl(13);
        x ^= x.wrapping_shr(7);
        x ^= x.wrapping_shl(17);
        *state = x;
        x
    }

    fn sequential(values: &[u32], edges: &[u32]) -> Vec<u64> {
        let mut out = vec![0u64; edges.len() - 1];
        for &v in values {
            for i in 0..edges.len() - 1 {
                if edges[i] <= v && v < edges[i + 1] {
                    out[i] += 1;
                }
            }
        }
        out
    }

    #[test]
    fn basic() {
        assert_eq!(histogram(&[0, 1, 5, 9, 10, 99], &[0, 5, 10]), vec![2, 2]);
    }

    #[test]
    fn large_matches_sequential() {
        let mut s: u64 = 0x9E37_79B9_7F4A_7C15;
        let values: Vec<u32> = (0..1_000_000)
            .map(|_| {
                let x: u32 = xorshift(&mut s).truncate();
                x
            })
            .collect();
        let mut edges: Vec<u32> = Vec::new();
        while edges.len() < 17 {
            let e: u32 = xorshift(&mut s).truncate();
            if !edges.contains(&e) {
                edges.push(e);
            }
        }
        edges.sort();
        assert_eq!(histogram(&values, &edges), sequential(&values, &edges));
        let small = [3u32, 1000, 1_000_000, 4_000_000_000];
        assert_eq!(histogram(&values, &small), sequential(&values, &small));
    }

    #[test]
    fn empty_values() {
        assert_eq!(histogram(&[], &[1, 2, 3]), vec![0, 0]);
    }

    #[test]
    #[should_panic]
    fn equal_edges_panic() {
        let _ = histogram(&[1], &[5, 5]);
    }

    #[test]
    #[should_panic]
    fn single_edge_panic() {
        let _ = histogram(&[1], &[5]);
    }
}
