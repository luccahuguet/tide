use std::collections::HashMap;

/// An index of the anagram classes in one text.
pub struct AnagramIndex<'a> {
    /// Classes in order of first occurrence of their first word; each holds
    /// distinct words in order of first occurrence.
    classes: Vec<Vec<&'a str>>,
    by_key: HashMap<Vec<u8>, usize>,
}

fn key(word: &str) -> Vec<u8> {
    let mut k: Vec<u8> = word.bytes().map(|b| b.to_ascii_lowercase()).collect();
    k.sort_unstable();
    k
}

impl<'a> AnagramIndex<'a> {
    pub fn new(text: &'a str) -> Self {
        let mut classes: Vec<Vec<&'a str>> = Vec::new();
        let mut by_key: HashMap<Vec<u8>, usize> = HashMap::new();
        let bytes = text.as_bytes();
        let mut i = 0;
        while i < bytes.len() {
            if !bytes[i].is_ascii_alphabetic() {
                i += 1;
                continue;
            }
            let start = i;
            while i < bytes.len() && bytes[i].is_ascii_alphabetic() {
                i += 1;
            }
            let w = &text[start..i];
            let k = key(w);
            let idx = *by_key.entry(k).or_insert_with(|| {
                classes.push(Vec::new());
                classes.len() - 1
            });
            if !classes[idx].contains(&w) {
                classes[idx].push(w);
            }
        }
        AnagramIndex { classes, by_key }
    }

    pub fn groups(&self) -> Vec<Vec<&'a str>> {
        self.classes
            .iter()
            .filter(|c| c.len() >= 2)
            .cloned()
            .collect()
    }

    pub fn partners(&self, word: &str) -> Vec<&'a str> {
        if word.is_empty() || !word.bytes().all(|b| b.is_ascii_alphabetic()) {
            return Vec::new();
        }
        match self.by_key.get(&key(word)) {
            Some(&idx) => self.classes[idx]
                .iter()
                .copied()
                .filter(|w| *w != word)
                .collect(),
            None => Vec::new(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn case1() {
        let idx = AnagramIndex::new("listen silent enlist google tinsel");
        assert_eq!(idx.groups(), vec![vec!["listen", "silent", "enlist", "tinsel"]]);
    }

    #[test]
    fn case2() {
        let idx = AnagramIndex::new("Dusty study, night thing; dusty");
        assert_eq!(
            idx.groups(),
            vec![vec!["Dusty", "study", "dusty"], vec!["night", "thing"]]
        );
    }

    #[test]
    fn case3() {
        assert!(AnagramIndex::new("").groups().is_empty());
        assert!(AnagramIndex::new("abc def").groups().is_empty());
    }

    #[test]
    fn case4_slices() {
        let text = String::from("listen silent");
        let g;
        {
            let idx = AnagramIndex::new(&text);
            g = idx.groups();
        }
        assert_eq!(g, vec![vec!["listen", "silent"]]);
        let r = text.as_ptr() as usize..text.as_ptr() as usize + text.len();
        assert!(r.contains(&(g[0][1].as_ptr() as usize)));
    }

    #[test]
    fn case5() {
        let text = "listen silent enlist google tinsel";
        let p;
        {
            let idx = AnagramIndex::new(text);
            let s = String::from("listen");
            p = idx.partners(&s);
        }
        assert_eq!(p, vec!["silent", "enlist", "tinsel"]);
    }

    #[test]
    fn partners_case() {
        let idx = AnagramIndex::new("Dusty study dusty");
        assert_eq!(idx.partners("dusty"), vec!["Dusty", "study"]);
        assert_eq!(idx.partners("tydsu"), vec!["Dusty", "study", "dusty"]);
        assert!(idx.partners("xyz").is_empty());
    }
}
