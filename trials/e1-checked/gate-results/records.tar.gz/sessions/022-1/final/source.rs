use std::time::{Duration, Instant};

#[derive(Debug, Clone, PartialEq)]
pub struct Report {
    pub calls: u32,
    pub last_ok: Option<u32>,
    pub elapsed: Duration,
}

pub fn watch(interval: Duration, misses: u32, mut probe: impl FnMut() -> bool) -> Report {
    assert!(misses > 0, "misses must be at least 1");
    let start = Instant::now();
    let mut calls: u32 = 0;
    let mut last_ok = None;
    let mut consecutive = 0u32;
    let mut tick: u128 = 0;
    let mut elapsed;
    loop {
        elapsed = start.elapsed();
        let ok = probe();
        let idx = calls;
        calls += 1;
        if ok {
            last_ok = Some(idx);
            consecutive = 0;
        } else {
            consecutive += 1;
            if consecutive >= misses {
                break;
            }
        }
        let iv = interval.as_nanos();
        if iv == 0 {
            continue;
        }
        let now = start.elapsed().as_nanos();
        let next = (now / iv + 1).max(tick + 1);
        tick = next;
        let target_nanos = iv * next;
        let target = start
            + Duration::new(
                (target_nanos / 1_000_000_000) as u64,
                (target_nanos % 1_000_000_000) as u32,
            );
        let n = Instant::now();
        if target > n {
            std::thread::sleep(target - n);
        }
    }
    Report { calls, last_ok, elapsed }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ms(n: u64) -> Duration {
        Duration::from_millis(n)
    }

    #[test]
    fn case1() {
        let seq = [true, true, false, true, false, false];
        let mut i = 0;
        let r = watch(ms(100), 2, || {
            let v = seq[i];
            i += 1;
            v
        });
        assert_eq!(r.calls, 6);
        assert_eq!(r.last_ok, Some(3));
        assert!(r.elapsed >= ms(500) && r.elapsed < ms(650), "{:?}", r.elapsed);
    }

    #[test]
    fn case2() {
        let mut first = true;
        let r = watch(ms(100), 1, || {
            if first {
                first = false;
                std::thread::sleep(ms(250));
                true
            } else {
                false
            }
        });
        assert_eq!(r.calls, 2);
        assert_eq!(r.last_ok, Some(0));
        assert!(r.elapsed >= ms(300) && r.elapsed < ms(450), "{:?}", r.elapsed);
    }

    #[test]
    fn case3() {
        let r = watch(ms(100), 1, || false);
        assert_eq!(r.calls, 1);
        assert_eq!(r.last_ok, None);
        assert!(r.elapsed < ms(150));
    }

    #[test]
    #[should_panic]
    fn case4() {
        watch(ms(100), 0, || true);
    }
}
