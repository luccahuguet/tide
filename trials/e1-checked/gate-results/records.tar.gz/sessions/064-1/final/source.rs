use serde::{Deserialize, Serialize};
use std::collections::HashSet;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Item {
    pub sku: String,
    pub quantity: u32,
    pub unit_price_cents: u64,
    #[serde(default)]
    pub tags: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub discontinued: Option<bool>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Inventory {
    pub warehouse: String,
    pub items: Vec<Item>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum Change {
    Restock { sku: String, qty: u32 },
    Sell { sku: String, qty: u32 },
    Discontinue { sku: String },
}

#[derive(Debug, thiserror::Error)]
pub enum LoadError {
    #[error("json error: {0}")]
    Json(#[from] serde_json::Error),
    #[error("duplicate sku: {0}")]
    Duplicate(String),
}

#[derive(Debug, thiserror::Error)]
pub enum ApplyError {
    #[error("json error: {0}")]
    Json(#[from] serde_json::Error),
    #[error("unknown sku: {0}")]
    UnknownSku(String),
    #[error("insufficient quantity: {0}")]
    Insufficient(String),
    #[error("overflow: {0}")]
    Overflow(String),
}

pub fn load(bytes: &[u8]) -> Result<Inventory, LoadError> {
    let inv: Inventory = serde_json::from_slice(bytes)?;
    let mut seen = HashSet::new();
    for it in &inv.items {
        if !seen.insert(it.sku.as_str()) {
            return Err(LoadError::Duplicate(it.sku.clone()));
        }
    }
    Ok(inv)
}

pub fn apply(inv: &mut Inventory, changes: &[u8]) -> Result<(), ApplyError> {
    let changes: Vec<Change> = serde_json::from_slice(changes)?;
    let mut items = inv.items.clone();
    for c in &changes {
        let sku = match c {
            Change::Restock { sku, .. } | Change::Sell { sku, .. } | Change::Discontinue { sku } => sku,
        };
        let item = items
            .iter_mut()
            .find(|i| &i.sku == sku)
            .ok_or_else(|| ApplyError::UnknownSku(sku.clone()))?;
        match c {
            Change::Restock { qty, .. } => {
                item.quantity = item
                    .quantity
                    .checked_add(*qty)
                    .ok_or_else(|| ApplyError::Overflow(sku.clone()))?;
            }
            Change::Sell { qty, .. } => {
                item.quantity = item
                    .quantity
                    .checked_sub(*qty)
                    .ok_or_else(|| ApplyError::Insufficient(sku.clone()))?;
            }
            Change::Discontinue { .. } => item.discontinued = Some(true),
        }
    }
    inv.items = items;
    Ok(())
}

pub fn save(inv: &Inventory) -> Vec<u8> {
    serde_json::to_vec(inv).expect("inventory serializes")
}

#[cfg(test)]
mod tests {
    use super::*;

    const INV: &str = r#"{"warehouse":"w1","items":[{"sku":"a","quantity":3,"unitPriceCents":250},{"sku":"b","quantity":0,"unitPriceCents":100,"tags":["x"]}]}"#;

    fn inv() -> Inventory {
        load(INV.as_bytes()).unwrap()
    }

    #[test]
    fn loads() {
        let i = inv();
        assert!(i.items[0].tags.is_empty());
        assert_eq!(i.items[0].discontinued, None);
        assert_eq!(i.items[1].discontinued, None);
        assert_eq!(i.items[1].tags, vec!["x".to_string()]);
    }

    #[test]
    fn load_errors() {
        let d = r#"{"warehouse":"w","items":[{"sku":"a","quantity":1,"unitPriceCents":1},{"sku":"a","quantity":2,"unitPriceCents":1}]}"#;
        assert!(matches!(load(d.as_bytes()), Err(LoadError::Duplicate(s)) if s == "a"));
        assert!(matches!(load(b"{bad"), Err(LoadError::Json(_))));
    }

    #[test]
    fn apply_cases() {
        let mut i = inv();
        apply(&mut i, br#"[{"Sell":{"sku":"a","qty":2}},{"Restock":{"sku":"b","qty":5}}]"#).unwrap();
        assert_eq!(i.items[0].quantity, 1);
        assert_eq!(i.items[1].quantity, 5);

        let mut i = inv();
        let r = apply(&mut i, br#"[{"Restock":{"sku":"b","qty":1}},{"Sell":{"sku":"a","qty":9}}]"#);
        assert!(matches!(r, Err(ApplyError::Insufficient(s)) if s == "a"));
        assert_eq!(i, inv());

        let r = apply(&mut i, br#"[{"Sell":{"sku":"z","qty":1}}]"#);
        assert!(matches!(r, Err(ApplyError::UnknownSku(s)) if s == "z"));

        let r = apply(&mut i, br#"[{"Restock":{"sku":"b","qty":1}},{"Restock":{"sku":"b","qty":4294967295}}]"#);
        assert!(matches!(r, Err(ApplyError::Overflow(s)) if s == "b"));
        assert_eq!(i, inv());

        assert!(matches!(apply(&mut i, b"nope"), Err(ApplyError::Json(_))));
    }

    #[test]
    fn discontinue() {
        let mut i = inv();
        apply(&mut i, br#"[{"Discontinue":{"sku":"a"}}]"#).unwrap();
        assert_eq!(i.items[0].discontinued, Some(true));
    }

    #[test]
    fn roundtrip() {
        let mut i = inv();
        let s = save(&i);
        assert_eq!(load(&s).unwrap(), i);
        assert!(String::from_utf8(s).unwrap().contains("\"unitPriceCents\""));
        i.items[1].discontinued = Some(false);
        assert_eq!(load(&save(&i)).unwrap(), i);
    }
}
