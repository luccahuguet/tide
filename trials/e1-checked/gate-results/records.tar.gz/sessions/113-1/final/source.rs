use std::collections::HashSet;
use std::fs;
use std::io;
use std::path::{Path, PathBuf};

#[derive(Debug, thiserror::Error)]
pub enum ExportError {
    #[error("bad report name: {0:?}")]
    BadName(String),
    #[error("duplicate report name: {0:?}")]
    Duplicate(String),
    #[error("i/o error: {0}")]
    Io(#[from] io::Error),
}

fn valid_name(name: &str) -> bool {
    !name.is_empty()
        && !name.contains('\\')
        && !name.contains('\0')
        && name
            .split('/')
            .all(|c| !c.is_empty() && c != "." && c != "..")
}

fn not_dir_err(p: &Path) -> io::Error {
    io::Error::other(format!("{} exists and is not a real directory", p.display()))
}

/// Ensure `p` is a real (non-symlink) directory, creating it if missing.
fn ensure_dir(p: &Path) -> io::Result<()> {
    match fs::symlink_metadata(p) {
        Ok(m) if m.file_type().is_dir() => Ok(()),
        Ok(_) => Err(not_dir_err(p)),
        Err(e) if e.kind() == io::ErrorKind::NotFound => match fs::create_dir(p) {
            Ok(()) => Ok(()),
            Err(e) if e.kind() == io::ErrorKind::AlreadyExists => {
                let m = fs::symlink_metadata(p)?;
                if m.file_type().is_dir() {
                    Ok(())
                } else {
                    Err(not_dir_err(p))
                }
            }
            Err(e) => Err(e),
        },
        Err(e) => Err(e),
    }
}

pub fn export(root: &Path, reports: &[(&str, &str)]) -> Result<usize, ExportError> {
    let mut seen = HashSet::new();
    for &(name, _) in reports {
        if !valid_name(name) {
            return Err(ExportError::BadName(name.to_string()));
        }
        if !seen.insert(name) {
            return Err(ExportError::Duplicate(name.to_string()));
        }
    }

    let out = root.join("out");
    ensure_dir(&out)?;

    for &(name, body) in reports {
        let comps: Vec<&str> = name.split('/').collect();
        let mut p: PathBuf = out.clone();
        for c in &comps[..comps.len() - 1] {
            p.push(c);
            ensure_dir(&p)?;
        }
        p.push(comps[comps.len() - 1]);
        // Never follow a symlink at the target: replace the link itself.
        if let Ok(m) = fs::symlink_metadata(&p) {
            if m.file_type().is_symlink() {
                fs::remove_file(&p)?;
            }
        }
        fs::write(&p, body)?;
    }
    Ok(reports.len())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicUsize, Ordering};

    static N: AtomicUsize = AtomicUsize::new(0);

    fn tmp() -> PathBuf {
        let p = std::env::temp_dir().join(format!(
            "export-test-{}-{}",
            std::process::id(),
            N.fetch_add(1, Ordering::SeqCst)
        ));
        let _ = fs::remove_dir_all(&p);
        fs::create_dir_all(&p).unwrap();
        p
    }

    #[test]
    fn writes_and_replaces() {
        let d = tmp();
        fs::create_dir(d.join("out")).unwrap();
        fs::write(d.join("out/a.txt"), "old").unwrap();
        let n = export(&d, &[("a.txt", "1"), ("2026/jan.txt", "2")]).unwrap();
        assert_eq!(n, 2);
        assert_eq!(fs::read_to_string(d.join("out/a.txt")).unwrap(), "1");
        assert_eq!(fs::read_to_string(d.join("out/2026/jan.txt")).unwrap(), "2");
    }

    #[test]
    fn traversal_rejected() {
        let d = tmp();
        let r = export(&d, &[("ok", "x"), ("../evil", "y")]);
        assert!(matches!(r, Err(ExportError::BadName(ref n)) if n == "../evil"));
        assert!(!d.join("out/ok").exists());
        assert!(!d.join("evil").exists());
    }

    #[test]
    fn bad_names() {
        let d = tmp();
        for n in ["/abs", "a//b", "a/./b", "", "a\\b", "a/", "..", "."] {
            let r = export(&d, &[(n, "x")]);
            assert!(matches!(r, Err(ExportError::BadName(ref m)) if m == n), "{n}");
        }
    }

    #[test]
    fn duplicate() {
        let d = tmp();
        let r = export(&d, &[("a", "1"), ("a", "2")]);
        assert!(matches!(r, Err(ExportError::Duplicate(ref n)) if n == "a"));
        assert!(!d.join("out/a").exists());
    }

    #[test]
    fn out_is_file() {
        let d = tmp();
        fs::write(d.join("out"), "f").unwrap();
        assert!(matches!(export(&d, &[("a", "1")]), Err(ExportError::Io(_))));
    }

    #[cfg(unix)]
    #[test]
    fn symlink_dir_not_followed() {
        let d = tmp();
        fs::create_dir_all(d.join("out")).unwrap();
        fs::create_dir_all(d.join("outside")).unwrap();
        std::os::unix::fs::symlink(d.join("outside"), d.join("out/link")).unwrap();
        assert!(matches!(export(&d, &[("link/x", "1")]), Err(ExportError::Io(_))));
        assert!(!d.join("outside/x").exists());
    }
}
