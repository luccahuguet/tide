use std::collections::HashMap;
use std::hash::Hash;

const NIL: usize = usize::MAX;

struct Node<K, V> {
    key: K,
    value: V,
    prev: usize,
    next: usize,
}

/// A least-recently-used cache backed by a slot vector and an index map.
pub struct Lru<K, V> {
    map: HashMap<K, usize>,
    nodes: Vec<Node<K, V>>,
    head: usize, // most recent
    tail: usize, // least recent
    capacity: usize,
}

impl<K: Eq + Hash + Clone, V> Lru<K, V> {
    pub fn new(capacity: usize) -> Self {
        assert!(capacity > 0, "Lru capacity must be greater than 0");
        Lru {
            map: HashMap::new(),
            nodes: Vec::new(),
            head: NIL,
            tail: NIL,
            capacity,
        }
    }

    pub fn len(&self) -> usize {
        self.map.len()
    }

    pub fn is_empty(&self) -> bool {
        self.map.is_empty()
    }

    fn unlink(&mut self, i: usize) {
        let prev = self.nodes[i].prev;
        let next = self.nodes[i].next;
        if prev != NIL {
            self.nodes[prev].next = next;
        } else {
            self.head = next;
        }
        if next != NIL {
            self.nodes[next].prev = prev;
        } else {
            self.tail = prev;
        }
        self.nodes[i].prev = NIL;
        self.nodes[i].next = NIL;
    }

    fn push_front(&mut self, i: usize) {
        self.nodes[i].prev = NIL;
        self.nodes[i].next = self.head;
        if self.head != NIL {
            self.nodes[self.head].prev = i;
        } else {
            self.tail = i;
        }
        self.head = i;
    }

    fn touch(&mut self, i: usize) {
        if self.head != i {
            self.unlink(i);
            self.push_front(i);
        }
    }

    pub fn get(&mut self, k: &K) -> Option<&V> {
        let i = *self.map.get(k)?;
        self.touch(i);
        Some(&self.nodes[i].value)
    }

    pub fn peek(&self, k: &K) -> Option<&V> {
        let i = *self.map.get(k)?;
        Some(&self.nodes[i].value)
    }

    pub fn put(&mut self, k: K, v: V) -> Option<(K, V)> {
        if let Some(&i) = self.map.get(&k) {
            self.nodes[i].value = v;
            self.touch(i);
            return None;
        }
        if self.map.len() >= self.capacity {
            // Reuse the tail slot for the new entry.
            let t = self.tail;
            self.unlink(t);
            let old_key = std::mem::replace(&mut self.nodes[t].key, k.clone());
            let old_val = std::mem::replace(&mut self.nodes[t].value, v);
            self.map.remove(&old_key);
            self.map.insert(k, t);
            self.push_front(t);
            return Some((old_key, old_val));
        }
        let i = self.nodes.len();
        self.nodes.push(Node {
            key: k.clone(),
            value: v,
            prev: NIL,
            next: NIL,
        });
        self.map.insert(k, i);
        self.push_front(i);
        None
    }

    pub fn keys_recent_first(&self) -> Vec<&K> {
        let mut out = Vec::with_capacity(self.map.len());
        let mut i = self.head;
        while i != NIL {
            out.push(&self.nodes[i].key);
            i = self.nodes[i].next;
        }
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn case1_get_protects() {
        let mut c = Lru::new(2);
        assert_eq!(c.put("a", 1), None);
        assert_eq!(c.put("b", 2), None);
        assert_eq!(c.get(&"a"), Some(&1));
        assert_eq!(c.put("c", 3), Some(("b", 2)));
        assert_eq!(c.keys_recent_first(), vec![&"c", &"a"]);
        assert_eq!(c.len(), 2);
    }

    #[test]
    fn case2_peek_does_not_touch() {
        let mut c = Lru::new(2);
        c.put("a".to_string(), 1);
        c.put("b".to_string(), 2);
        assert_eq!(c.peek(&"a".to_string()), Some(&1));
        let ev = c.put("c".to_string(), 3);
        assert_eq!(ev, Some(("a".to_string(), 1)));
        assert_eq!(c.peek(&"a".to_string()), None);
    }

    #[test]
    fn case3_update_existing() {
        let mut c = Lru::new(2);
        c.put(1u32, 10u32);
        c.put(2, 20);
        assert_eq!(c.put(1, 11), None);
        assert_eq!(c.len(), 2);
        assert_eq!(c.peek(&1), Some(&11));
        assert_eq!(c.keys_recent_first(), vec![&1, &2]);
        assert_eq!(c.put(3, 30), Some((2, 20)));
    }

    #[test]
    #[should_panic]
    fn case4_zero_capacity() {
        let _c = Lru::<u32, u32>::new(0);
    }

    #[test]
    fn capacity_one() {
        let mut c = Lru::new(1);
        assert_eq!(c.put(1u32, 1u32), None);
        assert_eq!(c.put(2, 2), Some((1, 1)));
        assert_eq!(c.get(&1), None);
        assert_eq!(c.keys_recent_first(), vec![&2]);
    }

    #[test]
    fn case5_large() {
        let mut c: Lru<u64, u64> = Lru::new(100_000);
        let mut hits = 0u64;
        for i in 0..300_000u64 {
            let _ = c.put(i, i);
            if c.get(&(i / 2)).is_some() {
                hits += 1;
            }
        }
        assert_eq!(c.len(), 100_000);
        assert!(hits > 0);
    }
}
