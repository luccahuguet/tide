use std::cmp::Reverse;
use std::collections::BinaryHeap;
use std::sync::mpsc::{Receiver, sync_channel};
use std::thread;

#[derive(Debug, PartialEq, Eq, Clone, thiserror::Error)]
pub enum MergeError {
    #[error("input {input} is not sorted at index {index}")]
    Unsorted { input: usize, index: usize },
}

enum Msg {
    Item(i64),
    Unsorted(usize),
}

pub fn merge_streams(inputs: &[Vec<i64>], capacity: usize) -> Result<Vec<i64>, MergeError> {
    assert!(capacity > 0, "capacity must be greater than 0");
    thread::scope(|s| {
        let mut receivers: Vec<Receiver<Msg>> = Vec::with_capacity(inputs.len());
        for input in inputs {
            let (tx, rx) = sync_channel::<Msg>(capacity);
            receivers.push(rx);
            s.spawn(move || {
                let mut prev: Option<i64> = None;
                for (i, &v) in input.iter().enumerate() {
                    if let Some(p) = prev
                        && v < p
                    {
                        let _ = tx.send(Msg::Unsorted(i));
                        return;
                    }
                    prev = Some(v);
                    if tx.send(Msg::Item(v)).is_err() {
                        return;
                    }
                }
            });
        }

        let mut errors: Vec<MergeError> = Vec::new();
        let mut heap: BinaryHeap<Reverse<(i64, usize)>> = BinaryHeap::new();
        let mut pull = |idx: usize, heap: &mut BinaryHeap<Reverse<(i64, usize)>>| {
            match receivers[idx].recv() {
                Ok(Msg::Item(v)) => heap.push(Reverse((v, idx))),
                Ok(Msg::Unsorted(index)) => errors.push(MergeError::Unsorted { input: idx, index }),
                Err(_) => {}
            }
        };
        for idx in 0..inputs.len() {
            pull(idx, &mut heap);
        }
        let mut out = Vec::new();
        while let Some(Reverse((v, idx))) = heap.pop() {
            out.push(v);
            pull(idx, &mut heap);
        }
        drop(pull);
        match errors
            .into_iter()
            .min_by_key(|MergeError::Unsorted { input, .. }| *input)
        {
            Some(e) => Err(e),
            None => Ok(out),
        }
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn basic() {
        let inputs = vec![vec![1, 4, 9], vec![2, 3, 10], vec![], vec![5]];
        assert_eq!(merge_streams(&inputs, 1), Ok(vec![1, 2, 3, 4, 5, 9, 10]));
        assert_eq!(merge_streams(&[], 1), Ok(vec![]));
        assert_eq!(
            merge_streams(&[vec![1, 2, 2], vec![2]], 3),
            Ok(vec![1, 2, 2, 2])
        );
    }

    #[test]
    fn large() {
        let inputs: Vec<Vec<i64>> = (0..8)
            .map(|k| (0..600).map(|i| i * 3 + k % 5).collect())
            .collect();
        let mut expected: Vec<i64> = inputs.concat();
        expected.sort();
        assert_eq!(merge_streams(&inputs, 2), Ok(expected));
    }

    #[test]
    fn unsorted() {
        let inputs = vec![vec![1, 2], vec![3, 1], vec![5, 0]];
        assert_eq!(
            merge_streams(&inputs, 1),
            Err(MergeError::Unsorted { input: 1, index: 1 })
        );
        let inputs = vec![vec![1, 2], vec![9, 10, 11, 12, 0], vec![5, 0]];
        assert_eq!(
            merge_streams(&inputs, 1),
            Err(MergeError::Unsorted { input: 1, index: 4 })
        );
    }

    #[test]
    #[should_panic]
    fn zero_capacity() {
        let _ = merge_streams(&[vec![1]], 0);
    }
}
