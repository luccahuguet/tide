use std::fmt;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CalcError {
    DivByZero { pos: usize },
    Overflow { pos: usize },
    Unexpected { pos: usize },
}

impl fmt::Display for CalcError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            CalcError::DivByZero { pos } => write!(f, "division by zero at {}", pos),
            CalcError::Overflow { pos } => write!(f, "overflow at {}", pos),
            CalcError::Unexpected { pos } => write!(f, "unexpected input at {}", pos),
        }
    }
}

struct Parser<'a> {
    src: &'a [u8],
    pos: usize,
}

impl<'a> Parser<'a> {
    fn skip_ws(&mut self) {
        while self.pos < self.src.len() && self.src[self.pos] == b' ' {
            self.pos += 1;
        }
    }

    fn peek(&mut self) -> Option<u8> {
        self.skip_ws();
        self.src.get(self.pos).copied()
    }

    fn expr(&mut self) -> Result<i64, CalcError> {
        let mut acc = self.term()?;
        loop {
            match self.peek() {
                Some(op @ (b'+' | b'-')) => {
                    let op_pos = self.pos;
                    self.pos += 1;
                    let rhs = self.term()?;
                    let r = if op == b'+' {
                        acc.checked_add(rhs)
                    } else {
                        acc.checked_sub(rhs)
                    };
                    acc = r.ok_or(CalcError::Overflow { pos: op_pos })?;
                }
                _ => return Ok(acc),
            }
        }
    }

    fn term(&mut self) -> Result<i64, CalcError> {
        let mut acc = self.unary()?;
        loop {
            match self.peek() {
                Some(op @ (b'*' | b'/' | b'%')) => {
                    let op_pos = self.pos;
                    self.pos += 1;
                    let rhs = self.unary()?;
                    let r = match op {
                        b'*' => acc.checked_mul(rhs),
                        _ => {
                            if rhs == 0 {
                                return Err(CalcError::DivByZero { pos: op_pos });
                            }
                            if op == b'/' {
                                acc.checked_div(rhs)
                            } else {
                                acc.checked_rem(rhs)
                            }
                        }
                    };
                    acc = r.ok_or(CalcError::Overflow { pos: op_pos })?;
                }
                _ => return Ok(acc),
            }
        }
    }

    fn unary(&mut self) -> Result<i64, CalcError> {
        match self.peek() {
            Some(b'-') => {
                let op_pos = self.pos;
                self.pos += 1;
                let v = self.unary()?;
                v.checked_neg().ok_or(CalcError::Overflow { pos: op_pos })
            }
            Some(b'(') => {
                self.pos += 1;
                let v = self.expr()?;
                match self.peek() {
                    Some(b')') => {
                        self.pos += 1;
                        Ok(v)
                    }
                    _ => Err(CalcError::Unexpected { pos: self.pos }),
                }
            }
            Some(c) if c.is_ascii_digit() => {
                let start = self.pos;
                let mut v: i64 = 0;
                while self.pos < self.src.len() && self.src[self.pos].is_ascii_digit() {
                    let d = i64::from(self.src[self.pos] - b'0');
                    v = v
                        .checked_mul(10)
                        .and_then(|x| x.checked_add(d))
                        .ok_or(CalcError::Overflow { pos: start })?;
                    self.pos += 1;
                }
                Ok(v)
            }
            _ => Err(CalcError::Unexpected { pos: self.pos }),
        }
    }
}

pub fn eval(src: &str) -> Result<i64, CalcError> {
    let mut p = Parser { src: src.as_bytes(), pos: 0 };
    let v = p.expr()?;
    if p.peek().is_some() {
        return Err(CalcError::Unexpected { pos: p.pos });
    }
    Ok(v)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn values() {
        assert_eq!(eval("1 + 2 * 3"), Ok(7));
        assert_eq!(eval("(1+2)*3"), Ok(9));
        assert_eq!(eval("-(-4) % 3"), Ok(1));
        assert_eq!(eval("7 / -2"), Ok(-3));
        assert_eq!(eval("- 9223372036854775807 - 1"), Ok(i64::MIN));
        assert_eq!(eval("10 - 3 - 2"), Ok(5));
        assert_eq!(eval("-2 * 3"), Ok(-6));
    }

    #[test]
    fn errors() {
        assert_eq!(eval("1 / (2 - 2)"), Err(CalcError::DivByZero { pos: 2 }));
        assert_eq!(eval("9223372036854775807 + 1"), Err(CalcError::Overflow { pos: 20 }));
        assert_eq!(eval("9223372036854775808"), Err(CalcError::Overflow { pos: 0 }));
        assert_eq!(eval("-9223372036854775808"), Err(CalcError::Overflow { pos: 1 }));
        assert_eq!(eval("-(-9223372036854775807 - 1)"), Err(CalcError::Overflow { pos: 0 }));
        assert_eq!(eval("2 *"), Err(CalcError::Unexpected { pos: 3 }));
        assert_eq!(eval("(1"), Err(CalcError::Unexpected { pos: 2 }));
        assert_eq!(eval("1 2"), Err(CalcError::Unexpected { pos: 2 }));
        assert_eq!(eval(""), Err(CalcError::Unexpected { pos: 0 }));
        assert_eq!(eval("a"), Err(CalcError::Unexpected { pos: 0 }));
    }

    #[test]
    fn display() {
        assert_eq!(CalcError::DivByZero { pos: 2 }.to_string(), "division by zero at 2");
        assert_eq!(CalcError::Overflow { pos: 3 }.to_string(), "overflow at 3");
        assert_eq!(CalcError::Unexpected { pos: 4 }.to_string(), "unexpected input at 4");
    }
}
