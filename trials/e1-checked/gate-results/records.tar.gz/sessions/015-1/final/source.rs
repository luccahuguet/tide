use std::collections::HashMap;
use std::collections::HashSet;

/// An index of the anagram classes in one text.
pub struct AnagramIndex<'a> {
    /// Distinct words in order of first occurrence.
    words: Vec<&'a str>,
    /// Class key of each distinct word (parallel to `words`).
    keys: Vec<Vec<u8>>,
    /// Class key -> indices into `words`, in order of first occurrence.
    classes: HashMap<Vec<u8>, Vec<usize>>,
}

fn key_of(word: &str) -> Vec<u8> {
    let mut k: Vec<u8> = word.bytes().map(|b| b.to_ascii_lowercase()).collect();
    k.sort_unstable();
    k
}

impl<'a> AnagramIndex<'a> {
    pub fn new(text: &'a str) -> Self {
        let bytes = text.as_bytes();
        let mut words: Vec<&'a str> = Vec::new();
        let mut keys: Vec<Vec<u8>> = Vec::new();
        let mut classes: HashMap<Vec<u8>, Vec<usize>> = HashMap::new();
        let mut seen: HashSet<&'a str> = HashSet::new();
        let mut i = 0;
        while i < bytes.len() {
            if bytes[i].is_ascii_alphabetic() {
                let start = i;
                while i < bytes.len() && bytes[i].is_ascii_alphabetic() {
                    i += 1;
                }
                let w: &'a str = &text[start..i];
                if seen.insert(w) {
                    let k = key_of(w);
                    let idx = words.len();
                    words.push(w);
                    classes.entry(k.clone()).or_default().push(idx);
                    keys.push(k);
                }
            } else {
                i += 1;
            }
        }
        AnagramIndex { words, keys, classes }
    }

    pub fn groups(&self) -> Vec<Vec<&'a str>> {
        let mut out = Vec::new();
        for (idx, k) in self.keys.iter().enumerate() {
            if let Some(members) = self.classes.get(k) {
                if members.len() >= 2 && members[0] == idx {
                    out.push(members.iter().map(|&m| self.words[m]).collect());
                }
            }
        }
        out
    }

    pub fn partners(&self, word: &str) -> Vec<&'a str> {
        let k = key_of(word);
        match self.classes.get(&k) {
            Some(members) => members
                .iter()
                .map(|&m| self.words[m])
                .filter(|w| *w != word)
                .collect(),
            None => Vec::new(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn case1() {
        let idx = AnagramIndex::new("listen silent enlist google tinsel");
        assert_eq!(
            idx.groups(),
            vec![vec!["listen", "silent", "enlist", "tinsel"]]
        );
    }

    #[test]
    fn case2() {
        let idx = AnagramIndex::new("Dusty study, night thing; dusty");
        assert_eq!(
            idx.groups(),
            vec![vec!["Dusty", "study", "dusty"], vec!["night", "thing"]]
        );
    }

    #[test]
    fn case3() {
        assert!(AnagramIndex::new("").groups().is_empty());
        assert!(AnagramIndex::new("abc def").groups().is_empty());
    }

    #[test]
    fn case4_slices_outlive_index() {
        let text = String::from("listen silent");
        let g;
        {
            let idx = AnagramIndex::new(&text);
            g = idx.groups();
        }
        assert_eq!(g, vec![vec!["listen", "silent"]]);
    }

    #[test]
    fn case5_partners() {
        let text = "listen silent enlist google tinsel";
        let p;
        {
            let idx = AnagramIndex::new(text);
            {
                let w = String::from("listen");
                p = idx.partners(&w);
            }
        }
        assert_eq!(p, vec!["silent", "enlist", "tinsel"]);
        assert!(AnagramIndex::new(text).partners("zzz").is_empty());
        assert_eq!(AnagramIndex::new(text).partners("Silent"), vec!["listen", "silent", "enlist", "tinsel"]);
    }
}
