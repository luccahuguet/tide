//! Decimal amounts as integer cents.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Cents(pub i64);

#[derive(Debug, PartialEq, thiserror::Error)]
pub enum AmountError {
    #[error("invalid amount")]
    Invalid,
    #[error("amount overflow")]
    Overflow,
}

pub fn parse_amount(s: &str) -> Result<Cents, AmountError> {
    let (neg, rest) = match s.strip_prefix('-') {
        Some(r) => (true, r),
        None => (false, s),
    };
    let (int_part, frac_part) = match rest.split_once('.') {
        Some((i, f)) => (i, Some(f)),
        None => (rest, None),
    };
    if int_part.is_empty() || !int_part.bytes().all(|b| b.is_ascii_digit()) {
        return Err(AmountError::Invalid);
    }
    let frac_cents: i128 = match frac_part {
        None => 0,
        Some(f) => {
            if f.is_empty() || f.len() > 2 || !f.bytes().all(|b| b.is_ascii_digit()) {
                return Err(AmountError::Invalid);
            }
            let v: i128 = f.parse().map_err(|_| AmountError::Invalid)?;
            if f.len() == 1 { v * 10 } else { v }
        }
    };
    let mut int_val: i128 = 0;
    for b in int_part.bytes() {
        int_val = int_val
            .checked_mul(10)
            .and_then(|v| v.checked_add(i128::from(b - b'0')))
            .ok_or(AmountError::Overflow)?;
    }
    let mut total = int_val
        .checked_mul(100)
        .and_then(|v| v.checked_add(frac_cents))
        .ok_or(AmountError::Overflow)?;
    if neg {
        total = -total;
    }
    i64::try_from(total)
        .map(Cents)
        .map_err(|_| AmountError::Overflow)
}

pub fn total(items: &[(Cents, u32)]) -> Result<Cents, AmountError> {
    let mut sum: i64 = 0;
    for &(Cents(p), q) in items {
        let line = p.checked_mul(i64::from(q)).ok_or(AmountError::Overflow)?;
        sum = sum.checked_add(line).ok_or(AmountError::Overflow)?;
    }
    Ok(Cents(sum))
}

pub fn format_amount(c: Cents) -> String {
    let abs = c.0.unsigned_abs();
    let sign = if c.0 < 0 { "-" } else { "" };
    format!("{}{}.{:02}", sign, abs / 100, abs % 100)
}

pub fn split_even(c: Cents, parts: u32) -> Vec<Cents> {
    assert!(parts != 0, "parts must be nonzero");
    let n = i64::from(parts);
    let q = c.0.div_euclid(n);
    let r = c.0.rem_euclid(n);
    (0..n)
        .map(|i| if i < r { Cents(q + 1) } else { Cents(q) })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_ok() {
        assert_eq!(parse_amount("12.34"), Ok(Cents(1234)));
        assert_eq!(parse_amount("-0.5"), Ok(Cents(-50)));
        assert_eq!(parse_amount("7"), Ok(Cents(700)));
        assert_eq!(parse_amount("1.5"), Ok(Cents(150)));
    }

    #[test]
    fn parse_invalid() {
        for s in ["1.234", "", "-", ".5", "1.", "+1", "1,00", "-.5", "1.a", "--1"] {
            assert_eq!(parse_amount(s), Err(AmountError::Invalid), "{s}");
        }
    }

    #[test]
    fn parse_bounds() {
        assert_eq!(parse_amount("92233720368547758.07"), Ok(Cents(i64::MAX)));
        assert_eq!(parse_amount("-92233720368547758.08"), Ok(Cents(i64::MIN)));
        assert_eq!(parse_amount("92233720368547758.08"), Err(AmountError::Overflow));
        assert_eq!(
            parse_amount("99999999999999999999999999999999999999999999999"),
            Err(AmountError::Overflow)
        );
    }

    #[test]
    fn totals() {
        assert_eq!(total(&[(Cents(250), 3), (Cents(-100), 2)]), Ok(Cents(550)));
        assert_eq!(total(&[(Cents(1), u32::MAX)]), Ok(Cents(4294967295)));
        assert_eq!(total(&[(Cents(i64::MAX), 2)]), Err(AmountError::Overflow));
        assert_eq!(total(&[]), Ok(Cents(0)));
    }

    #[test]
    fn formatting() {
        assert_eq!(format_amount(Cents(0)), "0.00");
        assert_eq!(format_amount(Cents(-1205)), "-12.05");
        assert_eq!(format_amount(Cents(123450)), "1234.50");
        assert_eq!(format_amount(Cents(-5)), "-0.05");
        assert_eq!(format_amount(Cents(i64::MIN)), "-92233720368547758.08");
    }

    #[test]
    fn splitting() {
        assert_eq!(split_even(Cents(100), 3), vec![Cents(34), Cents(33), Cents(33)]);
        assert_eq!(split_even(Cents(-5), 2), vec![Cents(-2), Cents(-3)]);
        assert_eq!(split_even(Cents(0), 1), vec![Cents(0)]);
        let v = split_even(Cents(i64::MIN), 7);
        assert_eq!(v.iter().map(|c| c.0 as i128).sum::<i128>(), i64::MIN as i128);
    }

    #[test]
    #[should_panic]
    fn split_zero_panics() {
        split_even(Cents(1), 0);
    }
}
