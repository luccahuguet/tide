use std::cmp::Reverse;
use std::collections::BinaryHeap;
use std::sync::mpsc::{sync_channel, Receiver};
use std::task::{TaskError, Tasks};

#[derive(Debug, PartialEq)]
pub enum MergeError {
    Unsorted { input: usize, index: usize },
    Task(TaskError),
}

impl From<TaskError> for MergeError {
    fn from(e: TaskError) -> Self {
        MergeError::Task(e)
    }
}

pub fn merge_streams(
    tasks: &Tasks,
    inputs: &[Vec<i64>],
    capacity: usize,
) -> Result<Vec<i64>, MergeError> {
    if capacity == 0 {
        panic!("capacity must be positive");
    }
    tasks.scope(|s| {
        let mut receivers: Vec<Receiver<i64>> = Vec::new();
        let mut producers = Vec::new();
        for input in inputs.iter() {
            let (tx, rx) = sync_channel::<i64>(capacity, tasks);
            receivers.push(rx);
            let t = s.spawn(move || {
                let mut prev: Option<i64> = None;
                for (idx, &item) in input.iter().enumerate() {
                    if let Some(p) = prev {
                        if item < p {
                            return Ok(Some(idx));
                        }
                    }
                    prev = Some(item);
                    if tx.send(item).is_err() {
                        return Ok(None);
                    }
                }
                Ok(None)
            });
            producers.push(t);
        }

        let mut heap: BinaryHeap<Reverse<(i64, usize)>> = BinaryHeap::new();
        for (i, rx) in receivers.iter().enumerate() {
            if let Ok(v) = rx.recv() {
                heap.push(Reverse((v, i)));
            }
        }
        let mut out = Vec::new();
        while let Some(Reverse((v, i))) = heap.pop() {
            out.push(v);
            if let Ok(next) = receivers[i].recv() {
                heap.push(Reverse((next, i)));
            }
        }

        let mut failure: Option<MergeError> = None;
        for (i, t) in producers.into_iter().enumerate() {
            let r = t.join()?;
            if let Some(index) = r {
                if failure.is_none() {
                    failure = Some(MergeError::Unsorted { input: i, index });
                }
            }
        }
        match failure {
            Some(e) => Err(e),
            None => Ok(out),
        }
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    #[sim_test(seeds = 20)]
    fn basic(sim: SimRoot) {
        let inputs = vec![vec![1, 4, 9], vec![2, 3, 10], vec![], vec![5]];
        assert_eq!(
            merge_streams(&sim.tasks, &inputs, 1),
            Ok(vec![1, 2, 3, 4, 5, 9, 10])
        );
        assert_eq!(merge_streams(&sim.tasks, &[], 3), Ok(vec![]));
        let dup = vec![vec![1, 1, 2], vec![1, 2]];
        assert_eq!(merge_streams(&sim.tasks, &dup, 2), Ok(vec![1, 1, 1, 2, 2]));
    }

    #[sim_test(seeds = 20)]
    fn many(sim: SimRoot) {
        let mut inputs = Vec::new();
        let mut all = Vec::new();
        for k in 0..8i64 {
            let v: Vec<i64> = (0..600i64).map(|j| j * 3 + k % 4).collect();
            all.extend(v.iter().copied());
            inputs.push(v);
        }
        all.sort();
        assert_eq!(merge_streams(&sim.tasks, &inputs, 2), Ok(all));
    }

    #[sim_test(seeds = 20)]
    fn unsorted(sim: SimRoot) {
        let inputs = vec![vec![1, 2], vec![3, 1], vec![5, 0]];
        assert_eq!(
            merge_streams(&sim.tasks, &inputs, 1),
            Err(MergeError::Unsorted { input: 1, index: 1 })
        );
    }

    #[test]
    #[should_panic]
    fn zero_capacity() {
        let sim = Root::sim(0);
        let _ = merge_streams(&sim.tasks, &[vec![1]], 0);
    }
}
