use std::io::{Read, Write};
use std::process::ExitCode;

#[derive(Debug, PartialEq)]
struct Opts {
    col: usize,
    sep: char,
}

fn parse_args(args: &[String]) -> Result<Opts, String> {
    let mut col = 1usize;
    let mut sep = ',';
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--col" => {
                let v = args.get(i + 1).ok_or("--col needs a value")?;
                col = v
                    .parse::<usize>()
                    .ok()
                    .filter(|&n| n >= 1)
                    .ok_or_else(|| format!("bad column: {v}"))?;
                i += 2;
            }
            "--sep" => {
                let v = args.get(i + 1).ok_or("--sep needs a value")?;
                let mut cs = v.chars();
                match (cs.next(), cs.next()) {
                    (Some(c), None) => sep = c,
                    _ => return Err(format!("bad separator: {v}")),
                }
                i += 2;
            }
            other => return Err(format!("unknown argument: {other}")),
        }
    }
    Ok(Opts { col, sep })
}

#[derive(Debug, PartialEq)]
enum StatsError {
    Line(usize, String),
    Overflow,
}

#[derive(Debug, PartialEq)]
struct Stats {
    count: u64,
    sum: i64,
    min: i64,
    max: i64,
}

fn compute(input: &str, opts: &Opts) -> Result<Option<Stats>, StatsError> {
    let mut st: Option<Stats> = None;
    for (idx, line) in input.lines().enumerate() {
        let ln = idx + 1;
        if line.trim().is_empty() {
            continue;
        }
        let field = line.split(opts.sep).nth(opts.col - 1).ok_or_else(|| {
            StatsError::Line(ln, format!("too few fields (need column {})", opts.col))
        })?;
        let f = field.trim();
        let v: i64 = f
            .parse()
            .map_err(|_| StatsError::Line(ln, format!("not an integer: {f:?}")))?;
        match &mut st {
            None => {
                st = Some(Stats {
                    count: 1,
                    sum: v,
                    min: v,
                    max: v,
                })
            }
            Some(s) => {
                s.count += 1;
                s.sum = s.sum.checked_add(v).ok_or(StatsError::Overflow)?;
                s.min = s.min.min(v);
                s.max = s.max.max(v);
            }
        }
    }
    Ok(st)
}

fn format_stats(st: &Option<Stats>) -> String {
    match st {
        None => "count=0\n".to_string(),
        Some(s) => format!(
            "count={} sum={} min={} max={}\n",
            s.count, s.sum, s.min, s.max
        ),
    }
}

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let opts = match parse_args(&args) {
        Ok(o) => o,
        Err(e) => {
            eprintln!("usage: colstats [--col N] [--sep C] ({e})");
            return ExitCode::from(2);
        }
    };
    let mut buf = Vec::new();
    if let Err(e) = std::io::stdin().read_to_end(&mut buf) {
        eprintln!("colstats: read error: {e}");
        return ExitCode::from(1);
    }
    let input = String::from_utf8_lossy(&buf);
    match compute(&input, &opts) {
        Ok(st) => {
            let mut out = std::io::stdout();
            let _ = out.write_all(format_stats(&st).as_bytes());
            let _ = out.flush();
            ExitCode::SUCCESS
        }
        Err(StatsError::Line(l, r)) => {
            eprintln!("colstats: line {l}: {r}");
            ExitCode::from(1)
        }
        Err(StatsError::Overflow) => {
            eprintln!("colstats: overflow");
            ExitCode::from(1)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn a(v: &[&str]) -> Vec<String> {
        v.iter().map(|s| s.to_string()).collect()
    }

    fn run(args: &[&str], input: &str) -> Result<String, StatsError> {
        let o = parse_args(&a(args)).unwrap();
        compute(input, &o).map(|s| format_stats(&s))
    }

    #[test]
    fn case1() {
        assert_eq!(
            run(&["--col", "2"], "a,1\nb,-5\n\nc,10\n").unwrap(),
            "count=3 sum=6 min=-5 max=10\n"
        );
    }

    #[test]
    fn case2() {
        assert_eq!(
            run(&["--sep", ";", "--col", "1"], "4;x\n2;y\n").unwrap(),
            "count=2 sum=6 min=2 max=4\n"
        );
    }

    #[test]
    fn case3() {
        assert_eq!(run(&[], "").unwrap(), "count=0\n");
    }

    #[test]
    fn case4() {
        assert!(matches!(run(&[], "1\nx\n"), Err(StatsError::Line(2, _))));
        assert_eq!(
            run(&[], "9223372036854775807\n1\n"),
            Err(StatsError::Overflow)
        );
        assert!(matches!(
            run(&["--col", "3"], "1,2\n"),
            Err(StatsError::Line(1, _))
        ));
    }

    #[test]
    fn case5() {
        assert!(parse_args(&a(&["--col", "0"])).is_err());
        assert!(parse_args(&a(&["--col"])).is_err());
        assert!(parse_args(&a(&["--sep", "ab"])).is_err());
        assert!(parse_args(&a(&["--bogus"])).is_err());
    }
}
