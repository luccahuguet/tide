use std::collections::BTreeMap;
use std::fs::Fs;
use std::io;

const FILE: &str = "store.kv";
const TMP: &str = "store.kv.tmp";

/// A key-value store persisted to `store.kv` by atomic replace.
pub struct Store {
    fs: Fs,
    map: BTreeMap<String, String>,
}

fn parse(text: &str) -> io::Result<BTreeMap<String, String>> {
    let mut map = BTreeMap::new();
    for line in text.split('\n') {
        if line.is_empty() {
            continue;
        }
        match line.split_once('\t') {
            Some((k, v)) => {
                map.insert(k.to_string(), v.to_string());
            }
            None => {
                return Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    "store.kv: line without a tab",
                ));
            }
        }
    }
    Ok(map)
}

fn render(map: &BTreeMap<String, String>) -> String {
    let mut out = String::new();
    for (k, v) in map {
        out.push_str(k);
        out.push('\t');
        out.push_str(v);
        out.push('\n');
    }
    out
}

impl Store {
    /// Loads `store.kv` from the directory `fs`, if it exists.
    pub fn open(fs: &Fs) -> io::Result<Store> {
        let map = match fs.read_to_string(FILE) {
            Ok(text) => parse(&text)?,
            Err(e) if e.kind() == io::ErrorKind::NotFound => BTreeMap::new(),
            Err(e) => return Err(e),
        };
        Ok(Store { fs: fs.clone(), map })
    }

    pub fn get(&self, key: &str) -> Option<&str> {
        self.map.get(key).map(|v| v.as_str())
    }

    pub fn set(&mut self, key: &str, value: &str) -> io::Result<()> {
        if key.contains('\t') || key.contains('\n') {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "key may not contain tab or newline",
            ));
        }
        if value.contains('\n') {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "value may not contain newline",
            ));
        }
        let mut next = self.map.clone();
        next.insert(key.to_string(), value.to_string());
        self.save(&next)?;
        self.map = next;
        Ok(())
    }

    pub fn remove(&mut self, key: &str) -> io::Result<bool> {
        if !self.map.contains_key(key) {
            return Ok(false);
        }
        let mut next = self.map.clone();
        next.remove(key);
        self.save(&next)?;
        self.map = next;
        Ok(true)
    }

    fn save(&self, map: &BTreeMap<String, String>) -> io::Result<()> {
        self.fs.write_synced(TMP, render(map))?;
        self.fs.rename(TMP, FILE)?;
        self.fs.sync_dir(".")?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs::Mode;
    use std::sim::SimRoot;

    #[sim_test(seeds = 5)]
    fn set_and_reopen(sim: SimRoot) {
        {
            let mut s = Store::open(&sim.fs).unwrap();
            s.set("b", "2").unwrap();
            s.set("a", "1").unwrap();
        }
        let s = Store::open(&sim.fs).unwrap();
        assert_eq!(s.get("a"), Some("1"));
        assert_eq!(s.get("b"), Some("2"));
        assert_eq!(s.get("c"), None);
        assert_eq!(sim.fs.read_to_string("store.kv").unwrap(), "a\t1\nb\t2\n");
    }

    #[sim_test(seeds = 5)]
    fn remove_survives(sim: SimRoot) {
        let mut s = Store::open(&sim.fs).unwrap();
        s.set("a", "1").unwrap();
        s.set("b", "2").unwrap();
        assert!(s.remove("a").unwrap());
        let mut s2 = Store::open(&sim.fs).unwrap();
        assert_eq!(s2.get("a"), None);
        assert!(!s2.remove("a").unwrap());
        assert_eq!(sim.fs.read_to_string("store.kv").unwrap(), "b\t2\n");
    }

    #[sim_test(seeds = 5)]
    fn invalid_input(sim: SimRoot) {
        let mut s = Store::open(&sim.fs).unwrap();
        s.set("a", "1").unwrap();
        let e = s.set("x\ny", "v").unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::InvalidInput);
        let e = s.set("x\ty", "v").unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::InvalidInput);
        let e = s.set("x", "v\nw").unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::InvalidInput);
        assert_eq!(s.get("x"), None);
        assert_eq!(sim.fs.read_to_string("store.kv").unwrap(), "a\t1\n");
    }

    #[sim_test(seeds = 5)]
    fn invalid_data(sim: SimRoot) {
        sim.world.file("/store.kv", "oops\n");
        match Store::open(&sim.fs) {
            Err(e) => assert_eq!(e.kind(), io::ErrorKind::InvalidData),
            Ok(_) => panic!("expected error"),
        }
    }

    #[sim_test(seeds = 5)]
    fn tmp_ignored(sim: SimRoot) {
        sim.world.file("/d/store.kv.tmp", "garbage no tab");
        let fs = sim.fs.dir("/d", Mode::ReadWrite).unwrap();
        let mut s = Store::open(&fs).unwrap();
        s.set("k", "v").unwrap();
        assert!(!fs.exists("store.kv.tmp").unwrap());
        assert_eq!(fs.read_to_string("store.kv").unwrap(), "k\tv\n");
    }
}
