use std::cmp::Ordering;
use std::f64::consts::PI;

pub trait Shape {
    fn area(&self) -> f64;
    fn perimeter(&self) -> f64;
    fn name(&self) -> &str;
}

fn valid(x: f64) -> bool {
    x.is_finite() && x > 0.0
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Circle {
    r: f64,
}

impl Circle {
    pub fn new(r: f64) -> Option<Self> {
        valid(r).then_some(Circle { r })
    }
}

impl Shape for Circle {
    fn area(&self) -> f64 {
        PI * self.r * self.r
    }
    fn perimeter(&self) -> f64 {
        2.0 * PI * self.r
    }
    fn name(&self) -> &str {
        "circle"
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Rect {
    w: f64,
    h: f64,
}

impl Rect {
    pub fn new(w: f64, h: f64) -> Option<Self> {
        (valid(w) && valid(h)).then_some(Rect { w, h })
    }
}

impl Shape for Rect {
    fn area(&self) -> f64 {
        self.w * self.h
    }
    fn perimeter(&self) -> f64 {
        2.0 * (self.w + self.h)
    }
    fn name(&self) -> &str {
        "rect"
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Triangle {
    a: f64,
    b: f64,
    c: f64,
}

impl Triangle {
    pub fn new(a: f64, b: f64, c: f64) -> Option<Self> {
        if !(valid(a) && valid(b) && valid(c)) {
            return None;
        }
        if a + b > c && a + c > b && b + c > a {
            Some(Triangle { a, b, c })
        } else {
            None
        }
    }
}

impl Shape for Triangle {
    fn area(&self) -> f64 {
        let s = (self.a + self.b + self.c) / 2.0;
        let p = s * (s - self.a) * (s - self.b) * (s - self.c);
        p.max(0.0).sqrt()
    }
    fn perimeter(&self) -> f64 {
        self.a + self.b + self.c
    }
    fn name(&self) -> &str {
        "triangle"
    }
}

pub fn largest(shapes: &[Box<dyn Shape>]) -> Option<&dyn Shape> {
    let mut best: Option<&dyn Shape> = None;
    for s in shapes {
        match best {
            Some(b) if !(s.area() > b.area()) => {}
            _ => best = Some(s.as_ref()),
        }
    }
    best
}

pub fn sort_by_area(shapes: &mut [Box<dyn Shape>]) {
    shapes.sort_by(|a, b| a.area().partial_cmp(&b.area()).unwrap_or(Ordering::Equal));
}

pub fn total_area(shapes: &[Box<dyn Shape>]) -> f64 {
    shapes.iter().map(|s| s.area()).sum()
}

pub fn describe(s: &dyn Shape) -> String {
    format!(
        "{}: area {:.2}, perimeter {:.2}",
        s.name(),
        s.area(),
        s.perimeter()
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn areas() {
        assert!((Circle::new(1.0).unwrap().area() - PI).abs() < 1e-9);
        assert!((Triangle::new(3.0, 4.0, 5.0).unwrap().area() - 6.0).abs() < 1e-9);
    }

    #[test]
    fn describe_rect() {
        assert_eq!(
            describe(&Rect::new(2.0, 3.0).unwrap()),
            "rect: area 6.00, perimeter 10.00"
        );
    }

    #[test]
    fn invalid() {
        assert!(Triangle::new(1.0, 2.0, 3.0).is_none());
        assert!(Circle::new(f64::NAN).is_none());
        assert!(Rect::new(0.0, 1.0).is_none());
        assert!(Rect::new(f64::INFINITY, 1.0).is_none());
    }

    #[test]
    fn largest_cases() {
        assert!(largest(&[]).is_none());
        let v: Vec<Box<dyn Shape>> = vec![
            Box::new(Circle::new(1.0).unwrap()),
            Box::new(Rect::new(2.0, 3.0).unwrap()),
            Box::new(Rect::new(1.0, 6.0).unwrap()),
        ];
        let l = largest(&v).unwrap();
        assert!((l.perimeter() - 10.0).abs() < 1e-9);
    }

    #[test]
    fn sorting() {
        let mut v: Vec<Box<dyn Shape>> = vec![
            Box::new(Rect::new(2.0, 3.0).unwrap()),
            Box::new(Circle::new(1.0).unwrap()),
            Box::new(Triangle::new(3.0, 4.0, 5.0).unwrap()),
        ];
        sort_by_area(&mut v);
        let names: Vec<&str> = v.iter().map(|s| s.name()).collect();
        assert_eq!(names, ["circle", "rect", "triangle"]);
        assert!((total_area(&v) - (12.0 + PI)).abs() < 1e-9);
    }
}
