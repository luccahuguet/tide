use std::fs::{Fs, OpenOptions};
use std::io::{self, Write};

const CURRENT: &str = "current.log";
const OLD1: &str = "old.1.log";
const OLD2: &str = "old.2.log";

pub struct RotLog {
    fs: Fs,
    max_bytes: u64,
    size: u64,
}

impl RotLog {
    pub fn open(fs: &Fs, max_bytes: u64) -> io::Result<RotLog> {
        let size = match fs.metadata(CURRENT) {
            Ok(m) => m.len(),
            Err(e) if e.kind() == io::ErrorKind::NotFound => 0,
            Err(e) => return Err(e),
        };
        Ok(RotLog { fs: fs.clone(), max_bytes, size })
    }

    pub fn append(&mut self, line: &str) -> io::Result<()> {
        if line.contains('\n') {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "line contains a newline",
            ));
        }
        let len = line.len() as u64 + 1;
        if self.size > 0 && self.size.saturating_add(len) > self.max_bytes {
            self.rotate()?;
        }
        let mut f = self
            .fs
            .open_with(CURRENT, OpenOptions::new().append(true).create(true))?;
        let mut buf = Vec::with_capacity(line.len() + 1);
        buf.extend_from_slice(line.as_bytes());
        buf.push(b'\n');
        f.write_all(&buf)?;
        self.size = self.size.saturating_add(len);
        Ok(())
    }

    fn rotate(&mut self) -> io::Result<()> {
        if self.fs.exists(OLD1) {
            self.fs.rename(OLD1, OLD2)?;
        }
        if self.fs.exists(CURRENT) {
            self.fs.rename(CURRENT, OLD1)?;
        }
        self.size = 0;
        Ok(())
    }
}

pub fn read_all(fs: &Fs) -> io::Result<Vec<String>> {
    let mut out = Vec::new();
    for name in [OLD2, OLD1, CURRENT] {
        match fs.read_to_string(name) {
            Ok(text) => {
                for l in text.lines() {
                    out.push(l.to_string());
                }
            }
            Err(e) if e.kind() == io::ErrorKind::NotFound => {}
            Err(e) => return Err(e),
        }
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    #[sim_test(seeds = 20)]
    fn case1_and_2(sim: SimRoot) {
        let mut log = RotLog::open(&sim.fs, 10).unwrap();
        log.append("aaaa").unwrap();
        log.append("bbbb").unwrap();
        log.append("cc").unwrap();
        assert_eq!(sim.fs.read_to_string("old.1.log").unwrap(), "aaaa\nbbbb\n");
        assert_eq!(sim.fs.read_to_string("current.log").unwrap(), "cc\n");
        assert_eq!(read_all(&sim.fs).unwrap(), vec!["aaaa", "bbbb", "cc"]);
        log.append("dddddddd").unwrap();
        log.append("e").unwrap();
        assert_eq!(read_all(&sim.fs).unwrap(), vec!["cc", "dddddddd", "e"]);
    }

    #[sim_test(seeds = 20)]
    fn newline_rejected(sim: SimRoot) {
        let mut log = RotLog::open(&sim.fs, 10).unwrap();
        log.append("aaaa").unwrap();
        let e = log.append("a\nb").unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::InvalidInput);
        assert_eq!(sim.fs.read_to_string("current.log").unwrap(), "aaaa\n");
        assert!(!sim.fs.exists("old.1.log"));
    }

    #[sim_test(seeds = 20)]
    fn long_line(sim: SimRoot) {
        let mut log = RotLog::open(&sim.fs, 10).unwrap();
        let long = "x".repeat(20);
        log.append(&long).unwrap();
        assert_eq!(sim.fs.read_to_string("current.log").unwrap().len(), 21);
        log.append("y").unwrap();
        assert_eq!(sim.fs.read_to_string("old.1.log").unwrap().len(), 21);
        assert_eq!(sim.fs.read_to_string("current.log").unwrap(), "y\n");
    }

    #[sim_test(seeds = 20)]
    fn reopen(sim: SimRoot) {
        {
            let mut log = RotLog::open(&sim.fs, 10).unwrap();
            log.append("a").unwrap();
        }
        let mut log = RotLog::open(&sim.fs, 10).unwrap();
        log.append("b").unwrap();
        assert_eq!(sim.fs.read_to_string("current.log").unwrap(), "a\nb\n");
    }

    #[sim_test(seeds = 20)]
    fn reopen_counts_size(sim: SimRoot) {
        sim.world.file("current.log", "123456789\n");
        let mut log = RotLog::open(&sim.fs, 10).unwrap();
        log.append("z").unwrap();
        assert_eq!(sim.fs.read_to_string("old.1.log").unwrap(), "123456789\n");
        assert_eq!(sim.fs.read_to_string("current.log").unwrap(), "z\n");
    }
}
