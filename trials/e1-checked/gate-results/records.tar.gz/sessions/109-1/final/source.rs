use std::collections::HashMap;
use std::io::Write;

/// Parse a defaults file's contents. Errors carry (line number, reason).
fn parse_defaults(text: &str) -> Result<HashMap<String, String>, (usize, String)> {
    let mut map = HashMap::new();
    for (i, raw) in text.split('\n').enumerate() {
        let line = raw.strip_suffix('\r').unwrap_or(raw);
        if line.trim().is_empty() || line.trim_start().starts_with('#') {
            continue;
        }
        let Some((k, v)) = line.split_once('=') else {
            return Err((i + 1, "missing '='".to_string()));
        };
        let key = k.trim();
        if key.is_empty() {
            return Err((i + 1, "empty key".to_string()));
        }
        map.insert(key.to_string(), v.to_string());
    }
    Ok(map)
}

/// Returns (stdout, stderr, exit code).
fn run(
    args: &[String],
    env: &dyn Fn(&str) -> Option<String>,
    read: &dyn Fn(&str) -> std::io::Result<String>,
) -> (String, String, i32) {
    const USAGE: &str = "usage: envreport [--defaults FILE] NAME...\n";
    let mut defaults_file: Option<String> = None;
    let mut names = Vec::new();
    let mut i = 0;
    while i < args.len() {
        if args[i] == "--defaults" {
            match args.get(i + 1) {
                Some(f) => defaults_file = Some(f.clone()),
                None => return (String::new(), USAGE.to_string(), 2),
            }
            i += 2;
        } else {
            names.push(args[i].clone());
            i += 1;
        }
    }
    if names.is_empty() {
        return (String::new(), USAGE.to_string(), 2);
    }
    let defaults = match &defaults_file {
        None => HashMap::new(),
        Some(f) => {
            let text = match read(f) {
                Ok(t) => t,
                Err(e) => return (String::new(), format!("envreport: {f}: {e}\n"), 2),
            };
            match parse_defaults(&text) {
                Ok(m) => m,
                Err((l, r)) => return (String::new(), format!("envreport: {f}:{l}: {r}\n"), 2),
            }
        }
    };
    let mut out = String::new();
    let mut code = 0;
    for n in &names {
        match env(n).or_else(|| defaults.get(n).cloned()) {
            Some(v) => out.push_str(&format!("{n}={v}\n")),
            None => {
                out.push_str(&format!("{n} is unset\n"));
                code = 1;
            }
        }
    }
    (out, String::new(), code)
}

fn main() {
    let args: Vec<String> = std::env::args_os()
        .skip(1)
        .map(|a| a.to_string_lossy().into_owned())
        .collect();
    let env = |n: &str| -> Option<String> {
        if n.is_empty() || n.contains('=') || n.contains('\0') {
            return None;
        }
        std::env::var_os(n).and_then(|v| v.into_string().ok())
    };
    let read = |p: &str| std::fs::read_to_string(p);
    let (out, err, code) = run(&args, &env, &read);
    let _ = std::io::stdout().write_all(out.as_bytes());
    let _ = std::io::stderr().write_all(err.as_bytes());
    std::process::exit(code);
}

#[cfg(test)]
mod tests {
    use super::*;

    fn a(s: &[&str]) -> Vec<String> {
        s.iter().map(|x| x.to_string()).collect()
    }
    fn env_a(n: &str) -> Option<String> {
        (n == "A").then(|| "1".to_string())
    }
    fn file(p: &str) -> std::io::Result<String> {
        match p {
            "d.env" => Ok("B=two\n# c\nA=zzz\n\nC=x=y\n".into()),
            "bad.env" => Ok("oops\n".into()),
            "empty.env" => Ok("X=1\n =2\n".into()),
            _ => Err(std::io::Error::new(std::io::ErrorKind::NotFound, "not found")),
        }
    }

    #[test]
    fn case1() {
        assert_eq!(run(&a(&["A", "B"]), &env_a, &file), ("A=1\nB is unset\n".into(), "".into(), 1));
    }
    #[test]
    fn case2() {
        let r = run(&a(&["--defaults", "d.env", "A", "B", "C"]), &env_a, &file);
        assert_eq!(r, ("A=1\nB=two\nC=x=y\n".into(), "".into(), 0));
    }
    #[test]
    fn case3() {
        let r = run(&a(&["--defaults", "nope.env", "A"]), &env_a, &file);
        assert!(r.1.starts_with("envreport: nope.env: "));
        assert_eq!((r.0.as_str(), r.2), ("", 2));
    }
    #[test]
    fn case4() {
        let r = run(&a(&["--defaults", "bad.env", "A"]), &env_a, &file);
        assert!(r.1.starts_with("envreport: bad.env:1: "));
        assert_eq!(r.2, 2);
        let r = run(&a(&["--defaults", "empty.env", "A"]), &env_a, &file);
        assert!(r.1.starts_with("envreport: empty.env:2: "));
    }
    #[test]
    fn case5() {
        let r = run(&[], &env_a, &file);
        assert!(r.1.starts_with("usage: envreport"));
        assert_eq!(r.2, 2);
        let r = run(&a(&["--defaults", "d.env"]), &env_a, &file);
        assert_eq!(r.2, 2);
    }
    #[test]
    fn key_trimmed_value_kept() {
        let m = parse_defaults("  K  = v \n").unwrap();
        assert_eq!(m["K"], " v ");
    }
}
