use std::collections::BTreeMap;
use std::fs::Fs;
use std::io;

const FILE: &str = "store.kv";
const TMP: &str = "store.kv.tmp";

pub struct Store {
    fs: Fs,
    map: BTreeMap<String, String>,
}

impl Store {
    pub fn open(fs: &Fs) -> io::Result<Store> {
        let mut map = BTreeMap::new();
        match fs.read_to_string(FILE) {
            Ok(text) => {
                for line in text.lines() {
                    match line.split_once('\t') {
                        Some((k, v)) => {
                            map.insert(k.to_string(), v.to_string());
                        }
                        None => {
                            return Err(io::Error::new(
                                io::ErrorKind::InvalidData,
                                "line without a tab in store.kv",
                            ));
                        }
                    }
                }
            }
            Err(e) if e.kind() == io::ErrorKind::NotFound => {}
            Err(e) => return Err(e),
        }
        Ok(Store { fs: fs.clone(), map })
    }

    pub fn get(&self, key: &str) -> Option<&str> {
        self.map.get(key).map(|v| v.as_str())
    }

    pub fn set(&mut self, key: &str, value: &str) -> io::Result<()> {
        if key.contains('\t') || key.contains('\n') {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "key may not contain tab or newline",
            ));
        }
        if value.contains('\n') {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "value may not contain newline",
            ));
        }
        let old = self.map.insert(key.to_string(), value.to_string());
        if let Err(e) = self.save() {
            match old {
                Some(v) => {
                    self.map.insert(key.to_string(), v);
                }
                None => {
                    self.map.remove(key);
                }
            }
            return Err(e);
        }
        Ok(())
    }

    pub fn remove(&mut self, key: &str) -> io::Result<bool> {
        match self.map.remove(key) {
            None => Ok(false),
            Some(v) => {
                if let Err(e) = self.save() {
                    self.map.insert(key.to_string(), v);
                    return Err(e);
                }
                Ok(true)
            }
        }
    }

    fn save(&self) -> io::Result<()> {
        let mut out = String::new();
        for (k, v) in &self.map {
            out.push_str(k);
            out.push('\t');
            out.push_str(v);
            out.push('\n');
        }
        self.fs.write_synced(TMP, out.as_bytes())?;
        self.fs.rename(TMP, FILE)?;
        self.fs.sync_dir(".")?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    #[sim_test(seeds = 20)]
    fn set_and_reopen(sim: SimRoot) {
        {
            let mut s = Store::open(&sim.fs).unwrap();
            s.set("b", "2").unwrap();
            s.set("a", "1").unwrap();
        }
        let s = Store::open(&sim.fs).unwrap();
        assert_eq!(s.get("a"), Some("1"));
        assert_eq!(s.get("b"), Some("2"));
        assert_eq!(s.get("c"), None);
        assert_eq!(sim.fs.read_to_string("store.kv").unwrap(), "a\t1\nb\t2\n");
    }

    #[sim_test(seeds = 20)]
    fn remove_survives(sim: SimRoot) {
        {
            let mut s = Store::open(&sim.fs).unwrap();
            s.set("a", "1").unwrap();
            s.set("b", "2").unwrap();
            assert!(s.remove("a").unwrap());
            assert!(!s.remove("zz").unwrap());
        }
        let mut s = Store::open(&sim.fs).unwrap();
        assert_eq!(s.get("a"), None);
        assert!(!s.remove("a").unwrap());
        assert_eq!(sim.fs.read_to_string("store.kv").unwrap(), "b\t2\n");
    }

    #[sim_test(seeds = 20)]
    fn invalid_input(sim: SimRoot) {
        let mut s = Store::open(&sim.fs).unwrap();
        s.set("a", "1").unwrap();
        let e = s.set("x\ny", "v").unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::InvalidInput);
        let e = s.set("x\ty", "v").unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::InvalidInput);
        let e = s.set("k", "a\nb").unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::InvalidInput);
        assert_eq!(sim.fs.read_to_string("store.kv").unwrap(), "a\t1\n");
        assert_eq!(s.get("k"), None);
    }

    #[sim_test(seeds = 20)]
    fn invalid_data(sim: SimRoot) {
        sim.world.file("store.kv", "oops\n");
        match Store::open(&sim.fs) {
            Err(e) => assert_eq!(e.kind(), io::ErrorKind::InvalidData),
            Ok(_) => panic!("expected error"),
        }
    }

    #[sim_test(seeds = 20)]
    fn garbage_tmp(sim: SimRoot) {
        sim.world.file("store.kv.tmp", "garbage without tab\n\x00");
        let mut s = Store::open(&sim.fs).unwrap();
        s.set("k", "v").unwrap();
        match sim.fs.read("store.kv.tmp") {
            Err(e) => assert_eq!(e.kind(), io::ErrorKind::NotFound),
            Ok(_) => panic!("tmp remains"),
        }
        assert_eq!(sim.fs.read_to_string("store.kv").unwrap(), "k\tv\n");
    }
}
