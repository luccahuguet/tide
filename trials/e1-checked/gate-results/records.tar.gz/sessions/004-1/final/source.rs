use std::collections::HashMap;

/// An index of the anagram classes of the words in one text.
pub struct AnagramIndex<'a> {
    /// Classes in order of their first word's first occurrence; each lists
    /// its distinct words in order of first occurrence.
    classes: Vec<Vec<&'a str>>,
    /// Sorted lowercased letters -> index into `classes`.
    by_key: HashMap<Vec<u8>, usize>,
}

fn key_of(word: &str) -> Vec<u8> {
    let mut k: Vec<u8> = word.bytes().map(|b| b.to_ascii_lowercase()).collect();
    k.sort_unstable();
    k
}

impl<'a> AnagramIndex<'a> {
    pub fn new(text: &'a str) -> Self {
        let mut classes: Vec<Vec<&'a str>> = Vec::new();
        let mut by_key: HashMap<Vec<u8>, usize> = HashMap::new();
        let bytes = text.as_bytes();
        let mut i = 0;
        while i < bytes.len() {
            if !bytes[i].is_ascii_alphabetic() {
                i += 1;
                continue;
            }
            let start = i;
            while i < bytes.len() && bytes[i].is_ascii_alphabetic() {
                i += 1;
            }
            let word: &'a str = &text[start..i];
            let key = key_of(word);
            match by_key.get(&key) {
                Some(&ci) => {
                    if !classes[ci].contains(&word) {
                        classes[ci].push(word);
                    }
                }
                None => {
                    by_key.insert(key, classes.len());
                    classes.push(vec![word]);
                }
            }
        }
        AnagramIndex { classes, by_key }
    }

    pub fn groups(&self) -> Vec<Vec<&'a str>> {
        self.classes
            .iter()
            .filter(|c| c.len() >= 2)
            .cloned()
            .collect()
    }

    pub fn partners(&self, word: &str) -> Vec<&'a str> {
        match self.by_key.get(&key_of(word)) {
            Some(&ci) => self.classes[ci]
                .iter()
                .copied()
                .filter(|w| *w != word)
                .collect(),
            None => Vec::new(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn case1() {
        let idx = AnagramIndex::new("listen silent enlist google tinsel");
        assert_eq!(idx.groups(), vec![vec!["listen", "silent", "enlist", "tinsel"]]);
    }

    #[test]
    fn case2() {
        let idx = AnagramIndex::new("Dusty study, night thing; dusty");
        assert_eq!(
            idx.groups(),
            vec![vec!["Dusty", "study", "dusty"], vec!["night", "thing"]]
        );
        assert_eq!(idx.partners("dusty"), vec!["Dusty", "study"]);
    }

    #[test]
    fn case3() {
        assert!(AnagramIndex::new("").groups().is_empty());
        assert!(AnagramIndex::new("abc def").groups().is_empty());
    }

    #[test]
    fn case4_slices_outlive_index() {
        let text = String::from("listen silent");
        let g;
        {
            let idx = AnagramIndex::new(&text);
            g = idx.groups();
        }
        assert_eq!(g, vec![vec!["listen", "silent"]]);
    }

    #[test]
    fn case5_partners() {
        let text = "listen silent enlist google tinsel";
        let r;
        {
            let idx = AnagramIndex::new(text);
            {
                let w = String::from("listen");
                r = idx.partners(&w);
            }
        }
        assert_eq!(r, vec!["silent", "enlist", "tinsel"]);
        assert!(AnagramIndex::new(text).partners("xyz").is_empty());
        assert_eq!(AnagramIndex::new(text).partners("Silent"), vec!["listen", "silent", "enlist", "tinsel"]);
    }
}
