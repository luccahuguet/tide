//! Sentences of a text, borrowed from it.

#[derive(Debug, Clone, Copy)]
pub struct Doc<'a> {
    text: &'a str,
}

/// Lazy iterator over the sentences of a text.
#[derive(Debug, Clone)]
pub struct Sentences<'a> {
    rest: &'a str,
}

/// Lazy iterator over the sentences containing a given word.
#[derive(Debug, Clone)]
pub struct WithWord<'a, 'w> {
    inner: Sentences<'a>,
    word: &'w str,
}

fn is_end(c: char) -> bool {
    c == '.' || c == '!' || c == '?'
}

fn sentence_end(s: &str) -> usize {
    for (i, c) in s.char_indices() {
        if is_end(c) {
            let after = i + c.len_utf8();
            match s[after..].chars().next() {
                None => return after,
                Some(n) if n.is_whitespace() => return after,
                _ => {}
            }
        }
    }
    s.len()
}

fn words(s: &str) -> impl Iterator<Item = &str> {
    s.split_whitespace()
        .map(|w| w.trim_matches(|c: char| c.is_ascii_punctuation()))
        .filter(|w| !w.is_empty())
}

impl<'a> Iterator for Sentences<'a> {
    type Item = &'a str;
    fn next(&mut self) -> Option<&'a str> {
        loop {
            if self.rest.is_empty() {
                return None;
            }
            let rest = self.rest;
            let end = sentence_end(rest);
            let piece = &rest[..end];
            self.rest = &rest[end..];
            let t = piece.trim();
            if !t.is_empty() {
                return Some(t);
            }
        }
    }
}

impl<'a, 'w> Iterator for WithWord<'a, 'w> {
    type Item = &'a str;
    fn next(&mut self) -> Option<&'a str> {
        let word = self.word;
        self.inner
            .by_ref()
            .find(|s| words(s).any(|w| w.eq_ignore_ascii_case(word)))
    }
}

impl<'a> Doc<'a> {
    pub fn new(text: &'a str) -> Self {
        Doc { text }
    }

    pub fn sentences(&self) -> Sentences<'a> {
        Sentences { rest: self.text }
    }

    pub fn longest(&self) -> Option<&'a str> {
        let mut best: Option<(&'a str, usize)> = None;
        for s in self.sentences() {
            let n = s.chars().count();
            match best {
                Some((_, m)) if m >= n => {}
                _ => best = Some((s, n)),
            }
        }
        best.map(|(s, _)| s)
    }

    pub fn words_of(&self, i: usize) -> Option<Vec<&'a str>> {
        let s = self.sentences().nth(i)?;
        Some(words(s).collect())
    }

    pub fn with_word<'w>(&self, word: &'w str) -> WithWord<'a, 'w> {
        WithWord { inner: self.sentences(), word }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const T1: &str = "Hi there. How are you? Fine!";

    #[test]
    fn splits() {
        let v: Vec<&str> = Doc::new(T1).sentences().collect();
        assert_eq!(v, vec!["Hi there.", "How are you?", "Fine!"]);
        let v: Vec<&str> = Doc::new("a.b. c").sentences().collect();
        assert_eq!(v, vec!["a.b.", "c"]);
        let v: Vec<&str> = Doc::new("No end").sentences().collect();
        assert_eq!(v, vec!["No end"]);
        assert_eq!(Doc::new("   ").sentences().count(), 0);
        assert_eq!(Doc::new("").sentences().count(), 0);
    }

    #[test]
    fn longest_and_words() {
        assert_eq!(Doc::new("ab. cd. e.").longest(), Some("ab."));
        assert_eq!(Doc::new("  ").longest(), None);
        let d = Doc::new(T1);
        assert_eq!(d.words_of(1), Some(vec!["How", "are", "you"]));
        assert_eq!(d.words_of(9), None);
        assert_eq!(Doc::new("(hi), --- there!").words_of(0), Some(vec!["hi", "there"]));
    }

    #[test]
    fn with_word_works() {
        let v: Vec<&str> = Doc::new(T1).with_word("HI").collect();
        assert_eq!(v, vec!["Hi there."]);
        assert_eq!(Doc::new(T1).with_word("nope").count(), 0);
    }

    #[test]
    fn outlives_doc() {
        let text = String::from(T1);
        let word = String::from("fine");
        let it;
        let ww;
        {
            let d = Doc::new(&text);
            it = d.sentences();
            ww = d.with_word(&word);
        }
        assert_eq!(it.count(), 3);
        let v: Vec<&str> = ww.collect();
        assert_eq!(v, vec!["Fine!"]);
    }
}
