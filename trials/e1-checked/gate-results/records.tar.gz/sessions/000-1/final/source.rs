use std::sync::atomic::{AtomicUsize, Ordering};
use std::thread;

const CHUNK: usize = 4096;

fn count_chunk(chunk: &[u32], edges: &[u32], counts: &mut [u64]) {
    for &v in chunk {
        let idx = edges.partition_point(|&e| e <= v);
        if idx > 0 && idx < edges.len() {
            counts[idx - 1] += 1;
        }
    }
}

/// Parallel histogram: bucket `i` counts values with `edges[i] <= v < edges[i+1]`.
pub fn histogram(values: &[u32], edges: &[u32]) -> Vec<u64> {
    assert!(edges.len() >= 2, "edges must have at least two entries");
    assert!(
        edges.windows(2).all(|w| w[0] < w[1]),
        "edges must increase strictly"
    );
    let buckets = edges.len() - 1;
    let chunks: Vec<&[u32]> = values.chunks(CHUNK).collect();
    if chunks.is_empty() {
        return vec![0; buckets];
    }
    let workers = thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(4)
        .min(chunks.len())
        .max(1);
    let next = AtomicUsize::new(0);
    let mut total = vec![0u64; buckets];
    thread::scope(|s| {
        let handles: Vec<_> = (0..workers)
            .map(|_| {
                let chunks = &chunks;
                let next = &next;
                s.spawn(move || {
                    let mut local = vec![0u64; buckets];
                    loop {
                        let i = next.fetch_add(1, Ordering::Relaxed);
                        if i >= chunks.len() {
                            break;
                        }
                        count_chunk(chunks[i], edges, &mut local);
                    }
                    local
                })
            })
            .collect();
        for h in handles {
            let local = h.join().expect("worker panicked");
            for (t, l) in total.iter_mut().zip(local) {
                *t += l;
            }
        }
    });
    total
}

#[cfg(test)]
mod tests {
    use super::*;

    fn xorshift(state: &mut u32) -> u32 {
        let mut x = *state;
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
        *state = x;
        x
    }

    #[test]
    fn basic() {
        assert_eq!(histogram(&[0, 1, 5, 9, 10, 99], &[0, 5, 10]), vec![2, 2]);
    }

    #[test]
    fn large_matches_sequential() {
        let mut s = 0x1234_5678u32;
        let values: Vec<u32> = (0..1_000_000).map(|_| xorshift(&mut s)).collect();
        let mut edges: Vec<u32> = (0..17).map(|_| xorshift(&mut s)).collect();
        edges.sort();
        edges.dedup();
        let mut expected = vec![0u64; edges.len() - 1];
        for &v in &values {
            for i in 0..edges.len() - 1 {
                if edges[i] <= v && v < edges[i + 1] {
                    expected[i] += 1;
                }
            }
        }
        assert_eq!(histogram(&values, &edges), expected);
    }

    #[test]
    fn empty() {
        assert_eq!(histogram(&[], &[1, 2, 3]), vec![0, 0]);
    }

    #[test]
    #[should_panic]
    fn equal_edges() {
        histogram(&[1], &[5, 5]);
    }

    #[test]
    #[should_panic]
    fn single_edge() {
        histogram(&[1], &[5]);
    }

    #[test]
    #[should_panic]
    fn decreasing_edges() {
        histogram(&[1], &[6, 5]);
    }
}
