//! In-place partition and selection.

/// Reorders `v` so every element `< pivot` precedes every other element.
/// Returns the number of elements less than `pivot`. Allocates nothing.
pub fn partition(v: &mut [i32], pivot: i32) -> usize {
    // Invariant: v[..store] < pivot, v[store..i] >= pivot.
    let mut store = 0;
    for i in 0..v.len() {
        if v[i] < pivot {
            v.swap(store, i);
            store += 1;
        }
    }
    store
}

/// Returns the `k`-th smallest element (0-based). Panics if `k >= v.len()`.
pub fn select_kth(v: &mut [i32], k: usize) -> i32 {
    assert!(k < v.len(), "k ({k}) must be less than len ({})", v.len());
    let mut lo = 0;
    let mut hi = v.len();
    // Invariant: lo <= k < hi, and the k-th smallest of v lies in v[lo..hi],
    // with v[..lo] <= every element of v[lo..hi] <= v[hi..].
    loop {
        let s = &mut v[lo..hi];
        let n = s.len();
        let (a, b, c) = (s[0], s[n / 2], s[n - 1]);
        let p = a.max(b).min(a.min(b).max(c)); // median of three, present in s
        let lt = partition(s, p);
        let r = k - lo;
        if r < lt {
            hi = lo + lt;
            continue;
        }
        let rest = &mut s[lt..];
        let eq = if p == i32::MAX {
            rest.len()
        } else {
            partition(rest, p + 1)
        };
        // eq >= 1 because p occurs in s.
        if r < lt + eq {
            return p;
        }
        lo += lt + eq;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sorted(v: &[i32]) -> Vec<i32> {
        let mut s = v.to_vec();
        s.sort();
        s
    }

    fn xorshift(n: usize, m: Option<u32>) -> Vec<i32> {
        let mut x: u32 = 2463534242;
        (0..n)
            .map(|_| {
                x ^= x << 13;
                x ^= x >> 17;
                x ^= x << 5;
                match m {
                    Some(m) => (x % m) as i32,
                    None => x as i32,
                }
            })
            .collect()
    }

    #[test]
    fn case1() {
        let orig = [3, 1, 4, 1, 5, 9, 2, 6];
        let mut v = orig;
        assert_eq!(partition(&mut v, 4), 4);
        assert!(v[..4].iter().all(|&x| x < 4));
        assert!(v[4..].iter().all(|&x| x >= 4));
        assert_eq!(sorted(&v), sorted(&orig));
    }

    #[test]
    fn case2() {
        let mut v = [5, 6, 7];
        assert_eq!(partition(&mut v, 5), 0);
        let mut e: [i32; 0] = [];
        assert_eq!(partition(&mut e, 5), 0);
    }

    #[test]
    fn case3() {
        for m in [None, Some(10), Some(2), Some(1)] {
            let orig = xorshift(10_000, m);
            let s = sorted(&orig);
            for k in [0, 1, 4999, 9999] {
                let mut v = orig.clone();
                assert_eq!(select_kth(&mut v, k), s[k]);
            }
        }
        let mut v = vec![i32::MAX, i32::MIN, i32::MAX, 0];
        assert_eq!(select_kth(&mut v, 3), i32::MAX);
        let mut v = vec![i32::MAX, i32::MIN, i32::MAX, 0];
        assert_eq!(select_kth(&mut v, 0), i32::MIN);
    }

    #[test]
    #[should_panic]
    fn case4() {
        let mut v = vec![1, 2, 3];
        select_kth(&mut v, 3);
    }
}
