use std::cmp::Reverse;
use std::collections::BinaryHeap;
use std::sync::mpsc::{Receiver, sync_channel};
use std::thread;

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum MergeError {
    #[error("input {input} is not sorted at index {index}")]
    Unsorted { input: usize, index: usize },
}

enum Msg {
    Item(i64),
    Unsorted(usize),
}

pub fn merge_streams(inputs: &[Vec<i64>], capacity: usize) -> Result<Vec<i64>, MergeError> {
    assert!(capacity > 0, "capacity must be positive");
    thread::scope(|s| {
        let mut receivers: Vec<Receiver<Msg>> = Vec::with_capacity(inputs.len());
        for input in inputs {
            let (tx, rx) = sync_channel::<Msg>(capacity);
            receivers.push(rx);
            s.spawn(move || {
                let mut prev: Option<i64> = None;
                for (idx, &v) in input.iter().enumerate() {
                    if let Some(p) = prev
                        && v < p
                    {
                        let _ = tx.send(Msg::Unsorted(idx));
                        return;
                    }
                    if tx.send(Msg::Item(v)).is_err() {
                        return;
                    }
                    prev = Some(v);
                }
            });
        }

        let mut errors: Vec<Option<usize>> = vec![None; receivers.len()];
        let mut heap: BinaryHeap<Reverse<(i64, usize)>> = BinaryHeap::new();
        let fetch = |i: usize,
                     heap: &mut BinaryHeap<Reverse<(i64, usize)>>,
                     errors: &mut Vec<Option<usize>>| {
            match receivers[i].recv() {
                Ok(Msg::Item(v)) => heap.push(Reverse((v, i))),
                Ok(Msg::Unsorted(idx)) => errors[i] = Some(idx),
                Err(_) => {}
            }
        };
        for i in 0..receivers.len() {
            fetch(i, &mut heap, &mut errors);
        }
        let mut out = Vec::new();
        while let Some(Reverse((v, i))) = heap.pop() {
            out.push(v);
            fetch(i, &mut heap, &mut errors);
        }
        if let Some((input, idx)) = errors
            .iter()
            .enumerate()
            .find_map(|(i, e)| e.map(|x| (i, x)))
        {
            return Err(MergeError::Unsorted { input, index: idx });
        }
        Ok(out)
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn basic() {
        let r = merge_streams(&[vec![1, 4, 9], vec![2, 3, 10], vec![], vec![5]], 1);
        assert_eq!(r, Ok(vec![1, 2, 3, 4, 5, 9, 10]));
        assert_eq!(merge_streams(&[], 1), Ok(vec![]));
        assert_eq!(merge_streams(&[vec![1, 1], vec![1]], 1), Ok(vec![1, 1, 1]));
    }

    #[test]
    fn many() {
        let inputs: Vec<Vec<i64>> = (0..8)
            .map(|k| (0..600).map(|i| i * 3 + k % 5).collect())
            .collect();
        let mut expected: Vec<i64> = inputs.concat();
        expected.sort();
        assert_eq!(merge_streams(&inputs, 2), Ok(expected));
    }

    #[test]
    fn unsorted() {
        assert_eq!(
            merge_streams(&[vec![1, 2], vec![3, 1], vec![5, 0]], 1),
            Err(MergeError::Unsorted { input: 1, index: 1 })
        );
    }

    #[test]
    #[should_panic]
    fn zero_cap() {
        let _ = merge_streams(&[vec![1]], 0);
    }
}
