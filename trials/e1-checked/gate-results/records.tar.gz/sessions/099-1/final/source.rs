//! Sentences of a text, borrowed from it.

/// A document borrowing its text.
#[derive(Debug, Clone, Copy)]
pub struct Doc<'a> {
    text: &'a str,
}

/// Lazy iterator over the sentences of a text.
#[derive(Debug, Clone)]
pub struct Sentences<'a> {
    rest: &'a str,
}

impl<'a> Iterator for Sentences<'a> {
    type Item = &'a str;

    fn next(&mut self) -> Option<&'a str> {
        while !self.rest.is_empty() {
            let rest = self.rest;
            let mut end = rest.len();
            let mut iter = rest.char_indices().peekable();
            while let Some((i, c)) = iter.next() {
                if matches!(c, '.' | '!' | '?') {
                    match iter.peek() {
                        None => {
                            end = i + c.len_utf8();
                            break;
                        }
                        Some(&(_, n)) if n.is_whitespace() => {
                            end = i + c.len_utf8();
                            break;
                        }
                        _ => {}
                    }
                }
            }
            let s = rest[..end].trim();
            self.rest = &rest[end..];
            if !s.is_empty() {
                return Some(s);
            }
        }
        None
    }
}

fn words(s: &str) -> impl Iterator<Item = &str> {
    s.split_whitespace()
        .map(|w| w.trim_matches(|c: char| c.is_ascii_punctuation()))
        .filter(|w| !w.is_empty())
}

impl<'a> Doc<'a> {
    pub fn new(text: &'a str) -> Self {
        Doc { text }
    }

    pub fn sentences(&self) -> Sentences<'a> {
        Sentences { rest: self.text }
    }

    pub fn longest(&self) -> Option<&'a str> {
        let mut best: Option<(&'a str, usize)> = None;
        for s in self.sentences() {
            let n = s.chars().count();
            if best.is_none_or(|(_, b)| n > b) {
                best = Some((s, n));
            }
        }
        best.map(|(s, _)| s)
    }

    pub fn words_of(&self, i: usize) -> Option<Vec<&'a str>> {
        self.sentences().nth(i).map(|s| words(s).collect())
    }

    pub fn with_word<'w>(&self, word: &'w str) -> impl Iterator<Item = &'a str> + use<'a, 'w> {
        self.sentences()
            .filter(move |s| words(s).any(|w| w.eq_ignore_ascii_case(word)))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn all(t: &str) -> Vec<&str> {
        Doc::new(t).sentences().collect()
    }

    #[test]
    fn case1() {
        assert_eq!(
            all("Hi there. How are you? Fine!"),
            ["Hi there.", "How are you?", "Fine!"]
        );
        assert_eq!(all("a.b. c"), ["a.b.", "c"]);
        assert_eq!(all("No end"), ["No end"]);
        assert!(all("   ").is_empty());
    }

    #[test]
    fn case2() {
        assert_eq!(Doc::new("ab. cd. e.").longest(), Some("ab."));
        let d = Doc::new("Hi there. How are you? Fine!");
        assert_eq!(d.words_of(1), Some(vec!["How", "are", "you"]));
        assert_eq!(d.words_of(9), None);
        assert_eq!(Doc::new("").longest(), None);
    }

    #[test]
    fn case3_4() {
        let text = String::from("Hi there. How are you? Fine!");
        let d = Doc::new(&text);
        assert_eq!(d.with_word("HI").collect::<Vec<_>>(), ["Hi there."]);
        let word = String::from("fine");
        let (it, w) = {
            let d = Doc::new(&text);
            (d.sentences(), d.with_word(&word))
        };
        assert_eq!(it.count(), 3);
        assert_eq!(w.collect::<Vec<_>>(), ["Fine!"]);
        let s = all(&text)[0];
        let p = text.as_ptr() as usize;
        assert!(s.as_ptr() as usize >= p && (s.as_ptr() as usize) < p + text.len());
    }
}
