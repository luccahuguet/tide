use std::collections::HashMap;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Mutex, MutexGuard};

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum ReserveError {
    #[error("unknown item: {0}")]
    UnknownItem(String),
    #[error("insufficient stock: {0}")]
    Insufficient(String),
}

pub struct Warehouse {
    items: HashMap<String, Mutex<u32>>,
}

fn lock(m: &Mutex<u32>) -> MutexGuard<'_, u32> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

impl Warehouse {
    pub fn new(stock: &[(&str, u32)]) -> Self {
        let mut items = HashMap::new();
        for &(name, qty) in stock {
            items.insert(name.to_string(), Mutex::new(qty));
        }
        Warehouse { items }
    }

    pub fn stock(&self, item: &str) -> Option<u32> {
        self.items.get(item).map(|m| *lock(m))
    }

    pub fn reserve(&self, order: &[(&str, u32)]) -> Result<(), ReserveError> {
        // Aggregate in order of first appearance.
        let mut needs: Vec<(&str, u64)> = Vec::new();
        for &(name, qty) in order {
            if let Some(e) = needs.iter_mut().find(|(n, _)| *n == name) {
                e.1 += qty as u64;
            } else {
                needs.push((name, qty as u64));
            }
        }
        // Lock known items in sorted order to avoid deadlock.
        let mut sorted: Vec<&str> = needs
            .iter()
            .map(|(n, _)| *n)
            .filter(|n| self.items.contains_key(*n))
            .collect();
        sorted.sort_unstable();
        let mut guards: HashMap<&str, MutexGuard<'_, u32>> = HashMap::new();
        for n in sorted {
            guards.insert(n, lock(&self.items[n]));
        }
        for &(name, need) in &needs {
            match guards.get(name) {
                None => return Err(ReserveError::UnknownItem(name.to_string())),
                Some(g) => {
                    if (**g as u64) < need {
                        return Err(ReserveError::Insufficient(name.to_string()));
                    }
                }
            }
        }
        for &(name, need) in &needs {
            let g = guards.get_mut(name).unwrap();
            **g -= need as u32;
        }
        Ok(())
    }
}

pub fn run_orders(
    w: &Warehouse,
    orders: &[Vec<(&str, u32)>],
    workers: usize,
) -> Vec<Result<(), ReserveError>> {
    let n = orders.len();
    let workers = workers.max(1).min(n.max(1));
    let next = AtomicUsize::new(0);
    let results: Vec<Mutex<Option<Result<(), ReserveError>>>> =
        (0..n).map(|_| Mutex::new(None)).collect();
    std::thread::scope(|s| {
        for _ in 0..workers {
            s.spawn(|| {
                loop {
                    let i = next.fetch_add(1, Ordering::SeqCst);
                    if i >= n {
                        break;
                    }
                    let r = w.reserve(&orders[i]);
                    *results[i].lock().unwrap_or_else(|e| e.into_inner()) = Some(r);
                }
            });
        }
    });
    results
        .into_iter()
        .map(|m| m.into_inner().unwrap_or_else(|e| e.into_inner()).unwrap())
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn basic() {
        let w = Warehouse::new(&[("a", 5), ("b", 2)]);
        assert_eq!(w.reserve(&[("a", 2), ("b", 2)]), Ok(()));
        assert_eq!(w.stock("a"), Some(3));
        assert_eq!(w.stock("b"), Some(0));
        assert_eq!(
            w.reserve(&[("a", 1), ("b", 1)]),
            Err(ReserveError::Insufficient("b".into()))
        );
        assert_eq!(w.stock("a"), Some(3));
        assert_eq!(
            w.reserve(&[("a", 2), ("a", 2)]),
            Err(ReserveError::Insufficient("a".into()))
        );
        assert_eq!(
            w.reserve(&[("z", 1)]),
            Err(ReserveError::UnknownItem("z".into()))
        );
        assert_eq!(w.stock("z"), None);
    }

    #[test]
    fn concurrent() {
        let w = Warehouse::new(&[("x", 600), ("y", 1000)]);
        let orders: Vec<Vec<(&str, u32)>> = (0..1000).map(|_| vec![("x", 1), ("y", 1)]).collect();
        let r = run_orders(&w, &orders, 8);
        assert_eq!(r.len(), 1000);
        assert_eq!(r.iter().filter(|r| r.is_ok()).count(), 600);
        assert_eq!(
            r.iter()
                .filter(|r| **r == Err(ReserveError::Insufficient("x".into())))
                .count(),
            400
        );
        assert_eq!(w.stock("x"), Some(0));
        assert_eq!(w.stock("y"), Some(400));
    }
}
