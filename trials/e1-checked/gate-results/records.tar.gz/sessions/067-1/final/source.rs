//! A parallel merge sort built on `std::par::join`.

use std::par::join;

const THRESHOLD: usize = 2048;

/// Sorts `v` ascending. Slices longer than 2048 elements are split in two,
/// the halves sorted in parallel, then merged.
pub fn sort_parallel(v: &mut [i64]) {
    if v.len() <= THRESHOLD {
        v.sort_unstable();
        return;
    }
    let mid = v.len() / 2;
    {
        let (left, right) = v.split_at_mut(mid);
        let ((), ()) = join(|| sort_parallel(left), || sort_parallel(right));
    }
    merge_i64(v, mid);
}

fn merge_i64(v: &mut [i64], mid: usize) {
    if v[mid - 1] <= v[mid] {
        return;
    }
    let left: Vec<i64> = v[..mid].to_vec();
    let mut i = 0;
    let mut j = mid;
    let mut k = 0;
    while i < left.len() && j < v.len() {
        if v[j] < left[i] {
            v[k] = v[j];
            j += 1;
        } else {
            v[k] = left[i];
            i += 1;
        }
        k += 1;
    }
    while i < left.len() {
        v[k] = left[i];
        i += 1;
        k += 1;
    }
    // Remaining right elements are already in place.
}

/// Sorts `v` stably by `key`, with the same parallel structure as
/// [`sort_parallel`].
pub fn sort_by_key_parallel<T, K, F>(v: &mut [T], key: F)
where
    T: Send + Pure,
    K: Ord,
    F: Fn(&T) -> K + Pure + Sync,
{
    sort_by_key_rec(v, &key);
}

fn sort_by_key_rec<T, K, F>(v: &mut [T], key: &F)
where
    T: Send + Pure,
    K: Ord,
    F: Fn(&T) -> K + Pure + Sync,
{
    if v.len() <= THRESHOLD {
        v.sort_by(|a, b| key(a).cmp(&key(b)));
        return;
    }
    let mid = v.len() / 2;
    {
        let (left, right) = v.split_at_mut(mid);
        let ((), ()) = join(|| sort_by_key_rec(left, key), || sort_by_key_rec(right, key));
    }
    merge_by_key(v, mid, key);
}

/// Stable merge of `v[..mid]` and `v[mid..]` (each sorted) without needing
/// `Clone`: compute the merged order as a permutation, then apply it in place.
fn merge_by_key<T, K, F>(v: &mut [T], mid: usize, key: &F)
where
    K: Ord,
    F: Fn(&T) -> K,
{
    let n = v.len();
    if key(&v[mid]) >= key(&v[mid - 1]) {
        return;
    }
    // perm[k] = index in the current slice of the element that belongs at k.
    let mut perm: Vec<usize> = Vec::with_capacity(n);
    let mut i = 0;
    let mut j = mid;
    while i < mid && j < n {
        // Take from the right only when strictly smaller: keeps stability.
        if key(&v[j]) < key(&v[i]) {
            perm.push(j);
            j += 1;
        } else {
            perm.push(i);
            i += 1;
        }
    }
    while i < mid {
        perm.push(i);
        i += 1;
    }
    while j < n {
        perm.push(j);
        j += 1;
    }
    let mut done = vec![false; n];
    for start in 0..n {
        if done[start] {
            continue;
        }
        let mut cur = start;
        loop {
            done[cur] = true;
            let next = perm[cur];
            if next == start {
                break;
            }
            v.swap(cur, next);
            cur = next;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn xorshift(n: usize) -> Vec<i64> {
        let mut x: u64 = 0x9E37_79B9_7F4A_7C15;
        let mut out = Vec::with_capacity(n);
        for _ in 0..n {
            x ^= x << 13;
            x ^= x >> 7;
            x ^= x << 17;
            out.push(x.cast_signed());
        }
        out
    }

    #[test]
    fn million_matches_std() {
        let mut v = xorshift(1_000_000);
        let mut expected = v.clone();
        expected.sort();
        sort_parallel(&mut v);
        assert_eq!(v, expected);
    }

    #[test]
    fn small_ranges_with_duplicates() {
        let mut v: Vec<i64> = xorshift(50_000).iter().map(|x| x % 100).collect();
        let mut expected = v.clone();
        expected.sort();
        sort_parallel(&mut v);
        assert_eq!(v, expected);
    }

    #[test]
    fn edge_cases() {
        let mut e: Vec<i64> = vec![];
        sort_parallel(&mut e);
        assert!(e.is_empty());
        let mut one = vec![5i64];
        sort_parallel(&mut one);
        assert_eq!(one, vec![5]);
        let mut same = vec![3i64; 10_000];
        sort_parallel(&mut same);
        assert_eq!(same, vec![3i64; 10_000]);

        let mut e2: Vec<(i64, i64)> = vec![];
        sort_by_key_parallel(&mut e2, |p: &(i64, i64)| p.0);
        assert!(e2.is_empty());
        let mut one2 = vec![(1i64, 2i64)];
        sort_by_key_parallel(&mut one2, |p: &(i64, i64)| p.0);
        assert_eq!(one2, vec![(1, 2)]);
        let mut same2: Vec<(i64, i64)> = (0..10_000).map(|i| (4, i)).collect();
        let expected2 = same2.clone();
        sort_by_key_parallel(&mut same2, |p: &(i64, i64)| p.0);
        assert_eq!(same2, expected2);
    }

    #[test]
    fn stable_by_key() {
        let mut v: Vec<(i64, i64)> = (0..100_000i64).map(|i| (i % 7, i)).collect();
        sort_by_key_parallel(&mut v, |p: &(i64, i64)| p.0);
        let mut expected = v.clone();
        expected.sort();
        assert_eq!(v, expected);
        for w in v.windows(2) {
            assert!(w[0] <= w[1]);
        }
    }

    #[test]
    fn stable_reverse_keys() {
        let mut v: Vec<(i64, i64)> = (0..30_000i64).map(|i| (-(i % 13), i)).collect();
        sort_by_key_parallel(&mut v, |p: &(i64, i64)| p.0);
        for w in v.windows(2) {
            assert!(w[0].0 < w[1].0 || (w[0].0 == w[1].0 && w[0].1 < w[1].1));
        }
    }
}
