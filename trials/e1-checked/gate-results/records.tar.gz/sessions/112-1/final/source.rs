//! Sentences of a text, borrowed from it.

/// A document borrowing its text.
#[derive(Debug, Clone, Copy)]
pub struct Doc<'a> {
    text: &'a str,
}

/// Lazy iterator over the sentences of a text.
#[derive(Debug, Clone)]
pub struct Sentences<'a> {
    rest: &'a str,
}

impl<'a> Iterator for Sentences<'a> {
    type Item = &'a str;

    fn next(&mut self) -> Option<&'a str> {
        loop {
            if self.rest.is_empty() {
                return None;
            }
            let s = self.rest;
            let mut end = s.len();
            let mut it = s.char_indices().peekable();
            while let Some((i, c)) = it.next() {
                if matches!(c, '.' | '!' | '?') {
                    match it.peek() {
                        None => {
                            end = i + c.len_utf8();
                            break;
                        }
                        Some(&(_, n)) if n.is_whitespace() => {
                            end = i + c.len_utf8();
                            break;
                        }
                        _ => {}
                    }
                }
            }
            let sent = s[..end].trim();
            self.rest = &s[end..];
            if !sent.is_empty() {
                return Some(sent);
            }
        }
    }
}

fn words(s: &str) -> impl Iterator<Item = &str> {
    s.split_whitespace()
        .map(|w| w.trim_matches(|c: char| c.is_ascii_punctuation()))
        .filter(|w| !w.is_empty())
}

impl<'a> Doc<'a> {
    pub fn new(text: &'a str) -> Self {
        Doc { text }
    }

    pub fn sentences(&self) -> Sentences<'a> {
        Sentences { rest: self.text }
    }

    pub fn longest(&self) -> Option<&'a str> {
        let mut best: Option<(&'a str, usize)> = None;
        for s in self.sentences() {
            let n = s.chars().count();
            if best.is_none_or(|(_, b)| n > b) {
                best = Some((s, n));
            }
        }
        best.map(|(s, _)| s)
    }

    pub fn words_of(&self, i: usize) -> Option<Vec<&'a str>> {
        self.sentences().nth(i).map(|s| words(s).collect())
    }

    pub fn with_word<'w>(&self, word: &'w str) -> impl Iterator<Item = &'a str> + use<'a, 'w> {
        self.sentences()
            .filter(move |s| words(s).any(|w| w.eq_ignore_ascii_case(word)))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const T: &str = "Hi there. How are you? Fine!";

    #[test]
    fn splitting() {
        assert_eq!(
            Doc::new(T).sentences().collect::<Vec<_>>(),
            ["Hi there.", "How are you?", "Fine!"]
        );
        assert_eq!(Doc::new("a.b. c").sentences().collect::<Vec<_>>(), ["a.b.", "c"]);
        assert_eq!(Doc::new("No end").sentences().collect::<Vec<_>>(), ["No end"]);
        assert!(Doc::new("   ").sentences().next().is_none());
        assert_eq!(Doc::new("a?!  b").sentences().collect::<Vec<_>>(), ["a?!", "b"]);
    }

    #[test]
    fn slices() {
        let s = Doc::new(T).sentences().nth(1).unwrap();
        let r = T.as_bytes().as_ptr_range();
        assert!(r.contains(&s.as_ptr()));
    }

    #[test]
    fn longest_words() {
        assert_eq!(Doc::new("ab. cd. e.").longest(), Some("ab."));
        assert_eq!(Doc::new("  ").longest(), None);
        let d = Doc::new(T);
        assert_eq!(d.words_of(1), Some(vec!["How", "are", "you"]));
        assert_eq!(d.words_of(9), None);
    }

    #[test]
    fn with_word_and_drop() {
        assert_eq!(Doc::new(T).with_word("HI").collect::<Vec<_>>(), ["Hi there."]);
        let text = String::from(T);
        let word = String::from("fine");
        let (a, b) = {
            let d = Doc::new(&text);
            (d.sentences(), d.with_word(&word))
        };
        assert_eq!(a.count(), 3);
        assert_eq!(b.collect::<Vec<_>>(), ["Fine!"]);
    }
}
