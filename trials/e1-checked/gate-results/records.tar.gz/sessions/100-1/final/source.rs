use std::collections::BTreeMap;
use std::json;
use std::process::ExitCode;

#[derive(Debug, Clone, Copy, PartialEq, Decode)]
enum Op {
    #[codec(rename = "read")]
    Read,
    #[codec(rename = "write")]
    Write,
}

#[derive(Debug, Decode)]
struct Entry {
    user: String,
    bytes: u64,
    op: Op,
}

#[derive(Debug, PartialEq)]
struct Report {
    out: String,
    errors: Vec<String>,
}

#[derive(Debug, PartialEq)]
struct Overflow;

/// Authority-free: totals the input, returning stdout text and stderr lines.
fn tally(input: &str) -> Result<Report, Overflow> {
    let mut totals: BTreeMap<String, (u64, u64)> = BTreeMap::new();
    let mut errors = Vec::new();
    for (i, line) in input.lines().enumerate() {
        if line.trim().is_empty() {
            continue;
        }
        let n = i + 1;
        match json::decode::<Entry>(line.as_bytes()) {
            Ok(e) => {
                let t = totals.entry(e.user).or_insert((0, 0));
                match e.op {
                    Op::Read => t.0 = t.0.checked_add(e.bytes).ok_or(Overflow)?,
                    Op::Write => t.1 = t.1.checked_add(e.bytes).ok_or(Overflow)?,
                }
            }
            Err(err) => errors.push(format!("usage: line {n}: {err}")),
        }
    }
    let mut out = String::new();
    for (user, (r, w)) in &totals {
        out.push_str(&format!("{user} read={r} write={w}\n"));
    }
    Ok(Report { out, errors })
}

#[tide::main]
fn main(root: Root) -> ExitCode {
    let mut input = String::new();
    if let Err(e) = root.stdin.read_to_string(&mut input) {
        eprintln!("usage: cannot read standard input: {e}");
        return ExitCode::FAILURE;
    }
    match tally(&input) {
        Err(Overflow) => {
            eprintln!("usage: overflow");
            ExitCode::FAILURE
        }
        Ok(rep) => {
            for e in &rep.errors {
                eprintln!("{e}");
            }
            print!("{}", rep.out);
            if rep.errors.is_empty() {
                ExitCode::SUCCESS
            } else {
                ExitCode::FAILURE
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const A: &str = "{\"user\":\"bo\",\"bytes\":5,\"op\":\"read\"}";
    const B: &str = "{\"user\":\"al\",\"bytes\":7,\"op\":\"write\",\"extra\":1}";
    const C: &str = "{\"user\":\"bo\",\"bytes\":3,\"op\":\"write\"}";

    #[test]
    fn basic() {
        let input = format!("{A}\n{B}\n\n{C}\n");
        let r = tally(&input).unwrap();
        assert_eq!(r.out, "al read=0 write=7\nbo read=5 write=3\n");
        assert!(r.errors.is_empty());
    }

    #[test]
    fn bad_line() {
        let input = format!("{A}\n{{bad\n{B}\n{C}\n");
        let r = tally(&input).unwrap();
        assert_eq!(r.out, "al read=0 write=7\nbo read=5 write=3\n");
        assert_eq!(r.errors.len(), 1);
        assert!(r.errors[0].starts_with("usage: line 2: "));
    }

    #[test]
    fn bad_values() {
        let r = tally("{\"user\":\"x\",\"bytes\":1,\"op\":\"delete\"}\n{\"user\":\"x\",\"bytes\":-1,\"op\":\"read\"}\n").unwrap();
        assert_eq!(r.out, "");
        assert_eq!(r.errors.len(), 2);
        assert!(r.errors[1].starts_with("usage: line 2: "));
    }

    #[test]
    fn empty() {
        let r = tally("").unwrap();
        assert_eq!(r, Report { out: String::new(), errors: vec![] });
    }

    #[test]
    fn overflow() {
        let l = "{\"user\":\"a\",\"bytes\":18446744073709551615,\"op\":\"read\"}";
        assert_eq!(tally(&format!("{l}\n{l}\n")), Err(Overflow));
    }
}
