//! Decimal amounts as integer cents.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Cents(pub i64);

#[derive(Debug, PartialEq)]
pub enum AmountError {
    Invalid,
    Overflow,
}

/// Parses an optional `-`, one or more ASCII digits, and optionally `.`
/// followed by one or two digits.
pub fn parse_amount(s: &str) -> Result<Cents, AmountError> {
    let (neg, rest) = match s.strip_prefix('-') {
        Some(r) => (true, r),
        None => (false, s),
    };
    let (int_part, frac_part) = match rest.split_once('.') {
        Some((i, f)) => (i, Some(f)),
        None => (rest, None),
    };
    if int_part.is_empty() || !int_part.bytes().all(|b| b.is_ascii_digit()) {
        return Err(AmountError::Invalid);
    }
    if let Some(f) = frac_part {
        if f.is_empty() || f.len() > 2 || !f.bytes().all(|b| b.is_ascii_digit()) {
            return Err(AmountError::Invalid);
        }
    }
    // Format is valid; compute magnitude in i128, bailing out on overflow.
    let limit: i128 = 1i128 << 64;
    let mut mag: i128 = 0;
    for b in int_part.bytes() {
        mag = mag * 10 + i128::from(b - b'0');
        if mag > limit {
            return Err(AmountError::Overflow);
        }
    }
    let mut frac: i128 = 0;
    if let Some(f) = frac_part {
        let bytes = f.as_bytes();
        frac = i128::from(bytes[0] - b'0') * 10;
        if bytes.len() == 2 {
            frac += i128::from(bytes[1] - b'0');
        }
    }
    let total = mag * 100 + frac;
    let signed = if neg { -total } else { total };
    i64::try_from(signed)
        .map(Cents)
        .map_err(|_| AmountError::Overflow)
}

/// Sum of price times quantity; `Overflow` if any step overflows.
pub fn total(items: &[(Cents, u32)]) -> Result<Cents, AmountError> {
    let mut sum: i64 = 0;
    for (price, qty) in items {
        let line = price
            .0
            .checked_mul(i64::from(*qty))
            .ok_or(AmountError::Overflow)?;
        sum = sum.checked_add(line).ok_or(AmountError::Overflow)?;
    }
    Ok(Cents(sum))
}

/// `-` for negatives, at least one integer digit, exactly two decimals.
pub fn format_amount(c: Cents) -> String {
    let mag = c.0.unsigned_abs();
    let sign = if c.0 < 0 { "-" } else { "" };
    format!("{}{}.{:02}", sign, mag / 100, mag % 100)
}

/// `parts` shares summing to `c`, differing by at most one cent, larger
/// shares first. Panics if `parts` is 0.
pub fn split_even(c: Cents, parts: u32) -> Vec<Cents> {
    assert!(parts > 0, "split_even: parts must be positive");
    let p = i64::from(parts);
    let q = c.0.div_euclid(p);
    let r = usize::try_from(c.0.rem_euclid(p)).unwrap();
    let n = usize::try_from(parts).unwrap();
    let mut out = Vec::with_capacity(n);
    for i in 0..n {
        if i < r {
            out.push(Cents(q + 1));
        } else {
            out.push(Cents(q));
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_valid() {
        assert_eq!(parse_amount("12.34"), Ok(Cents(1234)));
        assert_eq!(parse_amount("-0.5"), Ok(Cents(-50)));
        assert_eq!(parse_amount("7"), Ok(Cents(700)));
        assert_eq!(parse_amount("1.5"), Ok(Cents(150)));
        assert_eq!(parse_amount("-0"), Ok(Cents(0)));
    }

    #[test]
    fn rejects_invalid() {
        for s in ["1.234", "", "-", ".5", "1.", "+1", "1,00", "--1", "1.a", "a", "-.5"] {
            assert_eq!(parse_amount(s), Err(AmountError::Invalid), "{s}");
        }
        assert_eq!(
            parse_amount("99999999999999999999999999999x"),
            Err(AmountError::Invalid)
        );
    }

    #[test]
    fn bounds() {
        assert_eq!(parse_amount("92233720368547758.07"), Ok(Cents(i64::MAX)));
        assert_eq!(parse_amount("-92233720368547758.08"), Ok(Cents(i64::MIN)));
        assert_eq!(
            parse_amount("92233720368547758.08"),
            Err(AmountError::Overflow)
        );
        assert_eq!(
            parse_amount("999999999999999999999999999999999"),
            Err(AmountError::Overflow)
        );
    }

    #[test]
    fn totals() {
        assert_eq!(total(&[(Cents(250), 3), (Cents(-100), 2)]), Ok(Cents(550)));
        assert_eq!(total(&[(Cents(1), u32::MAX)]), Ok(Cents(4294967295)));
        assert_eq!(total(&[(Cents(i64::MAX), 2)]), Err(AmountError::Overflow));
        assert_eq!(total(&[]), Ok(Cents(0)));
    }

    #[test]
    fn formats() {
        assert_eq!(format_amount(Cents(0)), "0.00");
        assert_eq!(format_amount(Cents(-1205)), "-12.05");
        assert_eq!(format_amount(Cents(123450)), "1234.50");
        assert_eq!(format_amount(Cents(i64::MIN)), "-92233720368547758.08");
        assert_eq!(format_amount(Cents(-5)), "-0.05");
    }

    #[test]
    fn splits() {
        assert_eq!(split_even(Cents(100), 3), vec![Cents(34), Cents(33), Cents(33)]);
        assert_eq!(split_even(Cents(-5), 2), vec![Cents(-2), Cents(-3)]);
        assert_eq!(split_even(Cents(0), 1), vec![Cents(0)]);
    }

    #[test]
    #[should_panic]
    fn split_zero_panics() {
        let _ = split_even(Cents(1), 0);
    }
}
