//! A bounded stack with stated pre- and postconditions.

#[derive(Debug, Clone, PartialEq)]
pub struct BoundedStack<T> {
    items: Vec<T>,
    cap: usize,
}

impl<T: Pure + Sync> BoundedStack<T> {
    #[requires(capacity >= 1)]
    pub fn new(capacity: usize) -> Self {
        assert!(capacity >= 1, "capacity must be at least 1");
        BoundedStack { items: Vec::new(), cap: capacity }
    }

    #[requires(self.items.len() < self.cap)]
    #[ensures(self.items.len() == old(self.items.len()) + 1)]
    pub fn push(&mut self, x: T) {
        assert!(self.items.len() < self.cap, "push onto a full stack");
        self.items.push(x);
    }

    #[ensures(old(self.items.len()) == 0 ==> self.items.len() == 0)]
    #[ensures(old(self.items.len()) > 0 ==> self.items.len() + 1 == old(self.items.len()))]
    pub fn pop(&mut self) -> Option<T> {
        self.items.pop()
    }

    #[requires(n <= self.items.len())]
    #[ensures(result.len() == n)]
    pub fn drain_top(&mut self, n: usize) -> Vec<T> {
        assert!(n <= self.items.len(), "drain_top: n exceeds len");
        let at = self.items.len() - n;
        let mut out = self.items.split_off(at);
        out.reverse();
        out
    }
}

impl<T> BoundedStack<T> {
    pub fn peek(&self) -> Option<&T> {
        self.items.last()
    }

    pub fn len(&self) -> usize {
        self.items.len()
    }

    pub fn capacity(&self) -> usize {
        self.cap
    }

    pub fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    pub fn is_full(&self) -> bool {
        self.items.len() == self.cap
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn push_pop_order() {
        let mut s = BoundedStack::new(3);
        assert!(s.is_empty());
        s.push(1);
        s.push(2);
        s.push(3);
        assert!(s.is_full());
        assert_eq!(s.len(), 3);
        assert_eq!(s.capacity(), 3);
        assert_eq!(s.pop(), Some(3));
        assert_eq!(s.pop(), Some(2));
        assert_eq!(s.pop(), Some(1));
        assert_eq!(s.pop(), None);
        assert_eq!(s.len(), 0);
    }

    #[test]
    #[should_panic]
    fn push_full_panics() {
        let mut s = BoundedStack::new(1);
        s.push(1);
        s.push(2);
    }

    #[test]
    #[should_panic]
    fn new_zero_panics() {
        let _s: BoundedStack<i32> = BoundedStack::new(0);
    }

    #[test]
    #[should_panic]
    fn drain_too_many_panics() {
        let mut s = BoundedStack::new(5);
        s.push(1);
        s.push(2);
        let _v = s.drain_top(3);
    }

    #[test]
    fn drain_top_order() {
        let mut s = BoundedStack::new(3);
        s.push('a');
        s.push('b');
        s.push('c');
        assert_eq!(s.drain_top(2), vec!['c', 'b']);
        assert_eq!(s.len(), 1);
        assert_eq!(s.peek(), Some(&'a'));
    }

    #[test]
    fn strings_work() {
        let mut s: BoundedStack<String> = BoundedStack::new(3);
        s.push("a".to_string());
        s.push("b".to_string());
        s.push("c".to_string());
        assert!(s.is_full());
        assert_eq!(s.drain_top(2), vec!["c".to_string(), "b".to_string()]);
        assert_eq!(s.peek(), Some(&"a".to_string()));
        assert_eq!(s.pop(), Some("a".to_string()));
        assert_eq!(s.pop(), None);
    }
}
