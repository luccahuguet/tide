use std::sync::Mutex;
use std::sync::atomic::{AtomicBool, Ordering};
use std::thread;

const CHUNK: usize = 4096;

fn find_bytes(hay: &[u8], needle: &[u8]) -> Option<usize> {
    if needle.len() > hay.len() {
        return None;
    }
    let first = needle[0];
    let last_start = hay.len() - needle.len();
    let mut i = 0;
    while i <= last_start {
        match hay[i..=last_start].iter().position(|&b| b == first) {
            None => return None,
            Some(off) => {
                let p = i + off;
                if &hay[p..p + needle.len()] == needle {
                    return Some(p);
                }
                i = p + 1;
            }
        }
    }
    None
}

fn search(hay: &[u8], needle: &[u8], stop: &AtomicBool) -> Option<usize> {
    let mut start = 0;
    while start < hay.len() {
        if stop.load(Ordering::Relaxed) {
            return None;
        }
        let end = (start + CHUNK + needle.len() - 1).min(hay.len());
        if let Some(p) = find_bytes(&hay[start..end], needle) {
            return Some(start + p);
        }
        start += CHUNK;
    }
    None
}

/// Searches each haystack concurrently; returns the first match found.
pub fn find_any(hays: &[String], needle: &str) -> Option<(usize, usize)> {
    assert!(!needle.is_empty(), "needle must not be empty");
    let stop = AtomicBool::new(false);
    let result: Mutex<Option<(usize, usize)>> = Mutex::new(None);
    let nb = needle.as_bytes();
    thread::scope(|s| {
        for (i, h) in hays.iter().enumerate() {
            let stop = &stop;
            let result = &result;
            s.spawn(move || {
                if let Some(p) = search(h.as_bytes(), nb, stop) {
                    let mut r = result.lock().unwrap();
                    if r.is_none() {
                        *r = Some((i, p));
                    }
                    stop.store(true, Ordering::Relaxed);
                }
            });
        }
    });
    result.into_inner().unwrap()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn v(x: &[&str]) -> Vec<String> {
        x.iter().map(|s| s.to_string()).collect()
    }

    #[test]
    fn one() {
        assert_eq!(find_any(&v(&["abc", "xxneedle", "q"]), "needle"), Some((1, 2)));
    }

    #[test]
    fn none() {
        assert_eq!(find_any(&v(&["abc", "def"]), "zz"), None);
        assert_eq!(find_any(&[], "zz"), None);
    }

    #[test]
    fn two() {
        let r = find_any(&v(&["aXb", "cdX"]), "X");
        assert!(r == Some((0, 1)) || r == Some((1, 2)));
    }

    #[test]
    fn big() {
        let mut hays = vec!["a".repeat(1_000_000); 8];
        hays[3].replace_range(999_000..999_006, "needle");
        assert_eq!(find_any(&hays, "needle"), Some((3, 999_000)));
    }

    #[test]
    fn boundary() {
        let mut h = "a".repeat(10000);
        h.replace_range(4094..4098, "wxyz");
        assert_eq!(find_any(&[h], "wxyz"), Some((0, 4094)));
        assert_eq!(find_any(&v(&["abab"]), "ab"), Some((0, 0)));
    }

    #[test]
    #[should_panic]
    fn empty() {
        find_any(&v(&["a"]), "");
    }
}
