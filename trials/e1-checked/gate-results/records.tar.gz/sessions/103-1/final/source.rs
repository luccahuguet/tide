use serde::Deserialize;
use std::collections::BTreeMap;
use std::io::{Read, Write};

#[derive(Deserialize)]
#[serde(rename_all = "lowercase")]
enum Op {
    Read,
    Write,
}

#[derive(Deserialize)]
struct Record {
    user: String,
    bytes: u64,
    op: Op,
}

/// Returns (stdout, stderr, exit code).
fn process(input: &[u8]) -> (String, String, i32) {
    let mut totals: BTreeMap<String, (u64, u64)> = BTreeMap::new();
    let mut err = String::new();
    let mut failed = false;
    for (i, raw) in input.split(|&b| b == b'\n').enumerate() {
        let line = raw.strip_suffix(b"\r").unwrap_or(raw);
        if line.iter().all(|b| b.is_ascii_whitespace()) {
            continue;
        }
        match serde_json::from_slice::<Record>(line) {
            Ok(rec) => {
                let entry = totals.entry(rec.user).or_insert((0, 0));
                let slot = match rec.op {
                    Op::Read => &mut entry.0,
                    Op::Write => &mut entry.1,
                };
                match slot.checked_add(rec.bytes) {
                    Some(v) => *slot = v,
                    None => {
                        err.push_str("usage: overflow\n");
                        return (String::new(), err, 1);
                    }
                }
            }
            Err(e) => {
                failed = true;
                err.push_str(&format!("usage: line {}: {}\n", i + 1, e));
            }
        }
    }
    let mut out = String::new();
    for (user, (r, w)) in &totals {
        out.push_str(&format!("{user} read={r} write={w}\n"));
    }
    (out, err, if failed { 1 } else { 0 })
}

fn main() {
    let mut input = Vec::new();
    if let Err(e) = std::io::stdin().read_to_end(&mut input) {
        eprintln!("usage: {e}");
        std::process::exit(1);
    }
    let (out, err, code) = process(&input);
    let _ = std::io::stderr().write_all(err.as_bytes());
    let mut so = std::io::stdout();
    let _ = so.write_all(out.as_bytes());
    let _ = so.flush();
    std::process::exit(code);
}

#[cfg(test)]
mod tests {
    use super::*;

    const A: &str = r#"{"user":"bo","bytes":5,"op":"read"}"#;
    const B: &str = r#"{"user":"al","bytes":7,"op":"write","extra":1}"#;
    const C: &str = r#"{"user":"bo","bytes":3,"op":"write"}"#;

    #[test]
    fn basic() {
        let input = format!("{A}\n{B}\n{C}\n");
        let (o, e, c) = process(input.as_bytes());
        assert_eq!(o, "al read=0 write=7\nbo read=5 write=3\n");
        assert_eq!(e, "");
        assert_eq!(c, 0);
    }

    #[test]
    fn bad_line() {
        let input = format!("{A}\n{{bad\n{B}\n{C}\n");
        let (o, e, c) = process(input.as_bytes());
        assert_eq!(o, "al read=0 write=7\nbo read=5 write=3\n");
        assert!(e.starts_with("usage: line 2: "));
        assert_eq!(c, 1);
    }

    #[test]
    fn bad_values() {
        let (o, e, c) = process(br#"{"user":"x","bytes":1,"op":"delete"}"#);
        assert_eq!((o.as_str(), c), ("", 1));
        assert!(e.starts_with("usage: line 1: "));
        let (_, e, c) = process(b"\n{\"user\":\"x\",\"bytes\":-1,\"op\":\"read\"}\n");
        assert_eq!(c, 1);
        assert!(e.starts_with("usage: line 2: "));
    }

    #[test]
    fn empty() {
        assert_eq!(process(b""), (String::new(), String::new(), 0));
        assert_eq!(process(b"\n  \n"), (String::new(), String::new(), 0));
    }

    #[test]
    fn overflow() {
        let l = r#"{"user":"u","bytes":18446744073709551615,"op":"read"}"#;
        let input = format!("{l}\n{l}\n");
        let (o, e, c) = process(input.as_bytes());
        assert_eq!(o, "");
        assert!(e.starts_with("usage: overflow"));
        assert_eq!(c, 1);
    }
}
