use std::collections::HashSet;
use std::fs::{Fs, Mode};
use std::io;

#[derive(Debug, Error)]
pub enum ExportError {
    #[error("bad report name: {0}")]
    BadName(String),
    #[error("duplicate report name: {0}")]
    Duplicate(String),
    #[error("i/o error: {0}")]
    Io(#[from] io::Error),
}

fn valid_name(name: &str) -> bool {
    if name.is_empty() || name.contains('\\') {
        return false;
    }
    name.split('/')
        .all(|c| !c.is_empty() && c != "." && c != "..")
}

pub fn export(fs: &Fs, reports: &[(&str, &str)]) -> Result<usize, ExportError> {
    let mut seen: HashSet<&str> = HashSet::new();
    for (name, _) in reports {
        if !valid_name(name) {
            return Err(ExportError::BadName(name.to_string()));
        }
        if !seen.insert(*name) {
            return Err(ExportError::Duplicate(name.to_string()));
        }
    }
    fs.create_dir_all("out")?;
    let out = fs.dir("out", Mode::ReadWrite)?;
    for (name, body) in reports {
        if let Some((parent, _)) = name.rsplit_once('/') {
            out.create_dir_all(parent)?;
        }
        out.write(name, body.as_bytes())?;
    }
    Ok(reports.len())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    #[sim_test(seeds = 20)]
    fn writes_and_replaces(sim: SimRoot) {
        sim.world.file("out/a.txt", "old");
        let n = export(&sim.fs, &[("a.txt", "1"), ("2026/jan.txt", "2")]).unwrap();
        assert_eq!(n, 2);
        assert_eq!(sim.fs.read_to_string("out/a.txt").unwrap(), "1");
        assert_eq!(sim.fs.read_to_string("out/2026/jan.txt").unwrap(), "2");
    }

    #[sim_test(seeds = 20)]
    fn escape_rejected(sim: SimRoot) {
        let r = export(&sim.fs, &[("ok", "x"), ("../evil", "y")]);
        assert!(matches!(r, Err(ExportError::BadName(ref n)) if n == "../evil"));
        assert!(!sim.fs.exists("out/ok").unwrap());
        assert!(!sim.fs.exists("evil").unwrap());
    }

    #[sim_test(seeds = 20)]
    fn bad_names(sim: SimRoot) {
        for name in ["/abs", "a//b", "a/./b", "", "a\\b", "a/", "..", "."] {
            let r = export(&sim.fs, &[(name, "x")]);
            assert!(matches!(r, Err(ExportError::BadName(ref n)) if n == name), "{name}");
        }
        assert!(!sim.fs.exists("out").unwrap());
    }

    #[sim_test(seeds = 20)]
    fn duplicate(sim: SimRoot) {
        let r = export(&sim.fs, &[("a", "1"), ("a", "2")]);
        assert!(matches!(r, Err(ExportError::Duplicate(ref n)) if n == "a"));
        assert!(!sim.fs.exists("out/a").unwrap());
    }

    #[sim_test(seeds = 20)]
    fn out_is_file(sim: SimRoot) {
        sim.world.file("out", "file");
        let r = export(&sim.fs, &[("a", "1")]);
        assert!(matches!(r, Err(ExportError::Io(_))));
        assert_eq!(sim.fs.read_to_string("out").unwrap(), "file");
    }
}
