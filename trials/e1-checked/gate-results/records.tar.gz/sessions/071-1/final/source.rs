use std::fmt;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CalcError {
    DivByZero { pos: usize },
    Overflow { pos: usize },
    Unexpected { pos: usize },
}

impl fmt::Display for CalcError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            CalcError::DivByZero { pos } => write!(f, "division by zero at {pos}"),
            CalcError::Overflow { pos } => write!(f, "overflow at {pos}"),
            CalcError::Unexpected { pos } => write!(f, "unexpected input at {pos}"),
        }
    }
}

impl std::error::Error for CalcError {}

/// Syntax errors are returned as `Err` immediately; arithmetic errors
/// (division by zero, overflow) are recorded in evaluation order and
/// reported only if the whole input is syntactically valid.
struct Parser<'a> {
    s: &'a [u8],
    i: usize,
    err: Option<CalcError>,
}

impl<'a> Parser<'a> {
    fn peek(&mut self) -> Option<u8> {
        while self.i < self.s.len() && matches!(self.s[self.i], b' ' | b'\t' | b'\n' | b'\r') {
            self.i += 1;
        }
        self.s.get(self.i).copied()
    }

    fn fail(&mut self, e: CalcError) -> i64 {
        if self.err.is_none() {
            self.err = Some(e);
        }
        0
    }

    fn expr(&mut self) -> Result<i64, CalcError> {
        let mut v = self.term()?;
        loop {
            let op = match self.peek() {
                Some(c @ (b'+' | b'-')) => c,
                _ => return Ok(v),
            };
            let pos = self.i;
            self.i += 1;
            let r = self.term()?;
            let res = if op == b'+' { v.checked_add(r) } else { v.checked_sub(r) };
            v = match res {
                Some(x) => x,
                None => self.fail(CalcError::Overflow { pos }),
            };
        }
    }

    fn term(&mut self) -> Result<i64, CalcError> {
        let mut v = self.unary()?;
        loop {
            let op = match self.peek() {
                Some(c @ (b'*' | b'/' | b'%')) => c,
                _ => return Ok(v),
            };
            let pos = self.i;
            self.i += 1;
            let r = self.unary()?;
            v = if op == b'*' {
                match v.checked_mul(r) {
                    Some(x) => x,
                    None => self.fail(CalcError::Overflow { pos }),
                }
            } else if r == 0 {
                self.fail(CalcError::DivByZero { pos })
            } else {
                let res = if op == b'/' { v.checked_div(r) } else { v.checked_rem(r) };
                match res {
                    Some(x) => x,
                    None => self.fail(CalcError::Overflow { pos }),
                }
            };
        }
    }

    fn unary(&mut self) -> Result<i64, CalcError> {
        let mut minuses: Vec<usize> = Vec::new();
        while self.peek() == Some(b'-') {
            minuses.push(self.i);
            self.i += 1;
        }
        let mut v = self.primary()?;
        for &pos in minuses.iter().rev() {
            v = match v.checked_neg() {
                Some(x) => x,
                None => self.fail(CalcError::Overflow { pos }),
            };
        }
        Ok(v)
    }

    fn primary(&mut self) -> Result<i64, CalcError> {
        match self.peek() {
            Some(b'(') => {
                self.i += 1;
                let v = self.expr()?;
                if self.peek() == Some(b')') {
                    self.i += 1;
                    Ok(v)
                } else {
                    Err(CalcError::Unexpected { pos: self.i })
                }
            }
            Some(c) if c.is_ascii_digit() => {
                let start = self.i;
                let mut v: Option<i64> = Some(0);
                while self.i < self.s.len() && self.s[self.i].is_ascii_digit() {
                    let d = (self.s[self.i] - b'0') as i64;
                    v = v.and_then(|x| x.checked_mul(10)).and_then(|x| x.checked_add(d));
                    self.i += 1;
                }
                Ok(match v {
                    Some(x) => x,
                    None => self.fail(CalcError::Overflow { pos: start }),
                })
            }
            _ => Err(CalcError::Unexpected { pos: self.i }),
        }
    }
}

pub fn eval(src: &str) -> Result<i64, CalcError> {
    let mut p = Parser { s: src.as_bytes(), i: 0, err: None };
    let v = p.expr()?;
    if p.peek().is_some() {
        return Err(CalcError::Unexpected { pos: p.i });
    }
    match p.err {
        Some(e) => Err(e),
        None => Ok(v),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn values() {
        assert_eq!(eval("1 + 2 * 3"), Ok(7));
        assert_eq!(eval("(1+2)*3"), Ok(9));
        assert_eq!(eval("-(-4) % 3"), Ok(1));
        assert_eq!(eval("7 / -2"), Ok(-3));
        assert_eq!(eval("- 9223372036854775807 - 1"), Ok(i64::MIN));
        assert_eq!(eval("10 - 3 - 2"), Ok(5));
        assert_eq!(eval("--5"), Ok(5));
    }

    #[test]
    fn div_zero() {
        assert_eq!(eval("1 / (2 - 2)"), Err(CalcError::DivByZero { pos: 2 }));
        assert_eq!(eval("1 % 0"), Err(CalcError::DivByZero { pos: 2 }));
    }

    #[test]
    fn overflow() {
        assert_eq!(eval("9223372036854775807 + 1"), Err(CalcError::Overflow { pos: 20 }));
        assert_eq!(eval("9223372036854775808"), Err(CalcError::Overflow { pos: 0 }));
        assert_eq!(eval("-9223372036854775808"), Err(CalcError::Overflow { pos: 1 }));
        assert_eq!(eval("-(-9223372036854775807 - 1)"), Err(CalcError::Overflow { pos: 0 }));
    }

    #[test]
    fn unexpected() {
        assert_eq!(eval("2 *"), Err(CalcError::Unexpected { pos: 3 }));
        assert_eq!(eval("(1"), Err(CalcError::Unexpected { pos: 2 }));
        assert_eq!(eval("1 2"), Err(CalcError::Unexpected { pos: 2 }));
        assert_eq!(eval(""), Err(CalcError::Unexpected { pos: 0 }));
        assert_eq!(eval("a"), Err(CalcError::Unexpected { pos: 0 }));
        assert_eq!(eval("1)"), Err(CalcError::Unexpected { pos: 1 }));
    }

    #[test]
    fn display() {
        assert_eq!(CalcError::DivByZero { pos: 2 }.to_string(), "division by zero at 2");
        assert_eq!(CalcError::Overflow { pos: 3 }.to_string(), "overflow at 3");
        assert_eq!(CalcError::Unexpected { pos: 0 }.to_string(), "unexpected input at 0");
    }
}
