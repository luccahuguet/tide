use std::collections::BTreeMap;

#[derive(Default, Debug, Clone)]
struct Node {
    end: bool,
    children: BTreeMap<u8, Node>,
}

#[derive(Default, Debug, Clone)]
pub struct Trie {
    root: Node,
    len: usize,
}

impl Trie {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert(&mut self, w: &str) -> bool {
        let mut n = &mut self.root;
        for &b in w.as_bytes() {
            n = n.children.entry(b).or_default();
        }
        if n.end {
            false
        } else {
            n.end = true;
            self.len += 1;
            true
        }
    }

    fn find(&self, p: &[u8]) -> Option<&Node> {
        let mut n = &self.root;
        for b in p {
            n = n.children.get(b)?;
        }
        Some(n)
    }

    pub fn contains(&self, w: &str) -> bool {
        self.find(w.as_bytes()).is_some_and(|n| n.end)
    }

    pub fn remove(&mut self, w: &str) -> bool {
        fn rec(n: &mut Node, w: &[u8]) -> bool {
            match w.split_first() {
                None => {
                    let was = n.end;
                    n.end = false;
                    was
                }
                Some((b, rest)) => {
                    let Some(c) = n.children.get_mut(b) else {
                        return false;
                    };
                    let r = rec(c, rest);
                    if r && !c.end && c.children.is_empty() {
                        n.children.remove(b);
                    }
                    r
                }
            }
        }
        let r = rec(&mut self.root, w.as_bytes());
        if r {
            self.len -= 1;
        }
        r
    }

    pub fn len(&self) -> usize {
        self.len
    }

    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    pub fn with_prefix(&self, p: &str) -> Vec<String> {
        fn collect(n: &Node, buf: &mut Vec<u8>, out: &mut Vec<String>) {
            if n.end {
                out.push(String::from_utf8(buf.clone()).expect("valid utf8"));
            }
            for (&b, c) in &n.children {
                buf.push(b);
                collect(c, buf, out);
                buf.pop();
            }
        }
        let mut out = Vec::new();
        if let Some(n) = self.find(p.as_bytes()) {
            let mut buf = p.as_bytes().to_vec();
            collect(n, &mut buf, &mut out);
        }
        out
    }

    pub fn longest_common_prefix(&self) -> String {
        if self.len == 0 {
            return String::new();
        }
        let mut buf = Vec::new();
        let mut n = &self.root;
        while !n.end && n.children.len() == 1 {
            let (&b, c) = n.children.iter().next().unwrap();
            buf.push(b);
            n = c;
        }
        match String::from_utf8(buf) {
            Ok(s) => s,
            Err(e) => {
                let k = e.utf8_error().valid_up_to();
                let mut v = e.into_bytes();
                v.truncate(k);
                String::from_utf8(v).unwrap()
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn build(ws: &[&str]) -> Trie {
        let mut t = Trie::new();
        for w in ws {
            t.insert(w);
        }
        t
    }

    #[test]
    fn prefix_and_remove() {
        let mut t = build(&["car", "card", "care", "cat", "dog"]);
        assert_eq!(t.with_prefix("car"), vec!["car", "card", "care"]);
        assert_eq!(t.with_prefix("").len(), 5);
        assert!(t.remove("car"));
        assert!(!t.contains("car"));
        assert!(t.contains("card"));
        assert_eq!(t.with_prefix("ca"), vec!["card", "care", "cat"]);
        assert!(!t.remove("car"));
        assert!(!t.insert("dog"));
        assert_eq!(t.len(), 4);
        assert!(t.with_prefix("x").is_empty());
    }

    #[test]
    fn lcp() {
        let mut t = build(&["interview", "internet", "interval"]);
        assert_eq!(t.longest_common_prefix(), "inter");
        assert_eq!(Trie::new().longest_common_prefix(), "");
        t.insert("");
        assert_eq!(t.longest_common_prefix(), "");
        assert!(t.contains(""));
        let t = build(&["ü", "é"]);
        assert_eq!(t.longest_common_prefix(), "");
        let t = build(&["abc"]);
        assert_eq!(t.longest_common_prefix(), "abc");
    }

    #[test]
    fn unicode() {
        let t = build(&["über", "üben", "ab"]);
        assert_eq!(t.with_prefix("üb"), vec!["üben", "über"]);
    }

    #[test]
    fn empty_word() {
        let mut t = Trie::new();
        assert!(!t.contains(""));
        assert!(t.insert(""));
        assert!(!t.insert(""));
        assert_eq!(t.with_prefix(""), vec![""]);
        assert!(t.remove(""));
        assert_eq!(t.len(), 0);
    }
}
