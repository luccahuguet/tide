//! In-place partition and selection with loop invariants.

/// Reorders `v` so every element less than `pivot` precedes every other.
/// Returns the number of elements less than `pivot`. Allocates nothing.
pub fn partition(v: &mut [i32], pivot: i32) -> usize {
    let mut i = 0;
    // Invariant: v[..i] < pivot, v[i..j] >= pivot, v[j..] unexamined.
    for j in 0..v.len() {
        if v[j] < pivot {
            v.swap(i, j);
            i += 1;
        }
    }
    // Post: v[..i] < pivot, v[i..] >= pivot.
    i
}

/// Returns the `k`-th smallest element (0-based) of `v` by repeated partition.
/// Panics if `k >= v.len()`.
pub fn select_kth(v: &mut [i32], k: usize) -> i32 {
    assert!(k < v.len(), "select_kth: k ({k}) must be < len ({})", v.len());
    let mut lo = 0;
    let mut hi = v.len();
    let mut k = k;
    // Invariant: the answer is the k-th smallest of v[lo..hi]; lo <= k' < hi.
    loop {
        let s = &mut v[lo..hi];
        let n = s.len();
        let p = median3(s[0], s[n / 2], s[n - 1]);
        let lt = partition(s, p);
        // s[lt..] >= p; split off elements equal to p.
        let eq = if p == i32::MAX {
            n - lt
        } else {
            partition(&mut s[lt..], p + 1)
        };
        // eq >= 1 since p is an element of s, so the range shrinks.
        if k < lt {
            hi = lo + lt;
        } else if k < lt + eq {
            return p;
        } else {
            k -= lt + eq;
            lo += lt + eq;
        }
    }
}

fn median3(a: i32, b: i32, c: i32) -> i32 {
    a.max(b).min(a.min(b).max(c))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sorted(v: &[i32]) -> Vec<i32> {
        let mut s = v.to_vec();
        s.sort();
        s
    }

    fn xorshift(n: usize, m: Option<u32>) -> Vec<i32> {
        let mut x: u32 = 2463534242;
        (0..n)
            .map(|_| {
                x ^= x << 13;
                x ^= x >> 17;
                x ^= x << 5;
                match m {
                    Some(m) => (x % m) as i32,
                    None => x as i32,
                }
            })
            .collect()
    }

    #[test]
    fn basic() {
        let orig = [3, 1, 4, 1, 5, 9, 2, 6];
        let mut v = orig;
        assert_eq!(partition(&mut v, 4), 4);
        assert!(v[..4].iter().all(|&x| x < 4));
        assert!(v[4..].iter().all(|&x| x >= 4));
        assert_eq!(sorted(&v), sorted(&orig));
    }

    #[test]
    fn zero_and_empty() {
        let mut v = [5, 6, 7];
        assert_eq!(partition(&mut v, 5), 0);
        let mut e: [i32; 0] = [];
        assert_eq!(partition(&mut e, 5), 0);
    }

    #[test]
    fn select() {
        for m in [None, Some(10), Some(1)] {
            let v = xorshift(10_000, m);
            let s = sorted(&v);
            for k in [0, 1, 4999, 9999] {
                let mut w = v.clone();
                assert_eq!(select_kth(&mut w, k), s[k]);
                assert_eq!(sorted(&w), s);
            }
        }
        let mut v = [i32::MAX, i32::MIN, i32::MAX, 0];
        assert_eq!(select_kth(&mut v, 3), i32::MAX);
        assert_eq!(select_kth(&mut v, 0), i32::MIN);
    }

    #[test]
    #[should_panic]
    fn k_eq_len() {
        let mut v = [1, 2, 3];
        select_kth(&mut v, 3);
    }
}
