use std::fmt;
use std::ops::{Add, Mul, Neg, Sub};

#[derive(Debug, Clone, PartialEq)]
pub struct Poly {
    coeffs: Vec<i64>,
}

impl Poly {
    pub fn new(coeffs: Vec<i64>) -> Poly {
        let mut coeffs = coeffs;
        while coeffs.last() == Some(&0) {
            coeffs.pop();
        }
        Poly { coeffs }
    }

    pub fn coeffs(&self) -> &[i64] {
        &self.coeffs
    }

    pub fn degree(&self) -> Option<usize> {
        if self.coeffs.is_empty() {
            None
        } else {
            Some(self.coeffs.len() - 1)
        }
    }

    pub fn eval(&self, x: i64) -> Option<i64> {
        let mut acc: i64 = 0;
        for c in self.coeffs.iter().rev() {
            acc = acc.checked_mul(x)?.checked_add(*c)?;
        }
        Some(acc)
    }
}

impl fmt::Display for Poly {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if self.coeffs.is_empty() {
            return write!(f, "0");
        }
        let mut first = true;
        for (i, c) in self.coeffs.iter().enumerate().rev() {
            let c = *c;
            if c == 0 {
                continue;
            }
            let neg = c < 0;
            if first {
                if neg {
                    write!(f, "-")?;
                }
            } else if neg {
                write!(f, " - ")?;
            } else {
                write!(f, " + ")?;
            }
            first = false;
            let a = c.unsigned_abs();
            if a != 1 || i == 0 {
                write!(f, "{}", a)?;
            }
            if i == 1 {
                write!(f, "x")?;
            } else if i > 1 {
                write!(f, "x^{}", i)?;
            }
        }
        Ok(())
    }
}

impl Add for &Poly {
    type Output = Poly;
    fn add(self, rhs: &Poly) -> Poly {
        let n = self.coeffs.len().max(rhs.coeffs.len());
        let mut out = Vec::with_capacity(n);
        for i in 0..n {
            let a = self.coeffs.get(i).copied().unwrap_or(0);
            let b = rhs.coeffs.get(i).copied().unwrap_or(0);
            out.push(a + b);
        }
        Poly::new(out)
    }
}

impl Sub for &Poly {
    type Output = Poly;
    fn sub(self, rhs: &Poly) -> Poly {
        let n = self.coeffs.len().max(rhs.coeffs.len());
        let mut out = Vec::with_capacity(n);
        for i in 0..n {
            let a = self.coeffs.get(i).copied().unwrap_or(0);
            let b = rhs.coeffs.get(i).copied().unwrap_or(0);
            out.push(a - b);
        }
        Poly::new(out)
    }
}

impl Mul for &Poly {
    type Output = Poly;
    fn mul(self, rhs: &Poly) -> Poly {
        if self.coeffs.is_empty() || rhs.coeffs.is_empty() {
            return Poly::new(Vec::new());
        }
        let mut out = vec![0i64; self.coeffs.len() + rhs.coeffs.len() - 1];
        for (i, a) in self.coeffs.iter().enumerate() {
            for (j, b) in rhs.coeffs.iter().enumerate() {
                out[i + j] += *a * *b;
            }
        }
        Poly::new(out)
    }
}

impl Add for Poly {
    type Output = Poly;
    fn add(self, rhs: Poly) -> Poly {
        &self + &rhs
    }
}

impl Sub for Poly {
    type Output = Poly;
    fn sub(self, rhs: Poly) -> Poly {
        &self - &rhs
    }
}

impl Mul for Poly {
    type Output = Poly;
    fn mul(self, rhs: Poly) -> Poly {
        &self * &rhs
    }
}

impl Neg for Poly {
    type Output = Poly;
    fn neg(self) -> Poly {
        Poly::new(self.coeffs.iter().map(|c| -*c).collect())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn display() {
        assert_eq!(Poly::new(vec![5, -1, 3]).to_string(), "3x^2 - x + 5");
        assert_eq!(Poly::new(vec![-2, 0, 0, -1]).to_string(), "-x^3 - 2");
        assert_eq!(Poly::new(vec![1]).to_string(), "1");
        assert_eq!(Poly::new(vec![-1]).to_string(), "-1");
        assert_eq!(Poly::new(vec![0, 2]).to_string(), "2x");
    }

    #[test]
    fn zero() {
        let z = Poly::new(vec![0, 0]);
        assert_eq!(z.to_string(), "0");
        assert_eq!(z.degree(), None);
        assert!(z.coeffs().is_empty());
    }

    #[test]
    fn ops() {
        let x = Poly::new(vec![0, 1]);
        let one = Poly::new(vec![1]);
        let p = (x.clone() + one.clone()) * (x.clone() - one.clone());
        assert_eq!(p.coeffs(), &[-1, 0, 1]);
        let a = Poly::new(vec![1, 2]);
        let b = Poly::new(vec![3]);
        let c = &a + &b;
        assert_eq!(c.coeffs(), &[4, 2]);
        assert_eq!(a.degree(), Some(1));
        assert_eq!(b.degree(), Some(0));
        assert_eq!((&a * &b).coeffs(), &[3, 6]);
        assert_eq!((&a - &a).degree(), None);
    }

    #[test]
    fn neg_and_sub() {
        let a = Poly::new(vec![1, 2, 3]);
        assert_eq!(a.clone() - a, Poly::new(vec![]));
        assert_eq!((-Poly::new(vec![0, 1])).to_string(), "-x");
    }

    #[test]
    fn eval() {
        assert_eq!(Poly::new(vec![-1, 0, 1]).eval(3), Some(8));
        assert_eq!(Poly::new(vec![0, 0, 0, 1]).eval(3_000_000), None);
        assert_eq!(Poly::new(vec![]).eval(5), Some(0));
    }
}
