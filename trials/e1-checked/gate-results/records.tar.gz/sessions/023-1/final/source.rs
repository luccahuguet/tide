use std::collections::HashMap;
use std::hash::Hash;

const NIL: usize = usize::MAX;

struct Node<K, V> {
    key: K,
    val: V,
    prev: usize,
    next: usize,
}

/// A least-recently-used cache with O(1) get/put.
pub struct Lru<K, V> {
    cap: usize,
    map: HashMap<K, usize>,
    nodes: Vec<Node<K, V>>,
    head: usize, // most recent
    tail: usize, // least recent
}

impl<K: Eq + Hash + Clone, V> Lru<K, V> {
    pub fn new(capacity: usize) -> Self {
        assert!(capacity > 0, "capacity must be greater than 0");
        Lru {
            cap: capacity,
            map: HashMap::new(),
            nodes: Vec::new(),
            head: NIL,
            tail: NIL,
        }
    }

    fn unlink(&mut self, i: usize) {
        let (p, n) = (self.nodes[i].prev, self.nodes[i].next);
        if p != NIL {
            self.nodes[p].next = n;
        } else {
            self.head = n;
        }
        if n != NIL {
            self.nodes[n].prev = p;
        } else {
            self.tail = p;
        }
        self.nodes[i].prev = NIL;
        self.nodes[i].next = NIL;
    }

    fn push_front(&mut self, i: usize) {
        self.nodes[i].prev = NIL;
        self.nodes[i].next = self.head;
        if self.head != NIL {
            self.nodes[self.head].prev = i;
        } else {
            self.tail = i;
        }
        self.head = i;
    }

    pub fn get(&mut self, k: &K) -> Option<&V> {
        let i = *self.map.get(k)?;
        if self.head != i {
            self.unlink(i);
            self.push_front(i);
        }
        Some(&self.nodes[i].val)
    }

    pub fn peek(&self, k: &K) -> Option<&V> {
        self.map.get(k).map(|&i| &self.nodes[i].val)
    }

    pub fn put(&mut self, k: K, v: V) -> Option<(K, V)> {
        if let Some(&i) = self.map.get(&k) {
            self.nodes[i].val = v;
            if self.head != i {
                self.unlink(i);
                self.push_front(i);
            }
            return None;
        }
        if self.map.len() >= self.cap {
            // Reuse the tail slot.
            let t = self.tail;
            self.unlink(t);
            let old_key = std::mem::replace(&mut self.nodes[t].key, k.clone());
            let old_val = std::mem::replace(&mut self.nodes[t].val, v);
            self.map.remove(&old_key);
            self.map.insert(k, t);
            self.push_front(t);
            return Some((old_key, old_val));
        }
        let i = self.nodes.len();
        self.nodes.push(Node {
            key: k.clone(),
            val: v,
            prev: NIL,
            next: NIL,
        });
        self.map.insert(k, i);
        self.push_front(i);
        None
    }

    pub fn len(&self) -> usize {
        self.map.len()
    }

    pub fn is_empty(&self) -> bool {
        self.map.is_empty()
    }

    pub fn keys_recent_first(&self) -> Vec<&K> {
        let mut out = Vec::with_capacity(self.map.len());
        let mut i = self.head;
        while i != NIL {
            out.push(&self.nodes[i].key);
            i = self.nodes[i].next;
        }
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn case1() {
        let mut c = Lru::new(2);
        assert_eq!(c.put("a", 1), None);
        assert_eq!(c.put("b", 2), None);
        assert_eq!(c.get(&"a"), Some(&1));
        assert_eq!(c.put("c", 3), Some(("b", 2)));
        assert_eq!(c.keys_recent_first(), vec![&"c", &"a"]);
    }

    #[test]
    fn case2() {
        let mut c = Lru::new(2);
        c.put("a", 1);
        c.put("b", 2);
        assert_eq!(c.peek(&"a"), Some(&1));
        assert_eq!(c.put("c", 3), Some(("a", 1)));
    }

    #[test]
    fn case3() {
        let mut c = Lru::new(2);
        c.put("a", 1);
        c.put("b", 2);
        assert_eq!(c.put("a", 10), None);
        assert_eq!(c.len(), 2);
        assert_eq!(c.keys_recent_first(), vec![&"a", &"b"]);
        assert_eq!(c.peek(&"a"), Some(&10));
        assert_eq!(c.put("c", 3), Some(("b", 2)));
    }

    #[test]
    #[should_panic]
    fn case4() {
        let _ = Lru::<u32, u32>::new(0);
    }

    #[test]
    fn case5() {
        let mut c = Lru::new(100_000);
        for i in 0..300_000u32 {
            c.put(i, i);
            assert_eq!(c.get(&i), Some(&i));
        }
        assert_eq!(c.len(), 100_000);
        assert_eq!(c.peek(&0), None);
        assert_eq!(c.peek(&299_999), Some(&299_999));
    }

    #[test]
    fn capacity_one() {
        let mut c = Lru::new(1);
        assert_eq!(c.put(1, 'a'), None);
        assert_eq!(c.put(2, 'b'), Some((1, 'a')));
        assert_eq!(c.get(&1), None);
        assert_eq!(c.keys_recent_first(), vec![&2]);
    }
}
