use std::collections::BTreeSet;
use std::fs::Fs;
use std::io;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PlanError {
    DuplicateSource(String),
    DuplicateTarget(String),
}

/// Plans single renames that, applied in order, realize all moves at once.
#[pure]
pub fn plan(moves: &[(&str, &str)]) -> Result<Vec<(String, String)>, PlanError> {
    let mut seen_src: BTreeSet<&str> = BTreeSet::new();
    let mut seen_dst: BTreeSet<&str> = BTreeSet::new();
    let mut names: BTreeSet<String> = BTreeSet::new();
    for &(s, t) in moves {
        if !seen_src.insert(s) {
            return Err(PlanError::DuplicateSource(s.to_string()));
        }
        if !seen_dst.insert(t) {
            return Err(PlanError::DuplicateTarget(t.to_string()));
        }
        names.insert(s.to_string());
        names.insert(t.to_string());
    }

    let mut pending: Vec<(String, String)> = moves
        .iter()
        .filter(|(s, t)| s != t)
        .map(|(s, t)| (s.to_string(), t.to_string()))
        .collect();
    let mut out: Vec<(String, String)> = Vec::new();

    while !pending.is_empty() {
        let sources: BTreeSet<&str> = pending.iter().map(|(s, _)| s.as_str()).collect();
        let free = pending
            .iter()
            .position(|(_, t)| !sources.contains(t.as_str()));
        match free {
            Some(i) => {
                let step = pending.remove(i);
                out.push(step);
            }
            None => {
                // Every remaining move is part of a cycle: break one.
                let s = pending[0].0.clone();
                let mut tmp = format!("{s}.tmp");
                while names.contains(&tmp) {
                    tmp.push_str(".tmp");
                }
                out.push((s, tmp.clone()));
                pending[0].0 = tmp;
            }
        }
    }
    Ok(out)
}

fn exists(fs: &Fs, p: &str) -> io::Result<bool> {
    match fs.metadata(p) {
        Ok(_) => Ok(true),
        Err(e) if e.kind() == io::ErrorKind::NotFound => Ok(false),
        Err(e) => Err(e),
    }
}

/// Performs the renames in order, after checking every step's source.
pub fn apply(fs: &Fs, steps: &[(String, String)]) -> io::Result<()> {
    let mut produced: BTreeSet<&str> = BTreeSet::new();
    for (s, t) in steps {
        if !produced.contains(s.as_str()) && !exists(fs, s)? {
            return Err(io::Error::new(
                io::ErrorKind::NotFound,
                format!("rename source not found: {s}"),
            ));
        }
        produced.insert(t.as_str());
    }
    for (s, t) in steps {
        fs.rename(s, t)?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeMap;
    use std::sim::SimRoot;

    fn replay(moves: &[(&str, &str)], steps: &[(String, String)]) {
        let mut m: BTreeMap<String, String> = BTreeMap::new();
        for (s, _) in moves {
            m.insert(s.to_string(), format!("content of {s}"));
        }
        for (s, t) in steps {
            assert!(!m.contains_key(t), "target {t} exists");
            let v = m.remove(s).expect("source missing");
            m.insert(t.clone(), v);
        }
        for (s, t) in moves {
            assert_eq!(m.get(*t), Some(&format!("content of {s}")));
        }
        let targets: BTreeSet<&str> = moves.iter().map(|(_, t)| *t).collect();
        for k in m.keys() {
            assert!(targets.contains(k.as_str()), "leftover {k}");
        }
    }

    #[test]
    fn valid_plans() {
        let cases: [&[(&str, &str)]; 6] = [
            &[("a", "b"), ("b", "a")],
            &[("a", "b"), ("b", "c")],
            &[("a", "b"), ("b", "c"), ("c", "a")],
            &[("a", "b"), ("b", "a"), ("a.tmp", "x"), ("c", "d"), ("d", "c")],
            &[("b", "c"), ("a", "b"), ("x", "x"), ("p", "q"), ("q", "r"), ("r", "p")],
            &[("a", "a.tmp"), ("a.tmp", "a")],
        ];
        for moves in cases {
            let steps = plan(moves).unwrap();
            replay(moves, &steps);
        }
    }

    #[test]
    fn identity_dropped() {
        assert_eq!(plan(&[("a", "a")]), Ok(vec![]));
    }

    #[test]
    fn tmp_name() {
        let steps = plan(&[("a", "b"), ("b", "a"), ("a.tmp", "z")]).unwrap();
        assert!(steps.iter().any(|(_, t)| t == "a.tmp.tmp" || t == "b.tmp"));
    }

    #[test]
    fn duplicates() {
        assert_eq!(
            plan(&[("a", "b"), ("a", "c")]),
            Err(PlanError::DuplicateSource("a".to_string()))
        );
        assert_eq!(
            plan(&[("a", "c"), ("b", "c")]),
            Err(PlanError::DuplicateTarget("c".to_string()))
        );
    }

    #[sim_test(seeds = 5)]
    fn apply_swap(sim: SimRoot) {
        sim.world.file("a", "1");
        sim.world.file("b", "2");
        let steps = plan(&[("a", "b"), ("b", "a")]).unwrap();
        apply(&sim.fs, &steps).unwrap();
        assert_eq!(sim.fs.read_to_string("a").unwrap(), "2");
        assert_eq!(sim.fs.read_to_string("b").unwrap(), "1");
    }

    #[sim_test(seeds = 5)]
    fn apply_missing(sim: SimRoot) {
        sim.world.file("a", "1");
        let steps = vec![
            ("a".to_string(), "b".to_string()),
            ("x".to_string(), "y".to_string()),
        ];
        let err = apply(&sim.fs, &steps).unwrap_err();
        assert_eq!(err.kind(), io::ErrorKind::NotFound);
        assert_eq!(sim.fs.read_to_string("a").unwrap(), "1");
        assert!(sim.fs.metadata("b").is_err());
    }
}
