use std::collections::{BTreeMap, BTreeSet, HashSet};
use std::io;
use std::path::Path;

#[derive(Debug, PartialEq, Eq, Clone, thiserror::Error)]
pub enum PlanError {
    #[error("duplicate source: {0}")]
    DuplicateSource(String),
    #[error("duplicate target: {0}")]
    DuplicateTarget(String),
}

pub fn plan(moves: &[(&str, &str)]) -> Result<Vec<(String, String)>, PlanError> {
    let mut srcs = HashSet::new();
    let mut dsts = HashSet::new();
    let mut all: HashSet<&str> = HashSet::new();
    for &(s, d) in moves {
        if !srcs.insert(s) {
            return Err(PlanError::DuplicateSource(s.to_string()));
        }
        if !dsts.insert(d) {
            return Err(PlanError::DuplicateTarget(d.to_string()));
        }
        all.insert(s);
        all.insert(d);
    }
    // pending: src -> dst
    let mut pending: BTreeMap<&str, &str> = moves
        .iter()
        .filter(|(s, d)| s != d)
        .map(|&(s, d)| (s, d))
        .collect();
    let mut out = Vec::new();

    // Emit chain moves: those whose target is not a pending source.
    loop {
        let ready: Vec<&str> = pending
            .iter()
            .filter(|(_, d)| !pending.contains_key(*d))
            .map(|(s, _)| *s)
            .collect();
        if ready.is_empty() {
            break;
        }
        for s in ready {
            let d = pending.remove(s).unwrap();
            out.push((s.to_string(), d.to_string()));
        }
    }

    // Remaining are disjoint cycles.
    while let Some((&start, _)) = pending.iter().next() {
        let rev: BTreeMap<&str, &str> = pending.iter().map(|(s, d)| (*d, *s)).collect();
        let mut tmp = format!("{start}.tmp");
        while all.contains(tmp.as_str()) {
            tmp.push_str(".tmp");
        }
        let first_dst = pending.remove(start).unwrap();
        out.push((start.to_string(), tmp.clone()));
        let mut cur = start;
        let mut seen = BTreeSet::new();
        loop {
            let p = rev[cur];
            if p == start || !seen.insert(p) {
                break;
            }
            pending.remove(p);
            out.push((p.to_string(), cur.to_string()));
            cur = p;
        }
        out.push((tmp, first_dst.to_string()));
    }
    Ok(out)
}

pub fn apply(dir: &Path, steps: &[(String, String)]) -> io::Result<()> {
    let mut produced: HashSet<&str> = HashSet::new();
    for (s, d) in steps {
        let exists_initially = dir.join(s).symlink_metadata().is_ok();
        if !exists_initially && !produced.contains(s.as_str()) {
            return Err(io::Error::new(
                io::ErrorKind::NotFound,
                format!("source not found: {s}"),
            ));
        }
        produced.insert(d.as_str());
    }
    for (s, d) in steps {
        std::fs::rename(dir.join(s), dir.join(d))?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;

    fn check(moves: &[(&str, &str)]) {
        let p = plan(moves).unwrap();
        let mut m: HashMap<String, String> = HashMap::new();
        for (i, (s, _)) in moves.iter().enumerate() {
            m.insert(s.to_string(), format!("c{i}"));
        }
        for (s, d) in &p {
            assert!(m.contains_key(s), "{p:?}");
            assert!(!m.contains_key(d), "{p:?}");
            let v = m.remove(s).unwrap();
            m.insert(d.clone(), v);
        }
        for (i, (_, d)) in moves.iter().enumerate() {
            assert_eq!(m.get(*d), Some(&format!("c{i}")));
        }
        assert_eq!(m.len(), moves.len());
    }

    #[test]
    fn plans() {
        check(&[("a", "b"), ("b", "a")]);
        check(&[("a", "b"), ("b", "c")]);
        check(&[("a", "b"), ("b", "c"), ("c", "a")]);
        check(&[("a", "b"), ("b", "c"), ("c", "a"), ("d", "e"), ("e", "d"), ("x", "a.tmp")]);
        check(&[("a", "b"), ("b", "a"), ("z", "y"), ("q", "z")]);
        assert_eq!(plan(&[("a", "a")]).unwrap(), vec![]);
    }

    #[test]
    fn tmp_name() {
        let p = plan(&[("a", "b"), ("b", "a"), ("a.tmp", "a.tmp")]).unwrap();
        assert!(p.iter().any(|(_, d)| d == "a.tmp.tmp"));
    }

    #[test]
    fn dups() {
        assert_eq!(
            plan(&[("a", "b"), ("a", "c")]),
            Err(PlanError::DuplicateSource("a".into()))
        );
        assert_eq!(
            plan(&[("a", "c"), ("b", "c")]),
            Err(PlanError::DuplicateTarget("c".into()))
        );
    }

    fn tmpdir(n: &str) -> std::path::PathBuf {
        let d = std::env::temp_dir().join(format!("renameplan-{}-{n}", std::process::id()));
        let _ = std::fs::remove_dir_all(&d);
        std::fs::create_dir_all(&d).unwrap();
        d
    }

    #[test]
    fn apply_swap() {
        let d = tmpdir("swap");
        std::fs::write(d.join("a"), "1").unwrap();
        std::fs::write(d.join("b"), "2").unwrap();
        let p = plan(&[("a", "b"), ("b", "a")]).unwrap();
        apply(&d, &p).unwrap();
        assert_eq!(std::fs::read_to_string(d.join("a")).unwrap(), "2");
        assert_eq!(std::fs::read_to_string(d.join("b")).unwrap(), "1");
        std::fs::remove_dir_all(&d).unwrap();
    }

    #[test]
    fn apply_missing() {
        let d = tmpdir("missing");
        std::fs::write(d.join("other"), "1").unwrap();
        let e = apply(&d, &[("x".into(), "y".into())]).unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::NotFound);
        assert!(!d.join("y").exists());
        assert!(d.join("other").exists());
        std::fs::remove_dir_all(&d).unwrap();
    }
}
