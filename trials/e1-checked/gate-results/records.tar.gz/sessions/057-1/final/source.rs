//! Parallel merge sort using scoped threads.

use std::ptr;
use std::thread;

const THRESHOLD: usize = 2048;

/// Sorts `v` ascending using a parallel merge sort.
pub fn sort_parallel(v: &mut [i64]) {
    sort_by_key_parallel(v, |x| *x);
}

/// Sorts `v` stably by `key` using a parallel merge sort.
pub fn sort_by_key_parallel<T, K, F>(v: &mut [T], key: F)
where
    T: Send,
    K: Ord,
    F: Fn(&T) -> K + Sync,
{
    sort_rec(v, &key);
}

fn sort_rec<T, K, F>(v: &mut [T], key: &F)
where
    T: Send,
    K: Ord,
    F: Fn(&T) -> K + Sync,
{
    let len = v.len();
    if len <= THRESHOLD {
        v.sort_by_key(key);
        return;
    }
    let mid = len / 2;
    {
        let (a, b) = v.split_at_mut(mid);
        thread::scope(|s| {
            s.spawn(|| sort_rec(a, key));
            sort_rec(b, key);
        });
    }
    merge(v, mid, key);
}

/// On drop, moves the remaining buffered left-run elements into the hole.
struct Hole<T> {
    buf: *mut T,
    l: usize,
    end: usize,
    dest: *mut T,
}

impl<T> Drop for Hole<T> {
    fn drop(&mut self) {
        unsafe {
            ptr::copy_nonoverlapping(self.buf.add(self.l), self.dest, self.end - self.l);
        }
    }
}

fn merge<T, K: Ord, F: Fn(&T) -> K>(v: &mut [T], mid: usize, key: &F) {
    let len = v.len();
    if mid == 0 || mid == len {
        return;
    }
    let mut buf: Vec<T> = Vec::with_capacity(mid);
    let vp = v.as_mut_ptr();
    unsafe {
        ptr::copy_nonoverlapping(vp, buf.as_mut_ptr(), mid);
        let mut hole = Hole {
            buf: buf.as_mut_ptr(),
            l: 0,
            end: mid,
            dest: vp,
        };
        let mut r = mid;
        while hole.l < mid && r < len {
            let rv = &*vp.add(r);
            let lv = &*hole.buf.add(hole.l);
            if key(rv) < key(lv) {
                ptr::copy_nonoverlapping(vp.add(r), hole.dest, 1);
                r += 1;
            } else {
                ptr::copy_nonoverlapping(hole.buf.add(hole.l), hole.dest, 1);
                hole.l += 1;
            }
            hole.dest = hole.dest.add(1);
        }
        // hole's drop copies the remaining left elements; right ones are in place.
    }
    // buf has len 0, so dropping it only frees memory.
}

#[cfg(test)]
mod tests {
    use super::*;

    fn xorshift(n: usize) -> Vec<i64> {
        let mut x: u64 = 88172645463325252;
        (0..n)
            .map(|_| {
                x ^= x << 13;
                x ^= x >> 7;
                x ^= x << 17;
                x as i64
            })
            .collect()
    }

    #[test]
    fn million() {
        let mut v = xorshift(1_000_000);
        let mut w = v.clone();
        w.sort();
        sort_parallel(&mut v);
        assert_eq!(v, w);
    }

    #[test]
    fn small() {
        let mut e: Vec<i64> = vec![];
        sort_parallel(&mut e);
        assert!(e.is_empty());
        let mut o = vec![5];
        sort_parallel(&mut o);
        assert_eq!(o, vec![5]);
        let mut a = vec![3i64; 10000];
        sort_parallel(&mut a);
        assert_eq!(a, vec![3i64; 10000]);
    }

    #[test]
    fn stable() {
        let mut v: Vec<(usize, usize)> = (0..100_000).map(|i| (i % 7, i)).collect();
        sort_by_key_parallel(&mut v, |p| p.0);
        let mut w = v.clone();
        w.sort();
        assert_eq!(v, w);
    }

    #[test]
    fn strings_non_copy() {
        let mut v: Vec<String> = xorshift(20000).iter().map(|x| (x % 1000).to_string()).collect();
        let mut w = v.clone();
        w.sort_by_key(|s| s.len());
        sort_by_key_parallel(&mut v, |s| s.len());
        assert_eq!(v, w);
    }
}
