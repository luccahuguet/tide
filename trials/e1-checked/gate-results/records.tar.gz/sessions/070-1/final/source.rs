use std::collections::{BTreeMap, BTreeSet, HashMap, HashSet};
use std::fs::Fs;
use std::io;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PlanError {
    DuplicateSource(String),
    DuplicateTarget(String),
}

#[pure]
pub fn plan(moves: &[(&str, &str)]) -> Result<Vec<(String, String)>, PlanError> {
    let mut srcs: HashSet<&str> = HashSet::new();
    let mut dsts: HashSet<&str> = HashSet::new();
    let mut names: HashSet<&str> = HashSet::new();
    for &(s, d) in moves {
        if !srcs.insert(s) {
            return Err(PlanError::DuplicateSource(s.to_string()));
        }
        if !dsts.insert(d) {
            return Err(PlanError::DuplicateTarget(d.to_string()));
        }
        names.insert(s);
        names.insert(d);
    }
    // Real moves, in input order.
    let real: Vec<(&str, &str)> = moves.iter().copied().filter(|(s, d)| s != d).collect();
    let mut by_src: HashMap<&str, usize> = HashMap::new();
    let mut by_dst: HashMap<&str, usize> = HashMap::new();
    for (i, &(s, d)) in real.iter().enumerate() {
        by_src.insert(s, i);
        by_dst.insert(d, i);
    }
    let mut done = vec![false; real.len()];
    let mut out: Vec<(String, String)> = Vec::new();

    // Chains: start from moves whose target is not a source, walk backwards.
    for i in 0..real.len() {
        if done[i] || by_src.contains_key(real[i].1) {
            continue;
        }
        let mut cur = i;
        loop {
            let (s, d) = real[cur];
            out.push((s.to_string(), d.to_string()));
            done[cur] = true;
            match by_dst.get(s) {
                Some(&p) if !done[p] => cur = p,
                _ => break,
            }
        }
    }

    // Remaining moves form cycles.
    for i in 0..real.len() {
        if done[i] {
            continue;
        }
        let (start, first_dst) = real[i];
        let mut tmp = format!("{start}.tmp");
        while names.contains(tmp.as_str()) {
            tmp.push_str(".tmp");
        }
        out.push((start.to_string(), tmp.clone()));
        done[i] = true;
        let mut need = start;
        loop {
            let p = by_dst[need];
            if p == i {
                break;
            }
            let (s, d) = real[p];
            out.push((s.to_string(), d.to_string()));
            done[p] = true;
            need = s;
        }
        out.push((tmp, first_dst.to_string()));
    }
    Ok(out)
}

pub fn apply(fs: &Fs, steps: &[(String, String)]) -> io::Result<()> {
    let mut available: BTreeSet<&str> = BTreeSet::new();
    let mut checked: BTreeMap<&str, bool> = BTreeMap::new();
    for (s, d) in steps {
        let s = s.as_str();
        if !available.contains(s) {
            let existed = match checked.get(s) {
                Some(&e) => e,
                None => {
                    let e = fs.metadata(s).is_ok();
                    checked.insert(s, e);
                    e
                }
            };
            if !existed {
                return Err(io::Error::new(
                    io::ErrorKind::NotFound,
                    format!("rename source not found: {s}"),
                ));
            }
        }
        available.insert(d.as_str());
    }
    for (s, d) in steps {
        fs.rename(s, d)?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    fn replay(moves: &[(&str, &str)]) {
        let steps = plan(moves).unwrap();
        let mut map: BTreeMap<String, usize> = BTreeMap::new();
        for (i, (s, _)) in moves.iter().enumerate() {
            map.insert(s.to_string(), i);
        }
        for (s, d) in &steps {
            assert!(map.contains_key(s), "missing source {s}");
            assert!(!map.contains_key(d), "target exists {d}");
            let v = map.remove(s).unwrap();
            map.insert(d.clone(), v);
        }
        let mut want: BTreeMap<String, usize> = BTreeMap::new();
        for (i, (_, d)) in moves.iter().enumerate() {
            want.insert(d.to_string(), i);
        }
        assert_eq!(map, want);
    }

    #[test]
    fn valid_plans() {
        replay(&[("a", "b"), ("b", "a")]);
        replay(&[("a", "b"), ("b", "c")]);
        replay(&[("a", "b"), ("b", "c"), ("c", "a")]);
        replay(&[("a", "a.tmp"), ("a.tmp", "a")]);
        replay(&[("x", "y"), ("a", "b"), ("b", "a"), ("q", "q"), ("y", "z")]);
        replay(&[("c", "a"), ("a", "b"), ("b", "c"), ("d", "e"), ("e", "d")]);
    }

    #[test]
    fn temp_name() {
        let p = plan(&[("a", "a.tmp"), ("a.tmp", "a")]).unwrap();
        assert_eq!(p[0], ("a".to_string(), "a.tmp.tmp".to_string()));
    }

    #[test]
    fn self_move() {
        assert_eq!(plan(&[("a", "a")]), Ok(vec![]));
    }

    #[test]
    fn duplicates() {
        assert_eq!(
            plan(&[("a", "b"), ("a", "c")]),
            Err(PlanError::DuplicateSource("a".to_string()))
        );
        assert_eq!(
            plan(&[("a", "c"), ("b", "c")]),
            Err(PlanError::DuplicateTarget("c".to_string()))
        );
    }

    #[sim_test(seeds = 20)]
    fn apply_swap(sim: SimRoot) {
        sim.world.file("a", "1");
        sim.world.file("b", "2");
        let steps = plan(&[("a", "b"), ("b", "a")]).unwrap();
        apply(&sim.fs, &steps).unwrap();
        assert_eq!(sim.fs.read_to_string("a").unwrap(), "2");
        assert_eq!(sim.fs.read_to_string("b").unwrap(), "1");
    }

    #[sim_test(seeds = 20)]
    fn apply_missing(sim: SimRoot) {
        sim.world.file("other", "z");
        let steps = vec![("x".to_string(), "y".to_string())];
        let e = apply(&sim.fs, &steps).unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::NotFound);
        assert!(sim.fs.metadata("y").is_err());
        assert_eq!(sim.fs.read_to_string("other").unwrap(), "z");
    }
}
