use std::process::ExitCode;

const USAGE: &str = "usage: colstats [--col N] [--sep C]";

#[derive(Debug, Clone, Copy, PartialEq)]
struct Options {
    col: usize,
    sep: char,
}

#[derive(Debug, PartialEq)]
enum Failure {
    /// Bad option: exit 2.
    Usage,
    /// Data error: message (without prefix), exit 1.
    Data(String),
}

/// Authority-free. `args` excludes the program name.
fn parse_args(args: &[String]) -> Result<Options, Failure> {
    let mut opts = Options { col: 1, sep: ',' };
    let mut it = args.iter();
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "--col" => {
                let v = it.next().ok_or(Failure::Usage)?;
                let n: usize = v.trim().parse().map_err(|_| Failure::Usage)?;
                if n == 0 {
                    return Err(Failure::Usage);
                }
                opts.col = n;
            }
            "--sep" => {
                let v = it.next().ok_or(Failure::Usage)?;
                let mut chars = v.chars();
                match (chars.next(), chars.next()) {
                    (Some(c), None) => opts.sep = c,
                    _ => return Err(Failure::Usage),
                }
            }
            _ => return Err(Failure::Usage),
        }
    }
    Ok(opts)
}

/// Authority-free. Returns the output line (with trailing newline).
fn compute(opts: &Options, input: &str) -> Result<String, Failure> {
    let mut count: u64 = 0;
    let mut sum: i64 = 0;
    let mut min: i64 = i64::MAX;
    let mut max: i64 = i64::MIN;
    for (idx, line) in input.lines().enumerate() {
        let lineno = idx + 1;
        if line.trim().is_empty() {
            continue;
        }
        let field = match line.split(opts.sep).nth(opts.col - 1) {
            Some(f) => f.trim(),
            None => {
                return Err(Failure::Data(format!(
                    "line {lineno}: expected at least {} fields",
                    opts.col
                )));
            }
        };
        let v: i64 = field.parse().map_err(|_| {
            Failure::Data(format!("line {lineno}: not an integer: {field:?}"))
        })?;
        sum = sum
            .checked_add(v)
            .ok_or_else(|| Failure::Data(String::from("overflow")))?;
        count += 1;
        if v < min {
            min = v;
        }
        if v > max {
            max = v;
        }
    }
    if count == 0 {
        Ok(String::from("count=0\n"))
    } else {
        Ok(format!("count={count} sum={sum} min={min} max={max}\n"))
    }
}

#[cfg(test)]
fn run(args: &[String], input: &str) -> Result<String, Failure> {
    let opts = parse_args(args)?;
    compute(&opts, input)
}

#[tide::main]
fn main(root: Root) -> ExitCode {
    let args: Vec<String> = root.env.args().skip(1).collect();
    let opts = match parse_args(&args) {
        Ok(o) => o,
        Err(_) => {
            eprintln!("{USAGE}");
            return ExitCode::from(2);
        }
    };
    let mut input = String::new();
    if let Err(e) = root.stdin.read_to_string(&mut input) {
        eprintln!("colstats: cannot read standard input: {e}");
        return ExitCode::FAILURE;
    }
    match compute(&opts, &input) {
        Ok(out) => {
            print!("{out}");
            ExitCode::SUCCESS
        }
        Err(Failure::Usage) => {
            eprintln!("{USAGE}");
            ExitCode::from(2)
        }
        Err(Failure::Data(msg)) => {
            eprintln!("colstats: {msg}");
            ExitCode::FAILURE
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn a(xs: &[&str]) -> Vec<String> {
        xs.iter().map(|s| s.to_string()).collect()
    }

    #[test]
    fn column_two() {
        assert_eq!(
            run(&a(&["--col", "2"]), "a,1\nb,-5\n\nc,10\n").unwrap(),
            "count=3 sum=6 min=-5 max=10\n"
        );
    }

    #[test]
    fn sep_and_col() {
        assert_eq!(
            run(&a(&["--sep", ";", "--col", "1"]), "4;x\n2;y\n").unwrap(),
            "count=2 sum=6 min=2 max=4\n"
        );
    }

    #[test]
    fn empty() {
        assert_eq!(run(&a(&[]), "").unwrap(), "count=0\n");
        assert_eq!(run(&a(&[]), "\n  \n").unwrap(), "count=0\n");
    }

    #[test]
    fn bad_line() {
        match run(&a(&[]), "1\nx\n") {
            Err(Failure::Data(m)) => assert!(m.starts_with("line 2: ")),
            other => panic!("unexpected {other:?}"),
        }
        match run(&a(&["--col", "3"]), "\n1,2\n") {
            Err(Failure::Data(m)) => assert!(m.starts_with("line 2: ")),
            other => panic!("unexpected {other:?}"),
        }
    }

    #[test]
    fn overflow() {
        assert_eq!(
            run(&a(&[]), "9223372036854775807\n1\n"),
            Err(Failure::Data(String::from("overflow")))
        );
    }

    #[test]
    fn bad_options() {
        assert_eq!(run(&a(&["--col", "0"]), ""), Err(Failure::Usage));
        assert_eq!(run(&a(&["--col"]), ""), Err(Failure::Usage));
        assert_eq!(run(&a(&["--sep", "ab"]), ""), Err(Failure::Usage));
        assert_eq!(run(&a(&["--bogus"]), ""), Err(Failure::Usage));
    }
}
