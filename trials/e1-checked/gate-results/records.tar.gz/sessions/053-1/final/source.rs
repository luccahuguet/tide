use std::collections::HashMap;
use std::process::ExitCode;

const USAGE: &str = "usage: envreport [--defaults FILE] NAME...";

/// Parse defaults file contents. On error returns (line number, reason).
fn parse_defaults(text: &str) -> Result<HashMap<String, String>, (usize, String)> {
    let mut map = HashMap::new();
    for (i, line) in text.lines().enumerate() {
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }
        let Some((k, v)) = line.split_once('=') else {
            return Err((i + 1, "missing '='".to_string()));
        };
        let k = k.trim();
        if k.is_empty() {
            return Err((i + 1, "empty key".to_string()));
        }
        map.insert(k.to_string(), v.to_string());
    }
    Ok(map)
}

/// Returns output lines and whether all names had values.
fn report(
    names: &[String],
    lookup: impl Fn(&str) -> Option<String>,
    defaults: &HashMap<String, String>,
) -> (String, bool) {
    let mut out = String::new();
    let mut all = true;
    for n in names {
        match lookup(n).or_else(|| defaults.get(n).cloned()) {
            Some(v) => {
                out.push_str(&format!("{n}={v}\n"));
            }
            None => {
                all = false;
                out.push_str(&format!("{n} is unset\n"));
            }
        }
    }
    (out, all)
}

fn run() -> Result<bool, String> {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut defaults_file: Option<String> = None;
    let mut names = Vec::new();
    let mut i = 0;
    while i < args.len() {
        if args[i] == "--defaults" && defaults_file.is_none() && names.is_empty() {
            let Some(f) = args.get(i + 1) else {
                return Err(USAGE.to_string());
            };
            defaults_file = Some(f.clone());
            i += 2;
        } else {
            names.push(args[i].clone());
            i += 1;
        }
    }
    if names.is_empty() {
        return Err(USAGE.to_string());
    }
    let defaults = match &defaults_file {
        None => HashMap::new(),
        Some(f) => {
            let text =
                std::fs::read_to_string(f).map_err(|e| format!("envreport: {f}: {e}"))?;
            parse_defaults(&text).map_err(|(l, r)| format!("envreport: {f}:{l}: {r}"))?
        }
    };
    let (out, all) = report(&names, |n| std::env::var(n).ok(), &defaults);
    print!("{out}");
    Ok(all)
}

fn main() -> ExitCode {
    match run() {
        Ok(true) => ExitCode::SUCCESS,
        Ok(false) => ExitCode::from(1),
        Err(msg) => {
            eprintln!("{msg}");
            ExitCode::from(2)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_defaults() {
        let m = parse_defaults("B=two\n# c\nA=zzz\n\nC=x=y\n  D  = sp \n").unwrap();
        assert_eq!(m["B"], "two");
        assert_eq!(m["A"], "zzz");
        assert_eq!(m["C"], "x=y");
        assert_eq!(m["D"], " sp ");
    }

    #[test]
    fn parse_errors() {
        assert_eq!(parse_defaults("oops\n").unwrap_err().0, 1);
        assert_eq!(parse_defaults("a=1\n =x\n").unwrap_err().0, 2);
    }

    #[test]
    fn reports() {
        let d = parse_defaults("B=two\nA=zzz\nC=x=y\n").unwrap();
        let names: Vec<String> = ["A", "B", "C", "E"].iter().map(|s| s.to_string()).collect();
        let (out, all) = report(&names, |n| (n == "A").then(|| "1".to_string()), &d);
        assert_eq!(out, "A=1\nB=two\nC=x=y\nE is unset\n");
        assert!(!all);
    }
}
