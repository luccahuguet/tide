//! A concurrent line server over TCP, and its client.

use std::io::{self, BufRead, BufReader, Write};
use std::net::{Net, TcpListener, TcpStream};
use std::task::{TaskError, Tasks};

/// Reverses the characters of a line (authority-free).
fn reverse_line(line: &str) -> String {
    line.chars().rev().collect()
}

/// Handles one connection; returns the number of lines answered.
fn handle(stream: TcpStream) -> io::Result<u64> {
    let mut reader = BufReader::new(&stream);
    let mut writer = &stream;
    let mut answered: u64 = 0;
    let mut buf = String::new();
    loop {
        buf.clear();
        let k = reader.read_line(&mut buf)?;
        if k == 0 || !buf.ends_with('\n') {
            break; // end of input (a trailing unterminated fragment is ignored)
        }
        let line = &buf[..buf.len() - 1];
        if line == "QUIT" {
            break;
        }
        let mut reply = reverse_line(line);
        reply.push('\n');
        writer.write_all(reply.as_bytes())?;
        writer.flush()?;
        answered += 1;
    }
    Ok(answered)
}

/// Accepts exactly `clients` connections, handles them concurrently, and
/// returns the total number of lines answered.
pub fn serve(tasks: &Tasks, listener: &TcpListener, clients: usize) -> io::Result<u64> {
    let result: Result<io::Result<u64>, TaskError> = tasks.scope(|s| {
        let mut handles = Vec::new();
        for _ in 0..clients {
            let (stream, _) = match listener.accept() {
                Ok(x) => x,
                Err(e) => return Ok(Err(e)),
            };
            handles.push(s.spawn(move || Ok(handle(stream))));
        }
        let mut total: u64 = 0;
        for h in handles {
            match h.join()? {
                Ok(n) => total += n,
                Err(e) => return Ok(Err(e)),
            }
        }
        Ok(Ok(total))
    });
    match result {
        Ok(r) => r,
        Err(e) => Err(io::Error::other(e)),
    }
}

/// Connects to `addr`, sends each line and reads its reply, then sends
/// `QUIT`; returns the replies.
pub fn exchange(net: &Net, addr: &str, lines: &[&str]) -> io::Result<Vec<String>> {
    let stream = net.connect(addr)?;
    let mut reader = BufReader::new(&stream);
    let mut writer = &stream;
    let mut replies = Vec::with_capacity(lines.len());
    for line in lines {
        let mut msg = String::with_capacity(line.len() + 1);
        msg.push_str(line);
        msg.push('\n');
        writer.write_all(msg.as_bytes())?;
        writer.flush()?;
        let mut buf = String::new();
        let k = reader.read_line(&mut buf)?;
        if k == 0 || !buf.ends_with('\n') {
            return Err(io::Error::new(
                io::ErrorKind::UnexpectedEof,
                "connection closed before reply",
            ));
        }
        buf.pop();
        replies.push(buf);
    }
    writer.write_all(b"QUIT\n")?;
    writer.flush()?;
    Ok(replies)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;
    use std::sync::mpsc::sync_channel;

    #[test]
    fn reverses() {
        assert_eq!(reverse_line("héllo"), "olléh");
        assert_eq!(reverse_line(""), "");
    }

    #[sim_test(seeds = 20)]
    fn three_clients(sim: SimRoot) {
        let listener = sim.net.bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let (n, a, b, c) = sim
            .tasks
            .scope(|s| -> Result<_, TaskError> {
                let srv = s.spawn(|| Ok(serve(&sim.tasks, &listener, 3)));
                let a = s.spawn(|| Ok(exchange(&sim.net, &addr, &["abc", "héllo"])));
                let b = s.spawn(|| Ok(exchange(&sim.net, &addr, &["x"])));
                let c = s.spawn(|| Ok(exchange(&sim.net, &addr, &[])));
                Ok((srv.join()?, a.join()?, b.join()?, c.join()?))
            })
            .unwrap();
        assert_eq!(a.unwrap(), vec!["cba".to_string(), "olléh".to_string()]);
        assert_eq!(b.unwrap(), vec!["x".to_string()]);
        assert_eq!(c.unwrap(), Vec::<String>::new());
        assert_eq!(n.unwrap(), 3);
    }

    #[sim_test(seeds = 20)]
    fn concurrent_connections(sim: SimRoot) {
        let listener = sim.net.bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let (tx, rx) = sync_channel::<()>(1, &sim.tasks);
        let (n, first, second) = sim
            .tasks
            .scope(|s| -> Result<_, TaskError> {
                let srv = s.spawn(|| Ok(serve(&sim.tasks, &listener, 2)));
                let net = &sim.net;
                let addr = &addr;
                let first = s.spawn(move || {
                    let r = (|| -> io::Result<String> {
                        let stream = net.connect(addr)?;
                        let mut reader = BufReader::new(&stream);
                        let mut w = &stream;
                        w.write_all(b"hold\n")?;
                        let mut buf = String::new();
                        reader.read_line(&mut buf)?;
                        let _ = rx.recv();
                        w.write_all(b"QUIT\n")?;
                        Ok(buf)
                    })();
                    Ok(r)
                });
                let second = s.spawn(move || {
                    let r = exchange(net, addr, &["ok"]);
                    let _ = tx.send(());
                    Ok(r)
                });
                Ok((srv.join()?, first.join()?, second.join()?))
            })
            .unwrap();
        assert_eq!(first.unwrap(), "dloh\n");
        assert_eq!(second.unwrap(), vec!["ko".to_string()]);
        assert_eq!(n.unwrap(), 2);
    }
}
