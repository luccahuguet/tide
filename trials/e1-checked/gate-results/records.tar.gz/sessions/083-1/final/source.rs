use std::sync::Shared;
use std::task::{TaskError, Tasks};

/// How many candidate start positions a search scans between checks for
/// cancellation.
const CHUNK: usize = 4096;

/// Searches `hay` for `needle`, checking for cancellation at least every
/// `CHUNK` bytes. Returns `Ok(Some(pos))` on a match, `Ok(None)` if there is
/// none, and `Err(())` if the search was cancelled.
fn search(tasks: &Tasks, hay: &[u8], needle: &[u8]) -> Result<Option<usize>, ()> {
    let n = needle.len();
    if n > hay.len() {
        return Ok(None);
    }
    let last_start = hay.len() - n; // inclusive
    let mut start = 0usize;
    while start <= last_start {
        if tasks.checkpoint().is_err() {
            return Err(());
        }
        // Candidate start positions in this chunk: start .. start + CHUNK.
        let chunk_last = std::cmp::min(start + CHUNK - 1, last_start);
        let window = &hay[start..chunk_last + n];
        if let Some(off) = window.windows(n).position(|w| w == needle) {
            return Ok(Some(start + off));
        }
        start = chunk_last + 1;
    }
    Ok(None)
}

/// Searches each haystack in its own concurrent task; returns the index of a
/// haystack containing `needle` and the byte offset of its first occurrence
/// there. Once one task finds a match, the scope is cancelled so the others
/// stop early.
pub fn find_any(tasks: &Tasks, hays: &[String], needle: &str) -> Option<(usize, usize)> {
    assert!(!needle.is_empty(), "find_any: empty needle");
    let found: Shared<Option<(usize, usize)>> = Shared::new(None, tasks);
    let needle_b = needle.as_bytes();
    let res: Result<(), TaskError> = tasks.scope(|s| {
        for (i, hay) in hays.iter().enumerate() {
            let found = &found;
            let hay_b = hay.as_bytes();
            let _task = s.spawn(move || {
                match search(tasks, hay_b, needle_b) {
                    Ok(Some(pos)) => {
                        let _ = found.with(move |r| {
                            if r.is_none() {
                                *r = Some((i, pos));
                            }
                        });
                        s.cancel();
                    }
                    Ok(None) => {}
                    Err(()) => {}
                }
                Ok(())
            });
        }
        Ok(())
    });
    let _ = res;
    found.with(|r| *r).unwrap_or(None)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    fn s(x: &str) -> String {
        x.to_string()
    }

    #[sim_test(seeds = 20)]
    fn one_of_three(sim: SimRoot) {
        let hays = vec![s("hello world"), s("foo needle bar"), s("nothing here")];
        assert_eq!(find_any(&sim.tasks, &hays, "needle"), Some((1, 4)));
    }

    #[sim_test(seeds = 20)]
    fn none_found(sim: SimRoot) {
        let hays = vec![s("abc"), s("def"), s("")];
        assert_eq!(find_any(&sim.tasks, &hays, "zz"), None);
        let empty: Vec<String> = Vec::new();
        assert_eq!(find_any(&sim.tasks, &empty, "zz"), None);
    }

    #[sim_test(seeds = 20)]
    fn two_contain(sim: SimRoot) {
        let hays = vec![s("xxab"), s("nope"), s("ab")];
        let r = find_any(&sim.tasks, &hays, "ab");
        assert!(r == Some((0, 2)) || r == Some((2, 0)), "{:?}", r);
    }

    #[sim_test(seeds = 3)]
    fn big(sim: SimRoot) {
        let mut hays = Vec::new();
        for i in 0..8 {
            let mut h = "a".repeat(1_000_000);
            if i == 3 {
                h.replace_range(999_000..999_006, "needle");
            }
            hays.push(h);
        }
        assert_eq!(find_any(&sim.tasks, &hays, "needle"), Some((3, 999_000)));
    }

    #[sim_test(seeds = 5)]
    fn boundary(sim: SimRoot) {
        let mut h = "a".repeat(10_000);
        h.replace_range(4094..4098, "wxyz");
        let hays = vec![h, s("wxyz")];
        let r = find_any(&sim.tasks, &hays, "wxyz");
        assert!(r == Some((0, 4094)) || r == Some((1, 0)), "{:?}", r);
        let hays2 = vec![s("abcwxyzwxyz")];
        assert_eq!(find_any(&sim.tasks, &hays2, "wxyz"), Some((0, 3)));
        let hays3 = vec![s("wx")];
        assert_eq!(find_any(&sim.tasks, &hays3, "wxyz"), None);
    }

    #[test]
    #[should_panic]
    fn empty_needle_panics() {
        let sim = Root::sim(1);
        let hays = vec![s("abc")];
        let _ = find_any(&sim.tasks, &hays, "");
    }
}
