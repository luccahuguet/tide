use std::collections::BTreeMap;

#[derive(Debug, Default, Clone)]
struct Node {
    end: bool,
    children: BTreeMap<u8, Node>,
}

/// A set of strings stored in a byte-level prefix tree.
#[derive(Debug, Default, Clone)]
pub struct Trie {
    root: Node,
    len: usize,
}

fn bytes_to_string(mut v: Vec<u8>) -> String {
    match String::from_utf8(v.clone()) {
        Ok(s) => s,
        Err(e) => {
            v.truncate(e.utf8_error().valid_up_to());
            String::from_utf8(v).unwrap_or_default()
        }
    }
}

impl Trie {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn len(&self) -> usize {
        self.len
    }

    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    pub fn insert(&mut self, w: &str) -> bool {
        let mut node = &mut self.root;
        for &b in w.as_bytes() {
            node = node.children.entry(b).or_default();
        }
        if node.end {
            false
        } else {
            node.end = true;
            self.len += 1;
            true
        }
    }

    fn find(&self, p: &[u8]) -> Option<&Node> {
        let mut node = &self.root;
        for b in p {
            node = node.children.get(b)?;
        }
        Some(node)
    }

    pub fn contains(&self, w: &str) -> bool {
        self.find(w.as_bytes()).is_some_and(|n| n.end)
    }

    pub fn remove(&mut self, w: &str) -> bool {
        fn rec(node: &mut Node, w: &[u8]) -> bool {
            match w.split_first() {
                None => {
                    if node.end {
                        node.end = false;
                        true
                    } else {
                        false
                    }
                }
                Some((b, rest)) => {
                    let Some(child) = node.children.get_mut(b) else {
                        return false;
                    };
                    let removed = rec(child, rest);
                    if removed && !child.end && child.children.is_empty() {
                        node.children.remove(b);
                    }
                    removed
                }
            }
        }
        let removed = rec(&mut self.root, w.as_bytes());
        if removed {
            self.len -= 1;
        }
        removed
    }

    pub fn with_prefix(&self, p: &str) -> Vec<String> {
        fn collect(node: &Node, buf: &mut Vec<u8>, out: &mut Vec<String>) {
            if node.end {
                out.push(bytes_to_string(buf.clone()));
            }
            for (&b, child) in &node.children {
                buf.push(b);
                collect(child, buf, out);
                buf.pop();
            }
        }
        let mut out = Vec::new();
        if let Some(node) = self.find(p.as_bytes()) {
            let mut buf = p.as_bytes().to_vec();
            collect(node, &mut buf, &mut out);
        }
        out
    }

    pub fn longest_common_prefix(&self) -> String {
        if self.len == 0 {
            return String::new();
        }
        let mut buf = Vec::new();
        let mut node = &self.root;
        while !node.end && node.children.len() == 1 {
            let (&b, child) = node.children.iter().next().unwrap();
            buf.push(b);
            node = child;
        }
        bytes_to_string(buf)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn build(ws: &[&str]) -> Trie {
        let mut t = Trie::new();
        for w in ws {
            t.insert(w);
        }
        t
    }

    #[test]
    fn prefix_listing() {
        let t = build(&["car", "card", "care", "cat", "dog"]);
        assert_eq!(t.with_prefix("car"), vec!["car", "card", "care"]);
        assert_eq!(t.with_prefix(""), vec!["car", "card", "care", "cat", "dog"]);
        assert!(t.with_prefix("x").is_empty());
    }

    #[test]
    fn removal() {
        let mut t = build(&["car", "card", "care", "cat", "dog"]);
        assert!(t.remove("car"));
        assert!(!t.contains("car"));
        assert!(t.contains("card"));
        assert_eq!(t.with_prefix("ca"), vec!["card", "care", "cat"]);
        assert!(!t.remove("car"));
        assert!(!t.remove("zzz"));
        assert!(!t.remove("ca"));
        assert_eq!(t.len(), 4);
    }

    #[test]
    fn dup_and_len() {
        let mut t = Trie::new();
        assert!(t.insert("a"));
        assert!(!t.insert("a"));
        assert!(t.insert(""));
        assert!(!t.insert(""));
        assert_eq!(t.len(), 2);
        assert!(t.contains(""));
        assert!(t.remove(""));
        assert!(!t.contains(""));
        assert_eq!(t.len(), 1);
    }

    #[test]
    fn lcp() {
        let mut t = build(&["interview", "internet", "interval"]);
        assert_eq!(t.longest_common_prefix(), "inter");
        assert_eq!(Trie::new().longest_common_prefix(), "");
        t.insert("");
        assert_eq!(t.longest_common_prefix(), "");
        assert_eq!(build(&["solo"]).longest_common_prefix(), "solo");
        assert_eq!(build(&["é", "è"]).longest_common_prefix(), "");
    }

    #[test]
    fn unicode() {
        let t = build(&["über", "üben", "uber"]);
        assert_eq!(t.with_prefix("üb"), vec!["üben", "über"]);
    }
}
