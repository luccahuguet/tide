use std::fmt;
use std::ops::{Add, Mul, Neg, Sub};

#[derive(Debug, Clone, PartialEq)]
pub struct Poly {
    coeffs: Vec<i64>,
}

impl Poly {
    pub fn new(mut coeffs: Vec<i64>) -> Self {
        while coeffs.last() == Some(&0) {
            coeffs.pop();
        }
        Poly { coeffs }
    }

    pub fn coeffs(&self) -> &[i64] {
        &self.coeffs
    }

    pub fn degree(&self) -> Option<usize> {
        if self.coeffs.is_empty() {
            None
        } else {
            Some(self.coeffs.len() - 1)
        }
    }

    pub fn eval(&self, x: i64) -> Option<i64> {
        let mut acc: i64 = 0;
        for &c in self.coeffs.iter().rev() {
            acc = acc.checked_mul(x)?.checked_add(c)?;
        }
        Some(acc)
    }
}

fn add_impl(a: &Poly, b: &Poly) -> Poly {
    let n = a.coeffs.len().max(b.coeffs.len());
    let v = (0..n)
        .map(|i| a.coeffs.get(i).copied().unwrap_or(0) + b.coeffs.get(i).copied().unwrap_or(0))
        .collect();
    Poly::new(v)
}

fn sub_impl(a: &Poly, b: &Poly) -> Poly {
    let n = a.coeffs.len().max(b.coeffs.len());
    let v = (0..n)
        .map(|i| a.coeffs.get(i).copied().unwrap_or(0) - b.coeffs.get(i).copied().unwrap_or(0))
        .collect();
    Poly::new(v)
}

fn mul_impl(a: &Poly, b: &Poly) -> Poly {
    if a.coeffs.is_empty() || b.coeffs.is_empty() {
        return Poly::new(Vec::new());
    }
    let mut v = vec![0i64; a.coeffs.len() + b.coeffs.len() - 1];
    for (i, &x) in a.coeffs.iter().enumerate() {
        for (j, &y) in b.coeffs.iter().enumerate() {
            v[i + j] += x * y;
        }
    }
    Poly::new(v)
}

macro_rules! binop {
    ($tr:ident, $m:ident, $f:ident) => {
        impl $tr for Poly {
            type Output = Poly;
            fn $m(self, rhs: Poly) -> Poly {
                $f(&self, &rhs)
            }
        }
        impl<'a, 'b> $tr<&'b Poly> for &'a Poly {
            type Output = Poly;
            fn $m(self, rhs: &'b Poly) -> Poly {
                $f(self, rhs)
            }
        }
    };
}

binop!(Add, add, add_impl);
binop!(Sub, sub, sub_impl);
binop!(Mul, mul, mul_impl);

impl Neg for Poly {
    type Output = Poly;
    fn neg(self) -> Poly {
        Poly::new(self.coeffs.iter().map(|&c| -c).collect())
    }
}

impl<'a> Neg for &'a Poly {
    type Output = Poly;
    fn neg(self) -> Poly {
        Poly::new(self.coeffs.iter().map(|&c| -c).collect())
    }
}

impl fmt::Display for Poly {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if self.coeffs.is_empty() {
            return write!(f, "0");
        }
        let mut first = true;
        for (deg, &c) in self.coeffs.iter().enumerate().rev() {
            if c == 0 {
                continue;
            }
            let neg = c < 0;
            let mag = c.unsigned_abs();
            if first {
                if neg {
                    write!(f, "-")?;
                }
            } else if neg {
                write!(f, " - ")?;
            } else {
                write!(f, " + ")?;
            }
            first = false;
            if deg == 0 || mag != 1 {
                write!(f, "{}", mag)?;
            }
            match deg {
                0 => {}
                1 => write!(f, "x")?,
                d => write!(f, "x^{}", d)?,
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn display() {
        assert_eq!(Poly::new(vec![5, -1, 3]).to_string(), "3x^2 - x + 5");
        assert_eq!(Poly::new(vec![-2, 0, 0, -1]).to_string(), "-x^3 - 2");
        assert_eq!(Poly::new(vec![1]).to_string(), "1");
        assert_eq!(Poly::new(vec![-1]).to_string(), "-1");
        assert_eq!(Poly::new(vec![0, -2, 1]).to_string(), "x^2 - 2x");
        let z = Poly::new(vec![0, 0]);
        assert_eq!(z.to_string(), "0");
        assert_eq!(z.degree(), None);
        assert!(z.coeffs().is_empty());
    }

    #[test]
    fn ops() {
        let x = Poly::new(vec![0, 1]);
        let one = Poly::new(vec![1]);
        let p = (x.clone() + one.clone()) * (x.clone() - one.clone());
        assert_eq!(p.coeffs(), &[-1, 0, 1]);
        let s = &x + &one;
        assert_eq!(s.coeffs(), &[1, 1]);
        assert_eq!(x.coeffs(), &[0, 1]);
        assert_eq!(one.coeffs(), &[1]);
        let _ = &x * &one;
        let _ = &x - &one;
        let a = Poly::new(vec![3, 4]);
        assert_eq!(a.clone() - a, Poly::new(vec![]));
        assert_eq!((-Poly::new(vec![0, 1])).to_string(), "-x");
        assert_eq!(p.degree(), Some(2));
    }

    #[test]
    fn eval() {
        assert_eq!(Poly::new(vec![-1, 0, 1]).eval(3), Some(8));
        assert_eq!(Poly::new(vec![0, 0, 0, 1]).eval(3_000_000), None);
        assert_eq!(Poly::new(vec![]).eval(5), Some(0));
    }
}
