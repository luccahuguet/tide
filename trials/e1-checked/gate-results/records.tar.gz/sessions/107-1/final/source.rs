use std::thread;

const CHUNK: usize = 4096;

fn bucket_of(v: u32, edges: &[u32]) -> Option<usize> {
    let first = edges[0];
    let last = edges[edges.len() - 1];
    if v < first || v >= last {
        return None;
    }
    // number of edges <= v, minus one, is the bucket index
    let p = edges.partition_point(|&e| e <= v);
    Some(p - 1)
}

fn count_chunk(chunk: &[u32], edges: &[u32], counts: &mut [u64]) {
    for &v in chunk {
        if let Some(b) = bucket_of(v, edges) {
            counts[b] += 1;
        }
    }
}

/// Parallel histogram. Bucket `i` counts values `v` with
/// `edges[i] <= v < edges[i + 1]`.
pub fn histogram(values: &[u32], edges: &[u32]) -> Vec<u64> {
    assert!(edges.len() >= 2, "edges must have at least two entries");
    assert!(
        edges.windows(2).all(|w| w[0] < w[1]),
        "edges must increase strictly"
    );
    let nb = edges.len() - 1;
    let mut total = vec![0u64; nb];
    if values.is_empty() {
        return total;
    }

    let chunks: Vec<&[u32]> = values.chunks(CHUNK).collect();
    let workers = thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(4)
        .min(chunks.len())
        .max(1);

    let partials: Vec<Vec<u64>> = thread::scope(|s| {
        let handles: Vec<_> = (0..workers)
            .map(|w| {
                let chunks = &chunks;
                s.spawn(move || {
                    let mut counts = vec![0u64; nb];
                    let mut i = w;
                    while i < chunks.len() {
                        count_chunk(chunks[i], edges, &mut counts);
                        i += workers;
                    }
                    counts
                })
            })
            .collect();
        handles
            .into_iter()
            .map(|h| h.join().expect("worker panicked"))
            .collect()
    });

    for p in partials {
        for (t, c) in total.iter_mut().zip(p) {
            *t += c;
        }
    }
    total
}

#[cfg(test)]
mod tests {
    use super::*;

    fn xorshift(state: &mut u32) -> u32 {
        let mut x = *state;
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
        *state = x;
        x
    }

    #[test]
    fn basic() {
        assert_eq!(histogram(&[0, 1, 5, 9, 10, 99], &[0, 5, 10]), vec![2, 2]);
    }

    #[test]
    fn large_matches_sequential() {
        let mut s = 2463534242u32;
        let values: Vec<u32> = (0..1_000_000).map(|_| xorshift(&mut s)).collect();
        let mut edges: Vec<u32> = (0..17).map(|_| xorshift(&mut s)).collect();
        edges.sort();
        edges.dedup();
        let mut expected = vec![0u64; edges.len() - 1];
        for &v in &values {
            for i in 0..edges.len() - 1 {
                if edges[i] <= v && v < edges[i + 1] {
                    expected[i] += 1;
                }
            }
        }
        assert_eq!(histogram(&values, &edges), expected);
    }

    #[test]
    fn empty_values() {
        assert_eq!(histogram(&[], &[1, 2, 3]), vec![0, 0]);
    }

    #[test]
    #[should_panic]
    fn equal_edges_panic() {
        histogram(&[1], &[5, 5]);
    }

    #[test]
    #[should_panic]
    fn single_edge_panic() {
        histogram(&[1], &[5]);
    }

    #[test]
    #[should_panic]
    fn single_edge_empty_values_panic() {
        histogram(&[], &[5]);
    }
}
