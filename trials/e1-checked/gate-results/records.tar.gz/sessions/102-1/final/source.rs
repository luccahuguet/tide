use std::panic::{self, AssertUnwindSafe};
use std::sync::Mutex;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::thread;

#[derive(Debug, PartialEq, Clone, Copy)]
pub struct TooLong;

#[derive(Debug, PartialEq, Clone, Copy, Default)]
pub struct Summary {
    pub ok: u64,
    pub done: u32,
    pub too_long: u32,
    pub panicked: u32,
}

pub fn steps(n: u64) -> Result<u32, TooLong> {
    assert!(n != 0, "steps(0) is undefined");
    let mut n = n;
    let mut count: u32 = 0;
    while n != 1 {
        n = if n % 2 == 0 {
            n / 2
        } else {
            n.checked_mul(3)
                .and_then(|x| x.checked_add(1))
                .expect("attempt to multiply with overflow")
        };
        count += 1;
        if count > 200 {
            return Err(TooLong);
        }
    }
    Ok(count)
}

pub fn run_jobs(inputs: &[u64], workers: usize) -> Summary {
    let workers = workers.max(1).min(inputs.len().max(1));
    let next = AtomicUsize::new(0);
    let summary = Mutex::new(Summary::default());
    thread::scope(|s| {
        for _ in 0..workers {
            s.spawn(|| {
                loop {
                    let i = next.fetch_add(1, Ordering::SeqCst);
                    if i >= inputs.len() {
                        break;
                    }
                    let n = inputs[i];
                    let r = panic::catch_unwind(AssertUnwindSafe(|| steps(n)));
                    let mut sum = summary.lock().unwrap_or_else(|e| e.into_inner());
                    match r {
                        Ok(Ok(c)) => {
                            sum.ok += c as u64;
                            sum.done += 1;
                        }
                        Ok(Err(TooLong)) => sum.too_long += 1,
                        Err(_) => sum.panicked += 1,
                    }
                }
            });
        }
    });
    summary.into_inner().unwrap_or_else(|e| e.into_inner())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn basic_steps() {
        assert_eq!(steps(1), Ok(0));
        assert_eq!(steps(6), Ok(8));
        assert_eq!(steps(27), Ok(111));
        assert_eq!(steps(6171), Err(TooLong));
    }

    #[test]
    #[should_panic]
    fn zero_panics() {
        let _ = steps(0);
    }

    #[test]
    #[should_panic]
    fn max_panics() {
        let _ = steps(u64::MAX);
    }

    #[test]
    fn jobs() {
        let s = run_jobs(&[1, 6, 27, 0, u64::MAX, 6171], 2);
        assert_eq!(
            s,
            Summary { ok: 119, done: 3, too_long: 1, panicked: 2 }
        );
        assert_eq!(run_jobs(&[], 3), Summary::default());
    }
}
