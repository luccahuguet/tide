use std::collections::HashSet;
use std::fs;
use std::io;
use std::path::{Path, PathBuf};

#[derive(Debug, thiserror::Error)]
pub enum ExportError {
    #[error("bad report name: {0:?}")]
    BadName(String),
    #[error("duplicate report name: {0:?}")]
    Duplicate(String),
    #[error("i/o error: {0}")]
    Io(#[from] io::Error),
}

fn valid_name(name: &str) -> bool {
    !name.is_empty()
        && !name.contains('\\')
        && !name.contains('\0')
        && name
            .split('/')
            .all(|c| !c.is_empty() && c != "." && c != "..")
}

/// Ensure `dir` is a real directory (not a symlink), creating it if missing.
fn ensure_dir(dir: &Path) -> io::Result<()> {
    match fs::symlink_metadata(dir) {
        Ok(m) => {
            if m.file_type().is_symlink() {
                Err(io::Error::other(format!(
                    "{} is a symbolic link",
                    dir.display()
                )))
            } else if m.is_dir() {
                Ok(())
            } else {
                Err(io::Error::other(format!(
                    "{} exists and is not a directory",
                    dir.display()
                )))
            }
        }
        Err(e) if e.kind() == io::ErrorKind::NotFound => match fs::create_dir(dir) {
            Ok(()) => Ok(()),
            Err(e) if e.kind() == io::ErrorKind::AlreadyExists => {
                let m = fs::symlink_metadata(dir)?;
                if m.is_dir() && !m.file_type().is_symlink() {
                    Ok(())
                } else {
                    Err(e)
                }
            }
            Err(e) => Err(e),
        },
        Err(e) => Err(e),
    }
}

fn write_one(out: &Path, name: &str, body: &str) -> io::Result<()> {
    let comps: Vec<&str> = name.split('/').collect();
    let mut dir: PathBuf = out.to_path_buf();
    for c in &comps[..comps.len() - 1] {
        dir.push(c);
        ensure_dir(&dir)?;
    }
    let file = dir.join(comps[comps.len() - 1]);
    if let Ok(m) = fs::symlink_metadata(&file) {
        if m.file_type().is_symlink() {
            // Replace the link itself rather than writing through it.
            fs::remove_file(&file)?;
        } else if m.is_dir() {
            return Err(io::Error::other(format!(
                "{} is a directory",
                file.display()
            )));
        }
    }
    fs::write(&file, body)
}

pub fn export(root: &Path, reports: &[(&str, &str)]) -> Result<usize, ExportError> {
    let mut seen = HashSet::new();
    for (name, _) in reports {
        if !valid_name(name) {
            return Err(ExportError::BadName(name.to_string()));
        }
        if !seen.insert(*name) {
            return Err(ExportError::Duplicate(name.to_string()));
        }
    }
    let out = root.join("out");
    ensure_dir(&out)?;
    for (name, body) in reports {
        write_one(&out, name, body)?;
    }
    Ok(reports.len())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tmp(tag: &str) -> PathBuf {
        let p = std::env::temp_dir().join(format!("export_test_{}_{}", tag, std::process::id()));
        let _ = fs::remove_dir_all(&p);
        fs::create_dir_all(&p).unwrap();
        p
    }

    #[test]
    fn writes_and_replaces() {
        let d = tmp("w");
        fs::create_dir(d.join("out")).unwrap();
        fs::write(d.join("out/a.txt"), "old").unwrap();
        let n = export(&d, &[("a.txt", "1"), ("2026/jan.txt", "2")]).unwrap();
        assert_eq!(n, 2);
        assert_eq!(fs::read_to_string(d.join("out/a.txt")).unwrap(), "1");
        assert_eq!(fs::read_to_string(d.join("out/2026/jan.txt")).unwrap(), "2");
        fs::remove_dir_all(&d).unwrap();
    }

    #[test]
    fn bad_names() {
        let d = tmp("b");
        match export(&d, &[("ok", "x"), ("../evil", "y")]) {
            Err(ExportError::BadName(n)) => assert_eq!(n, "../evil"),
            other => panic!("{other:?}"),
        }
        assert!(!d.join("out/ok").exists());
        assert!(!d.join("evil").exists());
        for n in ["/abs", "a//b", "a/./b", "", "a\\b", "a/", "..", "."] {
            assert!(matches!(export(&d, &[(n, "x")]), Err(ExportError::BadName(ref s)) if s == n));
        }
        assert!(!d.join("out").exists());
        fs::remove_dir_all(&d).unwrap();
    }

    #[test]
    fn duplicate() {
        let d = tmp("d");
        assert!(matches!(export(&d, &[("a", "1"), ("a", "2")]), Err(ExportError::Duplicate(ref s)) if s == "a"));
        assert!(!d.join("out").exists());
        fs::remove_dir_all(&d).unwrap();
    }

    #[test]
    fn out_is_file() {
        let d = tmp("f");
        fs::write(d.join("out"), "").unwrap();
        assert!(matches!(export(&d, &[("a", "1")]), Err(ExportError::Io(_))));
        fs::remove_dir_all(&d).unwrap();
    }
}
