use std::collections::BTreeMap;

#[derive(Debug, Default, Clone)]
struct Node {
    end: bool,
    children: BTreeMap<u8, Node>,
}

/// A set of strings stored in a byte-level prefix tree.
#[derive(Debug, Default, Clone)]
pub struct Trie {
    root: Node,
    len: usize,
}

fn bytes_to_string(mut bytes: Vec<u8>) -> String {
    match std::str::from_utf8(&bytes) {
        Ok(_) => {}
        Err(e) => {
            let n = e.valid_up_to();
            bytes.truncate(n);
        }
    }
    match String::from_utf8(bytes) {
        Ok(s) => s,
        Err(_) => String::new(),
    }
}

fn collect(node: &Node, buf: &mut Vec<u8>, out: &mut Vec<String>) {
    if node.end {
        out.push(bytes_to_string(buf.clone()));
    }
    for (b, child) in &node.children {
        buf.push(*b);
        collect(child, buf, out);
        buf.pop();
    }
}

/// Removes `w` below `node`; returns whether it was present.
fn remove_rec(node: &mut Node, w: &[u8]) -> bool {
    match w.split_first() {
        None => {
            if node.end {
                node.end = false;
                true
            } else {
                false
            }
        }
        Some((b, rest)) => {
            let (removed, prune) = match node.children.get_mut(b) {
                None => (false, false),
                Some(child) => {
                    let removed = remove_rec(child, rest);
                    (removed, removed && !child.end && child.children.is_empty())
                }
            };
            if prune {
                node.children.remove(b);
            }
            removed
        }
    }
}

impl Trie {
    pub fn new() -> Self {
        Trie { root: Node::default(), len: 0 }
    }

    pub fn insert(&mut self, w: &str) -> bool {
        let mut node = &mut self.root;
        for b in w.bytes() {
            node = node.children.entry(b).or_default();
        }
        if node.end {
            false
        } else {
            node.end = true;
            self.len += 1;
            true
        }
    }

    fn find(&self, p: &str) -> Option<&Node> {
        let mut node = &self.root;
        for b in p.bytes() {
            node = node.children.get(&b)?;
        }
        Some(node)
    }

    pub fn contains(&self, w: &str) -> bool {
        self.find(w).map(|n| n.end).unwrap_or(false)
    }

    pub fn remove(&mut self, w: &str) -> bool {
        let removed = remove_rec(&mut self.root, w.as_bytes());
        if removed {
            self.len -= 1;
        }
        removed
    }

    pub fn len(&self) -> usize {
        self.len
    }

    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    pub fn with_prefix(&self, p: &str) -> Vec<String> {
        let mut out = Vec::new();
        if let Some(node) = self.find(p) {
            let mut buf: Vec<u8> = p.as_bytes().to_vec();
            collect(node, &mut buf, &mut out);
        }
        out
    }

    pub fn longest_common_prefix(&self) -> String {
        if self.len == 0 {
            return String::new();
        }
        let mut buf: Vec<u8> = Vec::new();
        let mut node = &self.root;
        while !node.end && node.children.len() == 1 {
            match node.children.iter().next() {
                Some((b, child)) => {
                    buf.push(*b);
                    node = child;
                }
                None => break,
            }
        }
        bytes_to_string(buf)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn build(ws: &[&str]) -> Trie {
        let mut t = Trie::new();
        for w in ws {
            let _ = t.insert(w);
        }
        t
    }

    #[test]
    fn prefix_listing() {
        let t = build(&["car", "card", "care", "cat", "dog"]);
        assert_eq!(t.with_prefix("car"), vec!["car", "card", "care"]);
        assert_eq!(t.with_prefix(""), vec!["car", "card", "care", "cat", "dog"]);
        assert!(t.with_prefix("x").is_empty());
    }

    #[test]
    fn removal() {
        let mut t = build(&["car", "card", "care", "cat", "dog"]);
        assert!(t.remove("car"));
        assert!(!t.contains("car"));
        assert!(t.contains("card"));
        assert_eq!(t.with_prefix("ca"), vec!["card", "care", "cat"]);
        assert!(t.remove("dog"));
        assert!(t.with_prefix("d").is_empty());
        assert_eq!(t.len(), 3);
    }

    #[test]
    fn duplicates_and_absent() {
        let mut t = build(&["a", "b"]);
        assert!(!t.remove("c"));
        assert!(!t.remove(""));
        assert!(!t.insert("a"));
        assert_eq!(t.len(), 2);
        assert!(t.insert(""));
        assert!(t.contains(""));
        assert_eq!(t.len(), 3);
        assert!(t.remove(""));
        assert!(!t.contains(""));
        assert_eq!(t.len(), 2);
    }

    #[test]
    fn lcp() {
        let mut t = build(&["interview", "internet", "interval"]);
        assert_eq!(t.longest_common_prefix(), "inter");
        assert_eq!(Trie::new().longest_common_prefix(), "");
        let _ = t.insert("");
        assert_eq!(t.longest_common_prefix(), "");
        assert_eq!(build(&["solo"]).longest_common_prefix(), "solo");
        assert_eq!(build(&["über", "äb"]).longest_common_prefix(), "");
    }

    #[test]
    fn unicode() {
        let t = build(&["über", "üben", "uber"]);
        assert_eq!(t.with_prefix("üb"), vec!["üben", "über"]);
        assert_eq!(build(&["über", "üben"]).longest_common_prefix(), "übe");
    }
}
