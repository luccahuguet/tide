use std::collections::HashMap;
use std::fmt;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TemplateError {
    Unclosed { pos: usize },
    BadName { pos: usize },
    StrayBrace { pos: usize },
    Missing { name: String },
}

impl fmt::Display for TemplateError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            TemplateError::Unclosed { pos } => write!(f, "unclosed placeholder at {}", pos),
            TemplateError::BadName { pos } => write!(f, "bad placeholder name at {}", pos),
            TemplateError::StrayBrace { pos } => write!(f, "stray '}}' at {}", pos),
            TemplateError::Missing { name } => write!(f, "missing value for {}", name),
        }
    }
}

impl std::error::Error for TemplateError {}

#[derive(Debug, Clone, PartialEq, Eq)]
enum Part<'a> {
    Lit(&'a str),
    Var(&'a str),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Template<'a> {
    parts: Vec<Part<'a>>,
}

fn is_name(s: &str) -> bool {
    let b = s.as_bytes();
    if b.is_empty() {
        return false;
    }
    if !(b[0].is_ascii_alphabetic() || b[0] == b'_') {
        return false;
    }
    b[1..].iter().all(|c| c.is_ascii_alphanumeric() || *c == b'_')
}

impl<'a> Template<'a> {
    pub fn parse(src: &'a str) -> Result<Template<'a>, TemplateError> {
        let b = src.as_bytes();
        let mut parts = Vec::new();
        let mut lit_start = 0;
        let mut i = 0;
        while i < b.len() {
            match b[i] {
                b'{' => {
                    if i + 1 < b.len() && b[i + 1] == b'{' {
                        if lit_start < i + 1 {
                            parts.push(Part::Lit(&src[lit_start..i + 1]));
                        }
                        i += 2;
                        lit_start = i;
                    } else {
                        let close = match src[i + 1..].find('}') {
                            Some(off) => i + 1 + off,
                            None => return Err(TemplateError::Unclosed { pos: i }),
                        };
                        let name = &src[i + 1..close];
                        if !is_name(name) {
                            return Err(TemplateError::BadName { pos: i });
                        }
                        if lit_start < i {
                            parts.push(Part::Lit(&src[lit_start..i]));
                        }
                        parts.push(Part::Var(name));
                        i = close + 1;
                        lit_start = i;
                    }
                }
                b'}' => {
                    if i + 1 < b.len() && b[i + 1] == b'}' {
                        if lit_start < i + 1 {
                            parts.push(Part::Lit(&src[lit_start..i + 1]));
                        }
                        i += 2;
                        lit_start = i;
                    } else {
                        return Err(TemplateError::StrayBrace { pos: i });
                    }
                }
                _ => i += 1,
            }
        }
        if lit_start < b.len() {
            parts.push(Part::Lit(&src[lit_start..]));
        }
        Ok(Template { parts })
    }

    pub fn names(&self) -> Vec<&'a str> {
        let mut out: Vec<&'a str> = Vec::new();
        for p in &self.parts {
            if let Part::Var(n) = p {
                if !out.contains(n) {
                    out.push(*n);
                }
            }
        }
        out
    }

    pub fn render(&self, vars: &HashMap<&str, &str>) -> Result<String, TemplateError> {
        let mut out = String::new();
        for p in &self.parts {
            match p {
                Part::Lit(s) => out.push_str(s),
                Part::Var(n) => match vars.get(n) {
                    Some(v) => out.push_str(v),
                    None => return Err(TemplateError::Missing { name: n.to_string() }),
                },
            }
        }
        Ok(out)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn vars<'a>(kv: &[(&'a str, &'a str)]) -> HashMap<&'a str, &'a str> {
        kv.iter().cloned().collect()
    }

    #[test]
    fn case1() {
        let t = Template::parse("Hi {name}, {{ok}} {name}!").unwrap();
        assert_eq!(t.names(), vec!["name"]);
        assert_eq!(t.render(&vars(&[("name", "Ann")])).unwrap(), "Hi Ann, {ok} Ann!");
    }

    #[test]
    fn case2() {
        let t = Template::parse("{{{x}}}").unwrap();
        assert_eq!(t.render(&vars(&[("x", "1")])).unwrap(), "{1}");
        let t = Template::parse("}}").unwrap();
        assert_eq!(t.render(&HashMap::new()).unwrap(), "}");
    }

    #[test]
    fn case3() {
        let t = Template::parse("{a}{b}").unwrap();
        let e = t.render(&vars(&[("a", "1")])).unwrap_err();
        assert_eq!(e, TemplateError::Missing { name: "b".to_string() });
        assert_eq!(e.to_string(), "missing value for b");
    }

    #[test]
    fn case4() {
        assert_eq!(Template::parse("x {y"), Err(TemplateError::Unclosed { pos: 2 }));
        assert_eq!(Template::parse("{1x}"), Err(TemplateError::BadName { pos: 0 }));
        assert_eq!(Template::parse("{}"), Err(TemplateError::BadName { pos: 0 }));
        assert_eq!(Template::parse("{ a }"), Err(TemplateError::BadName { pos: 0 }));
        assert_eq!(Template::parse("a } b"), Err(TemplateError::StrayBrace { pos: 2 }));
        assert_eq!(TemplateError::StrayBrace { pos: 2 }.to_string(), "stray '}' at 2");
        assert_eq!(TemplateError::Unclosed { pos: 2 }.to_string(), "unclosed placeholder at 2");
        assert_eq!(TemplateError::BadName { pos: 0 }.to_string(), "bad placeholder name at 0");
    }

    #[test]
    fn case5() {
        let src = String::from("{a} {b} {a}");
        let names;
        {
            let t = Template::parse(&src).unwrap();
            names = t.names();
        }
        assert_eq!(names, vec!["a", "b"]);
    }
}
