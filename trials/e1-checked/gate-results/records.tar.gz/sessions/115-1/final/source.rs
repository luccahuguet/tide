use std::io::{Read, Write};
use std::process::ExitCode;

#[derive(Debug, PartialEq)]
struct Opts {
    col: usize,
    sep: char,
}

fn parse_args(args: &[String]) -> Result<Opts, String> {
    let mut opts = Opts { col: 1, sep: ',' };
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--col" => {
                let v = args.get(i + 1).ok_or("--col needs a value")?;
                let n: usize = v.parse().map_err(|_| format!("bad column: {v}"))?;
                if n == 0 {
                    return Err("column must be at least 1".into());
                }
                opts.col = n;
                i += 2;
            }
            "--sep" => {
                let v = args.get(i + 1).ok_or("--sep needs a value")?;
                let mut cs = v.chars();
                match (cs.next(), cs.next()) {
                    (Some(c), None) => opts.sep = c,
                    _ => return Err(format!("separator must be one character: {v:?}")),
                }
                i += 2;
            }
            other => return Err(format!("unknown argument: {other}")),
        }
    }
    Ok(opts)
}

#[derive(Debug, PartialEq)]
enum StatErr {
    Line(usize, String),
    Overflow,
}

fn compute(input: &str, opts: &Opts) -> Result<String, StatErr> {
    let mut count = 0u64;
    let mut sum: i64 = 0;
    let mut min = i64::MAX;
    let mut max = i64::MIN;
    for (idx, line) in input.lines().enumerate() {
        let ln = idx + 1;
        if line.trim().is_empty() {
            continue;
        }
        let field = line.split(opts.sep).nth(opts.col - 1).ok_or_else(|| {
            StatErr::Line(ln, format!("too few fields (need column {})", opts.col))
        })?;
        let f = field.trim();
        let v: i64 = f
            .parse()
            .map_err(|_| StatErr::Line(ln, format!("not an integer: {f:?}")))?;
        sum = sum.checked_add(v).ok_or(StatErr::Overflow)?;
        count += 1;
        min = min.min(v);
        max = max.max(v);
    }
    if count == 0 {
        Ok("count=0\n".into())
    } else {
        Ok(format!("count={count} sum={sum} min={min} max={max}\n"))
    }
}

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let opts = match parse_args(&args) {
        Ok(o) => o,
        Err(e) => {
            eprintln!("usage: colstats [--col N] [--sep C]: {e}");
            return ExitCode::from(2);
        }
    };
    let mut buf = Vec::new();
    if let Err(e) = std::io::stdin().read_to_end(&mut buf) {
        eprintln!("colstats: read error: {e}");
        return ExitCode::from(1);
    }
    let input = String::from_utf8_lossy(&buf);
    match compute(&input, &opts) {
        Ok(out) => {
            let mut so = std::io::stdout();
            let _ = so.write_all(out.as_bytes());
            let _ = so.flush();
            ExitCode::SUCCESS
        }
        Err(StatErr::Line(l, r)) => {
            eprintln!("colstats: line {l}: {r}");
            ExitCode::from(1)
        }
        Err(StatErr::Overflow) => {
            eprintln!("colstats: overflow");
            ExitCode::from(1)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn a(v: &[&str]) -> Vec<String> {
        v.iter().map(|s| s.to_string()).collect()
    }

    #[test]
    fn case1() {
        let o = parse_args(&a(&["--col", "2"])).unwrap();
        assert_eq!(
            compute("a,1\nb,-5\n\nc,10\n", &o).unwrap(),
            "count=3 sum=6 min=-5 max=10\n"
        );
    }

    #[test]
    fn case2() {
        let o = parse_args(&a(&["--sep", ";", "--col", "1"])).unwrap();
        assert_eq!(compute("4;x\n2;y\n", &o).unwrap(), "count=2 sum=6 min=2 max=4\n");
    }

    #[test]
    fn empty() {
        let o = parse_args(&[]).unwrap();
        assert_eq!(compute("", &o).unwrap(), "count=0\n");
    }

    #[test]
    fn errors() {
        let o = parse_args(&[]).unwrap();
        assert!(matches!(compute("1\nx\n", &o), Err(StatErr::Line(2, _))));
        assert_eq!(
            compute("9223372036854775807\n1\n", &o),
            Err(StatErr::Overflow)
        );
        let o2 = parse_args(&a(&["--col", "3"])).unwrap();
        assert!(matches!(compute("1,2\n", &o2), Err(StatErr::Line(1, _))));
    }

    #[test]
    fn bad_opts() {
        assert!(parse_args(&a(&["--col", "0"])).is_err());
        assert!(parse_args(&a(&["--col"])).is_err());
        assert!(parse_args(&a(&["--sep", "ab"])).is_err());
        assert!(parse_args(&a(&["--x"])).is_err());
    }
}
