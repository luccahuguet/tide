//! Run jobs concurrently and keep what finishes before a time limit.

use std::sync::mpsc;
use std::thread;
use std::time::{Duration, Instant};

/// The result of one job.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Outcome {
    Done,
    TimedOut,
}

/// Starts every job at once on its own thread; job `i` sleeps `jobs[i]`.
/// Returns outcomes in job order as soon as all jobs finish or `limit` passes.
pub fn run_batch(jobs: &[Duration], limit: Duration) -> Vec<Outcome> {
    let mut outcomes = vec![Outcome::TimedOut; jobs.len()];
    if jobs.is_empty() {
        return outcomes;
    }
    let start = Instant::now();
    let deadline = start + limit;
    let (tx, rx) = mpsc::channel::<usize>();
    for (i, &d) in jobs.iter().enumerate() {
        let tx = tx.clone();
        // Detached threads: a job still running past the deadline is simply abandoned.
        thread::spawn(move || {
            thread::sleep(d);
            let _ = tx.send(i);
        });
    }
    drop(tx);
    let mut remaining = jobs.len();
    while remaining > 0 {
        let now = Instant::now();
        if now >= deadline {
            break;
        }
        match rx.recv_timeout(deadline - now) {
            Ok(i) => {
                outcomes[i] = Outcome::Done;
                remaining -= 1;
            }
            Err(_) => break,
        }
    }
    outcomes
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ms(n: u64) -> Duration {
        Duration::from_millis(n)
    }

    #[test]
    fn mixed() {
        let t = Instant::now();
        let r = run_batch(&[ms(10), ms(500), ms(30)], ms(100));
        let e = t.elapsed();
        assert_eq!(r, vec![Outcome::Done, Outcome::TimedOut, Outcome::Done]);
        assert!(e >= ms(100) && e < ms(300), "{e:?}");
    }

    #[test]
    fn all_done() {
        let t = Instant::now();
        let r = run_batch(&[ms(5), ms(6)], ms(1000));
        let e = t.elapsed();
        assert_eq!(r, vec![Outcome::Done, Outcome::Done]);
        assert!(e >= ms(6) && e < ms(500), "{e:?}");
    }

    #[test]
    fn empty() {
        let t = Instant::now();
        assert_eq!(run_batch(&[], ms(1000)), vec![]);
        assert!(t.elapsed() < ms(100));
    }
}
