//! In-place partition and selection with loop invariants.

/// Reorders `v` so every element less than `pivot` precedes every other
/// element; returns how many are less. Allocates nothing.
#[ensures(result <= v.len())]
#[ensures(forall |i: usize| i < result ==> v[i] < pivot)]
#[ensures(forall |i: usize| result <= i && i < v.len() ==> v[i] >= pivot)]
pub fn partition(v: &mut [i32], pivot: i32) -> usize {
    let mut less = 0;
    for j in 0..v.len() {
        invariant!(less <= j);
        invariant!(forall |k: usize| k < less ==> v[k] < pivot);
        invariant!(forall |k: usize| less <= k && k < j ==> v[k] >= pivot);
        if v[j] < pivot {
            v.swap(less, j);
            less += 1;
        }
    }
    less
}

/// Returns the `k`-th smallest element (0-based) of `v`, reordering `v`.
#[requires(k < v.len())]
pub fn select_kth(v: &mut [i32], k: usize) -> i32 {
    assert!(k < v.len(), "select_kth: k out of range");
    let mut lo = 0;
    let mut hi = v.len();
    loop {
        invariant!(lo <= k && k < hi && hi <= v.len());
        let pivot = v[lo + (hi - lo) / 2];
        let c = partition(&mut v[lo..hi], pivot);
        if k < lo + c {
            hi = lo + c;
            continue;
        }
        let start = lo + c;
        if pivot == i32::MAX {
            // Everything in v[start..hi] is >= MAX, so equal to the pivot.
            return pivot;
        }
        let eq = partition(&mut v[start..hi], pivot + 1);
        if k < start + eq {
            return pivot;
        }
        lo = start + eq;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn xorshift(n: usize, seed: u32, modulo: Option<u32>) -> Vec<i32> {
        let mut x = seed;
        let mut out = Vec::with_capacity(n);
        for _ in 0..n {
            x ^= x << 13;
            x ^= x >> 17;
            x ^= x << 5;
            let val = match modulo {
                Some(m) => i32::try_from(x % m).unwrap(),
                None => x.cast_signed(),
            };
            out.push(val);
        }
        out
    }

    #[test]
    fn case1() {
        let mut v = [3, 1, 4, 1, 5, 9, 2, 6];
        let r = partition(&mut v, 4);
        assert_eq!(r, 4);
        assert!(v[..4].iter().all(|&x| x < 4));
        assert!(v[4..].iter().all(|&x| x >= 4));
        let mut s = v.to_vec();
        s.sort();
        assert_eq!(s, vec![1, 1, 2, 3, 4, 5, 6, 9]);
    }

    #[test]
    fn case2() {
        let mut v = [5, 6, 7, 5];
        assert_eq!(partition(&mut v, 5), 0);
        assert_eq!(v, [5, 6, 7, 5]);
        let mut e: [i32; 0] = [];
        assert_eq!(partition(&mut e, 3), 0);
    }

    #[test]
    fn extremes() {
        let mut v = [i32::MAX, i32::MIN, i32::MAX, 0];
        assert_eq!(select_kth(&mut v.clone(), 3), i32::MAX);
        assert_eq!(select_kth(&mut v.clone(), 2), i32::MAX);
        assert_eq!(select_kth(&mut v, 0), i32::MIN);
        let mut w = [7];
        assert_eq!(select_kth(&mut w, 0), 7);
    }

    #[test]
    fn case3() {
        for modulo in [None, Some(50), Some(3), Some(1)] {
            let base = xorshift(10_000, 2463534242, modulo);
            let mut sorted = base.clone();
            sorted.sort();
            for k in [0usize, 1, 4999, 9999] {
                let mut v = base.clone();
                assert_eq!(select_kth(&mut v, k), sorted[k]);
                let mut s = v.clone();
                s.sort();
                assert_eq!(s, sorted);
            }
        }
    }

    #[test]
    #[should_panic]
    fn case4() {
        let mut v = vec![1, 2, 3];
        let n = v.len();
        let _ = select_kth(&mut v, n);
    }
}
