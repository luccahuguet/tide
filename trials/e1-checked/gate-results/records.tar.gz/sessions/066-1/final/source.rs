use std::fs::Fs;
use std::io;

#[derive(Debug, PartialEq)]
pub struct Summary {
    pub files: u64,
    pub dirs: u64,
    pub bytes: u64,
    pub largest: Option<(String, u64)>,
}

fn join_path(a: &str, b: &str) -> String {
    if a.is_empty() {
        b.to_string()
    } else if a.ends_with('/') {
        format!("{a}{b}")
    } else {
        format!("{a}/{b}")
    }
}

fn walk(
    fs: &Fs,
    root: &str,
    rel: &str,
    files: &mut Vec<(String, u64)>,
    dirs: &mut u64,
) -> io::Result<()> {
    let full = if rel.is_empty() {
        root.to_string()
    } else {
        join_path(root, rel)
    };
    let mut names: Vec<(String, bool, u64)> = Vec::new();
    for entry in fs.read_dir(&full)? {
        let entry = entry?;
        let name = entry.file_name().to_string_lossy().into_owned();
        let ft = entry.file_type()?;
        if ft.is_dir() {
            names.push((name, true, 0));
        } else {
            let len = entry.metadata()?.len();
            names.push((name, false, len));
        }
    }
    names.sort();
    for (name, is_dir, len) in names {
        let child = join_path(rel, &name);
        if is_dir {
            *dirs += 1;
            walk(fs, root, &child, files, dirs)?;
        } else {
            files.push((child, len));
        }
    }
    Ok(())
}

fn collect(fs: &Fs, dir: &str) -> io::Result<(Vec<(String, u64)>, u64)> {
    let mut files = Vec::new();
    let mut dirs = 0u64;
    walk(fs, dir, "", &mut files, &mut dirs)?;
    Ok((files, dirs))
}

fn sort_files(files: &mut [(String, u64)]) {
    files.sort_by(|a, b| b.1.cmp(&a.1).then_with(|| a.0.cmp(&b.0)));
}

pub fn summarize(fs: &Fs, dir: &str) -> io::Result<Summary> {
    let (mut files, dirs) = collect(fs, dir)?;
    let mut bytes = 0u64;
    for (_, s) in &files {
        bytes += *s;
    }
    let count = files.len() as u64;
    sort_files(&mut files);
    let largest = files.into_iter().next();
    Ok(Summary {
        files: count,
        dirs,
        bytes,
        largest,
    })
}

pub fn top_n(fs: &Fs, dir: &str, n: usize) -> io::Result<Vec<(String, u64)>> {
    let (mut files, _) = collect(fs, dir)?;
    sort_files(&mut files);
    files.truncate(n);
    Ok(files)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    fn setup(sim: &SimRoot) {
        sim.world.file("data/a.txt", "12345");
        sim.world.file("data/sub/b.bin", "0123456789");
        sim.world.file("data/sub/deeper/c", "abcdefghij");
        sim.fs.create_dir_all("data/empty").unwrap();
    }

    #[sim_test(seeds = 20)]
    fn summary_data(sim: SimRoot) {
        setup(&sim);
        let s = summarize(&sim.fs, "data").unwrap();
        assert_eq!(
            s,
            Summary {
                files: 3,
                dirs: 3,
                bytes: 25,
                largest: Some(("sub/b.bin".to_string(), 10)),
            }
        );
    }

    #[sim_test(seeds = 20)]
    fn top(sim: SimRoot) {
        setup(&sim);
        assert_eq!(
            top_n(&sim.fs, "data", 2).unwrap(),
            vec![("sub/b.bin".to_string(), 10), ("sub/deeper/c".to_string(), 10)]
        );
        assert_eq!(top_n(&sim.fs, "data", 0).unwrap(), vec![]);
        assert_eq!(top_n(&sim.fs, "data", 10).unwrap().len(), 3);
    }

    #[sim_test(seeds = 20)]
    fn empty(sim: SimRoot) {
        setup(&sim);
        let s = summarize(&sim.fs, "data/empty").unwrap();
        assert_eq!(
            s,
            Summary { files: 0, dirs: 0, bytes: 0, largest: None }
        );
    }

    #[sim_test(seeds = 20)]
    fn missing(sim: SimRoot) {
        setup(&sim);
        let e = summarize(&sim.fs, "nope").unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::NotFound);
        let e = top_n(&sim.fs, "nope", 1).unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::NotFound);
    }
}
