use std::collections::HashSet;
use std::json;

#[derive(Debug, Clone, PartialEq, Encode, Decode)]
#[codec(rename_all = "camelCase")]
pub struct Inventory {
    pub warehouse: String,
    pub items: Vec<Item>,
}

#[derive(Debug, Clone, PartialEq, Encode, Decode)]
#[codec(rename_all = "camelCase")]
pub struct Item {
    pub sku: String,
    pub quantity: u32,
    pub unit_price_cents: u64,
    #[codec(default)]
    pub tags: Vec<String>,
    #[codec(default)]
    pub discontinued: Option<bool>,
}

#[derive(Debug, Clone, PartialEq, Encode, Decode)]
pub enum Change {
    Restock { sku: String, qty: u32 },
    Sell { sku: String, qty: u32 },
    Discontinue { sku: String },
}

#[derive(Debug, Error)]
pub enum LoadError {
    #[error("invalid json: {0}")]
    Json(json::Error),
    #[error("duplicate sku: {0}")]
    Duplicate(String),
}

#[derive(Debug, Error)]
pub enum ApplyError {
    #[error("invalid json: {0}")]
    Json(json::Error),
    #[error("unknown sku: {0}")]
    UnknownSku(String),
    #[error("insufficient quantity: {0}")]
    Insufficient(String),
    #[error("quantity overflow: {0}")]
    Overflow(String),
}

pub fn load(bytes: &[u8]) -> Result<Inventory, LoadError> {
    let inv: Inventory = json::decode::<Inventory>(bytes).map_err(LoadError::Json)?;
    let mut seen: HashSet<&str> = HashSet::new();
    for item in &inv.items {
        if !seen.insert(item.sku.as_str()) {
            return Err(LoadError::Duplicate(item.sku.clone()));
        }
    }
    Ok(inv)
}

fn find<'a>(items: &'a mut [Item], sku: &str) -> Result<&'a mut Item, ApplyError> {
    items
        .iter_mut()
        .find(|i| i.sku == sku)
        .ok_or_else(|| ApplyError::UnknownSku(sku.to_string()))
}

pub fn apply(inv: &mut Inventory, changes: &[u8]) -> Result<(), ApplyError> {
    let changes: Vec<Change> = json::decode::<Vec<Change>>(changes).map_err(ApplyError::Json)?;
    let mut items = inv.items.clone();
    for change in &changes {
        match change {
            Change::Restock { sku, qty } => {
                let item = find(&mut items, sku)?;
                item.quantity = item
                    .quantity
                    .checked_add(*qty)
                    .ok_or_else(|| ApplyError::Overflow(sku.clone()))?;
            }
            Change::Sell { sku, qty } => {
                let item = find(&mut items, sku)?;
                item.quantity = item
                    .quantity
                    .checked_sub(*qty)
                    .ok_or_else(|| ApplyError::Insufficient(sku.clone()))?;
            }
            Change::Discontinue { sku } => {
                let item = find(&mut items, sku)?;
                item.discontinued = Some(true);
            }
        }
    }
    inv.items = items;
    Ok(())
}

pub fn save(inv: &Inventory) -> Vec<u8> {
    json::encode(inv)
}

#[cfg(test)]
mod tests {
    use super::*;

    const INV: &str = r#"{"warehouse":"w1","items":[{"sku":"a","quantity":3,"unitPriceCents":250},{"sku":"b","quantity":0,"unitPriceCents":100,"tags":["x"]}]}"#;

    fn fresh() -> Inventory {
        load(INV.as_bytes()).unwrap()
    }

    fn qty(inv: &Inventory, sku: &str) -> u32 {
        inv.items.iter().find(|i| i.sku == sku).unwrap().quantity
    }

    #[test]
    fn loads() {
        let inv = fresh();
        assert_eq!(inv.warehouse, "w1");
        assert!(inv.items[0].tags.is_empty());
        assert_eq!(inv.items[1].tags, vec!["x".to_string()]);
        assert_eq!(inv.items[0].discontinued, None);
        assert_eq!(inv.items[1].discontinued, None);
        assert_eq!(inv.items[0].unit_price_cents, 250);
    }

    #[test]
    fn load_errors() {
        let dup = r#"{"warehouse":"w","items":[{"sku":"a","quantity":1,"unitPriceCents":1},{"sku":"a","quantity":2,"unitPriceCents":1}]}"#;
        assert!(matches!(load(dup.as_bytes()), Err(LoadError::Duplicate(s)) if s == "a"));
        assert!(matches!(load(b"{bad"), Err(LoadError::Json(_))));
    }

    #[test]
    fn applies() {
        let mut inv = fresh();
        apply(&mut inv, br#"[{"Sell":{"sku":"a","qty":2}},{"Restock":{"sku":"b","qty":5}}]"#).unwrap();
        assert_eq!(qty(&inv, "a"), 1);
        assert_eq!(qty(&inv, "b"), 5);
    }

    #[test]
    fn apply_errors() {
        let mut inv = fresh();
        let r = apply(&mut inv, br#"[{"Restock":{"sku":"b","qty":1}},{"Sell":{"sku":"a","qty":9}}]"#);
        assert!(matches!(r, Err(ApplyError::Insufficient(s)) if s == "a"));
        assert_eq!(inv, fresh());
        let r = apply(&mut inv, br#"[{"Sell":{"sku":"z","qty":1}}]"#);
        assert!(matches!(r, Err(ApplyError::UnknownSku(s)) if s == "z"));
        let r = apply(&mut inv, br#"[{"Restock":{"sku":"b","qty":1}},{"Restock":{"sku":"b","qty":4294967295}}]"#);
        assert!(matches!(r, Err(ApplyError::Overflow(s)) if s == "b"));
        assert_eq!(inv, fresh());
        assert!(matches!(apply(&mut inv, b"[{"), Err(ApplyError::Json(_))));
    }

    #[test]
    fn discontinue() {
        let mut inv = fresh();
        apply(&mut inv, br#"[{"Discontinue":{"sku":"a"}}]"#).unwrap();
        assert_eq!(inv.items[0].discontinued, Some(true));
    }

    #[test]
    fn roundtrip() {
        let mut inv = fresh();
        assert_eq!(load(&save(&inv)).unwrap(), inv);
        let s = String::from_utf8(save(&inv)).unwrap();
        assert!(s.contains("\"unitPriceCents\""));
        inv.items[1].discontinued = Some(false);
        assert_eq!(load(&save(&inv)).unwrap(), inv);
    }
}
