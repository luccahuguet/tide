use std::collections::BTreeMap;

#[derive(Debug, Default, Clone)]
struct Node {
    end: bool,
    children: BTreeMap<u8, Node>,
}

#[derive(Debug, Default, Clone)]
pub struct Trie {
    root: Node,
    count: usize,
}

fn bytes_to_string(bytes: &[u8]) -> String {
    match std::str::from_utf8(bytes) {
        Ok(s) => s.to_string(),
        Err(e) => {
            let n = e.valid_up_to();
            String::from_utf8_lossy(&bytes[..n]).into_owned()
        }
    }
}

fn collect(node: &Node, buf: &mut Vec<u8>, out: &mut Vec<String>) {
    if node.end {
        out.push(bytes_to_string(buf));
    }
    for (b, child) in &node.children {
        buf.push(*b);
        collect(child, buf, out);
        buf.pop();
    }
}

// Returns (removed, prune_this_node).
fn remove_rec(node: &mut Node, w: &[u8]) -> (bool, bool) {
    match w.split_first() {
        None => {
            if !node.end {
                return (false, false);
            }
            node.end = false;
            (true, node.children.is_empty())
        }
        Some((b, rest)) => {
            let (removed, prune) = match node.children.get_mut(b) {
                None => return (false, false),
                Some(child) => remove_rec(child, rest),
            };
            if prune {
                node.children.remove(b);
            }
            (removed, removed && !node.end && node.children.is_empty())
        }
    }
}

impl Trie {
    pub fn new() -> Self {
        Trie { root: Node::default(), count: 0 }
    }

    pub fn insert(&mut self, w: &str) -> bool {
        let mut node = &mut self.root;
        for b in w.bytes() {
            node = node.children.entry(b).or_default();
        }
        if node.end {
            false
        } else {
            node.end = true;
            self.count += 1;
            true
        }
    }

    pub fn contains(&self, w: &str) -> bool {
        let mut node = &self.root;
        for b in w.bytes() {
            match node.children.get(&b) {
                Some(c) => node = c,
                None => return false,
            }
        }
        node.end
    }

    pub fn remove(&mut self, w: &str) -> bool {
        let (removed, _) = remove_rec(&mut self.root, w.as_bytes());
        if removed {
            self.count -= 1;
        }
        removed
    }

    pub fn len(&self) -> usize {
        self.count
    }

    pub fn is_empty(&self) -> bool {
        self.count == 0
    }

    pub fn with_prefix(&self, p: &str) -> Vec<String> {
        let mut node = &self.root;
        for b in p.bytes() {
            match node.children.get(&b) {
                Some(c) => node = c,
                None => return Vec::new(),
            }
        }
        let mut buf: Vec<u8> = p.as_bytes().to_vec();
        let mut out = Vec::new();
        collect(node, &mut buf, &mut out);
        out
    }

    pub fn longest_common_prefix(&self) -> String {
        if self.count == 0 {
            return String::new();
        }
        let mut buf: Vec<u8> = Vec::new();
        let mut node = &self.root;
        while !node.end && node.children.len() == 1 {
            let (b, child) = node.children.iter().next().unwrap();
            buf.push(*b);
            node = child;
        }
        bytes_to_string(&buf)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn build(ws: &[&str]) -> Trie {
        let mut t = Trie::new();
        for w in ws {
            assert!(t.insert(w));
        }
        t
    }

    #[test]
    fn prefix_listing() {
        let t = build(&["car", "card", "care", "cat", "dog"]);
        assert_eq!(t.with_prefix("car"), vec!["car", "card", "care"]);
        assert_eq!(t.with_prefix(""), vec!["car", "card", "care", "cat", "dog"]);
        assert_eq!(t.with_prefix("x"), Vec::<String>::new());
    }

    #[test]
    fn removal() {
        let mut t = build(&["car", "card", "care", "cat", "dog"]);
        assert!(t.remove("car"));
        assert!(!t.contains("car"));
        assert!(t.contains("card"));
        assert_eq!(t.with_prefix("ca"), vec!["card", "care", "cat"]);
        assert!(!t.remove("car"));
        assert!(!t.remove("ca"));
        assert!(!t.remove("zzz"));
        assert_eq!(t.len(), 4);
        assert!(t.remove("dog"));
        assert_eq!(t.with_prefix("d"), Vec::<String>::new());
        assert_eq!(t.len(), 3);
    }

    #[test]
    fn counting() {
        let mut t = build(&["a", "b"]);
        assert!(!t.insert("a"));
        assert_eq!(t.len(), 2);
        assert!(t.insert(""));
        assert!(!t.insert(""));
        assert!(t.contains(""));
        assert_eq!(t.len(), 3);
        assert!(t.remove(""));
        assert!(!t.contains(""));
        assert_eq!(t.len(), 2);
    }

    #[test]
    fn lcp() {
        let mut t = build(&["interview", "internet", "interval"]);
        assert_eq!(t.longest_common_prefix(), "inter");
        assert_eq!(Trie::new().longest_common_prefix(), "");
        t.insert("");
        assert_eq!(t.longest_common_prefix(), "");
        let one = build(&["hello"]);
        assert_eq!(one.longest_common_prefix(), "hello");
        let u = build(&["ä", "ü"]);
        assert_eq!(u.longest_common_prefix(), "");
    }

    #[test]
    fn unicode() {
        let t = build(&["über", "üben", "uber"]);
        assert_eq!(t.with_prefix("üb"), vec!["üben", "über"]);
    }
}
