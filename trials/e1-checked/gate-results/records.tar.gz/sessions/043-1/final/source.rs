use std::io::{self, Write};
use std::process::ExitCode;

const USAGE: &str = "usage: findtext [-i] PATTERN FILE...";

struct Args {
    ignore_case: bool,
    pattern: String,
    files: Vec<String>,
}

fn parse_args(args: &[String]) -> Option<Args> {
    let mut ignore_case = false;
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "--" {
            i += 1;
            break;
        }
        if a.starts_with('-') && a.len() > 1 {
            if a == "-i" {
                ignore_case = true;
                i += 1;
            } else {
                return None;
            }
        } else {
            break;
        }
    }
    let pattern = args.get(i)?.clone();
    let files: Vec<String> = args[i + 1..].to_vec();
    if files.is_empty() {
        return None;
    }
    Some(Args {
        ignore_case,
        pattern,
        files,
    })
}

/// Returns (line number, line) pairs of matching lines.
fn matching_lines<'a>(text: &'a str, pattern: &str, ignore_case: bool) -> Vec<(usize, &'a str)> {
    let pat_lower = pattern.to_ascii_lowercase();
    let mut out = Vec::new();
    let mut rest = text;
    let mut n = 0;
    while !rest.is_empty() {
        n += 1;
        let (line, next) = match rest.find('\n') {
            Some(p) => (&rest[..p], &rest[p + 1..]),
            None => (rest, ""),
        };
        rest = next;
        let line = line.strip_suffix('\r').unwrap_or(line);
        let hit = if ignore_case {
            line.to_ascii_lowercase().contains(&pat_lower)
        } else {
            line.contains(pattern)
        };
        if hit {
            out.push((n, line));
        }
    }
    out
}

fn main() -> ExitCode {
    let argv: Vec<String> = std::env::args().skip(1).collect();
    let Some(args) = parse_args(&argv) else {
        eprintln!("{USAGE}");
        return ExitCode::from(2);
    };
    let stdout = io::stdout();
    let mut out = io::BufWriter::new(stdout.lock());
    let mut any_match = false;
    let mut any_error = false;
    for file in &args.files {
        let text = match std::fs::read(file) {
            Ok(bytes) => match String::from_utf8(bytes) {
                Ok(s) => s,
                Err(_) => {
                    let _ = out.flush();
                    eprintln!("findtext: {file}: invalid UTF-8");
                    any_error = true;
                    continue;
                }
            },
            Err(e) => {
                let _ = out.flush();
                eprintln!("findtext: {file}: {e}");
                any_error = true;
                continue;
            }
        };
        for (n, line) in matching_lines(&text, &args.pattern, args.ignore_case) {
            any_match = true;
            let _ = writeln!(out, "{file}:{n}:{line}");
        }
    }
    let _ = out.flush();
    if any_error {
        ExitCode::from(2)
    } else if any_match {
        ExitCode::SUCCESS
    } else {
        ExitCode::from(1)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn s(v: &[&str]) -> Vec<String> {
        v.iter().map(|x| x.to_string()).collect()
    }

    #[test]
    fn parse_ok() {
        let a = parse_args(&s(&["-i", "two", "a.txt"])).unwrap();
        assert!(a.ignore_case);
        assert_eq!(a.pattern, "two");
        assert_eq!(a.files, vec!["a.txt"]);
        let a = parse_args(&s(&["", "a.txt"])).unwrap();
        assert_eq!(a.pattern, "");
    }

    #[test]
    fn parse_bad() {
        assert!(parse_args(&s(&["two"])).is_none());
        assert!(parse_args(&s(&[])).is_none());
        assert!(parse_args(&s(&["-x", "two", "a.txt"])).is_none());
    }

    #[test]
    fn matching() {
        let a = "one\nTwo\nthree two\n";
        assert_eq!(matching_lines(a, "two", false), vec![(3, "three two")]);
        assert_eq!(
            matching_lines(a, "two", true),
            vec![(2, "Two"), (3, "three two")]
        );
        assert_eq!(matching_lines(a, "", false).len(), 3);
        assert!(matching_lines(a, "zzz", false).is_empty());
        let b = "nothing\r\ntwo\r\n";
        assert_eq!(matching_lines(b, "two", false), vec![(2, "two")]);
        assert_eq!(matching_lines("x\nlast", "last", false), vec![(2, "last")]);
    }
}
