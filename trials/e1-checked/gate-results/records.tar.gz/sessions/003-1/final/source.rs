//! Sentences of a text, borrowed from it.

#[derive(Debug, Clone, Copy)]
pub struct Doc<'a> {
    text: &'a str,
}

/// Lazy iterator over the sentences of a text.
#[derive(Debug, Clone)]
pub struct Sentences<'a> {
    rest: &'a str,
}

impl<'a> Sentences<'a> {
    fn new(text: &'a str) -> Self {
        Sentences { rest: text }
    }
}

/// Byte offset just past the first sentence end in `s`, or `s.len()`.
fn sentence_end(s: &str) -> usize {
    let mut it = s.char_indices().peekable();
    while let Some((i, c)) = it.next() {
        if c == '.' || c == '!' || c == '?' {
            match it.peek() {
                None => return i + c.len_utf8(),
                Some(&(_, n)) if n.is_whitespace() => return i + c.len_utf8(),
                _ => {}
            }
        }
    }
    s.len()
}

impl<'a> Iterator for Sentences<'a> {
    type Item = &'a str;
    fn next(&mut self) -> Option<&'a str> {
        loop {
            if self.rest.is_empty() {
                return None;
            }
            let rest = self.rest;
            let end = sentence_end(rest);
            let seg = rest[..end].trim();
            self.rest = &rest[end..];
            if !seg.is_empty() {
                return Some(seg);
            }
        }
    }
}

fn words<'a>(sentence: &'a str) -> impl Iterator<Item = &'a str> {
    sentence
        .split_whitespace()
        .map(|w| w.trim_matches(|c: char| c.is_ascii_punctuation()))
        .filter(|w| !w.is_empty())
}

/// Lazy iterator over the sentences containing a given word.
#[derive(Debug, Clone)]
pub struct WithWord<'a, 'w> {
    inner: Sentences<'a>,
    word: &'w str,
}

impl<'a, 'w> Iterator for WithWord<'a, 'w> {
    type Item = &'a str;
    fn next(&mut self) -> Option<&'a str> {
        let word = self.word;
        self.inner
            .by_ref()
            .find(|s| words(s).any(|w| w.eq_ignore_ascii_case(word)))
    }
}

impl<'a> Doc<'a> {
    pub fn new(text: &'a str) -> Self {
        Doc { text }
    }

    pub fn sentences(&self) -> Sentences<'a> {
        Sentences::new(self.text)
    }

    pub fn longest(&self) -> Option<&'a str> {
        let mut best: Option<(&'a str, usize)> = None;
        for s in self.sentences() {
            let n = s.chars().count();
            match best {
                Some((_, m)) if m >= n => {}
                _ => best = Some((s, n)),
            }
        }
        best.map(|(s, _)| s)
    }

    pub fn words_of(&self, i: usize) -> Option<Vec<&'a str>> {
        let s = self.sentences().nth(i)?;
        Some(words(s).collect())
    }

    pub fn with_word<'w>(&self, word: &'w str) -> WithWord<'a, 'w> {
        WithWord {
            inner: self.sentences(),
            word,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sents(t: &str) -> Vec<&str> {
        Doc::new(t).sentences().collect()
    }

    #[test]
    fn case1() {
        assert_eq!(
            sents("Hi there. How are you? Fine!"),
            vec!["Hi there.", "How are you?", "Fine!"]
        );
        assert_eq!(sents("a.b. c"), vec!["a.b.", "c"]);
        assert_eq!(sents("No end"), vec!["No end"]);
        assert!(sents("   ").is_empty());
        assert!(sents("").is_empty());
        assert_eq!(sents("x. . y"), vec!["x.", ".", "y"]);
    }

    #[test]
    fn case2() {
        assert_eq!(Doc::new("ab. cd. e.").longest(), Some("ab."));
        assert_eq!(Doc::new("  ").longest(), None);
        let d = Doc::new("Hi there. How are you? Fine!");
        assert_eq!(d.words_of(1), Some(vec!["How", "are", "you"]));
        assert_eq!(d.words_of(9), None);
        assert_eq!(Doc::new("\"Wow,\" -- he said.").words_of(0), Some(vec!["Wow", "he", "said"]));
    }

    #[test]
    fn case3() {
        let d = Doc::new("Hi there. How are you? Fine!");
        let v: Vec<&str> = d.with_word("HI").collect();
        assert_eq!(v, vec!["Hi there."]);
        let v: Vec<&str> = d.with_word("fine").collect();
        assert_eq!(v, vec!["Fine!"]);
        assert_eq!(d.with_word("nope").count(), 0);
    }

    #[test]
    fn case4() {
        let text = String::from("Hi there. How are you? Fine!");
        let it = {
            let d = Doc::new(&text);
            d.sentences()
        };
        assert_eq!(it.collect::<Vec<_>>(), vec!["Hi there.", "How are you?", "Fine!"]);
        let word = String::from("you");
        let it2 = {
            let d = Doc::new(&text);
            d.with_word(&word)
        };
        assert_eq!(it2.collect::<Vec<_>>(), vec!["How are you?"]);
    }
}
