use std::collections::HashMap;
use std::env::Env;
use std::fs::Fs;
use std::process::ExitCode;

const USAGE: &str = "usage: envreport [--defaults FILE] NAME...";

/// The result of a run: standard output, standard error, exit code.
#[derive(Debug, PartialEq)]
struct Outcome {
    out: String,
    err: String,
    code: u8,
}

fn fail(err: String) -> Outcome {
    Outcome { out: String::new(), err, code: 2 }
}

/// Authority-free: parses a defaults file's text.
fn parse_defaults(file: &str, text: &str) -> Result<HashMap<String, String>, String> {
    let mut map = HashMap::new();
    let mut pieces: Vec<&str> = text.split('\n').collect();
    if pieces.last() == Some(&"") {
        pieces.pop();
    }
    for (i, line) in pieces.iter().enumerate() {
        let n = i + 1;
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }
        let Some((key, value)) = line.split_once('=') else {
            return Err(format!("envreport: {file}:{n}: missing '=' in line"));
        };
        let key = key.trim();
        if key.is_empty() {
            return Err(format!("envreport: {file}:{n}: empty key"));
        }
        map.insert(key.to_string(), value.to_string());
    }
    Ok(map)
}

fn run(args: &[String], env: &Env, fs: &Fs) -> Outcome {
    let mut defaults_file: Option<String> = None;
    let mut names: Vec<String> = Vec::new();
    let mut it = args.iter().skip(1);
    while let Some(arg) = it.next() {
        if arg == "--defaults" {
            match it.next() {
                Some(f) => defaults_file = Some(f.clone()),
                None => return fail(format!("{USAGE}\n")),
            }
        } else {
            names.push(arg.clone());
        }
    }
    if names.is_empty() {
        return fail(format!("{USAGE}\n"));
    }
    let defaults = match &defaults_file {
        None => HashMap::new(),
        Some(f) => {
            let text = match fs.read_to_string(f) {
                Ok(t) => t,
                Err(e) => return fail(format!("envreport: {f}: {e}\n")),
            };
            match parse_defaults(f, &text) {
                Ok(m) => m,
                Err(msg) => return fail(format!("{msg}\n")),
            }
        }
    };
    let mut out = String::new();
    let mut all = true;
    for name in &names {
        let value = env.var(name).ok().or_else(|| defaults.get(name).cloned());
        match value {
            Some(v) => out.push_str(&format!("{name}={v}\n")),
            None => {
                all = false;
                out.push_str(&format!("{name} is unset\n"));
            }
        }
    }
    Outcome { out, err: String::new(), code: if all { 0 } else { 1 } }
}

#[tide::main]
fn main(root: Root) -> ExitCode {
    let args: Vec<String> = root.env.args().collect();
    let o = run(&args, &root.env, &root.fs);
    print!("{}", o.out);
    eprint!("{}", o.err);
    ExitCode::from(o.code)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn argv(a: &[&str]) -> Vec<String> {
        let mut v = vec![String::from("envreport")];
        v.extend(a.iter().map(|s| s.to_string()));
        v
    }

    #[test]
    fn case1_env_only() {
        let sim = Root::sim(1);
        sim.world.env_var("A", "1");
        let o = run(&argv(&["A", "B"]), &sim.env, &sim.fs);
        assert_eq!(o.out, "A=1\nB is unset\n");
        assert_eq!(o.code, 1);
    }

    #[test]
    fn case2_defaults() {
        let sim = Root::sim(2);
        sim.world.env_var("A", "1");
        sim.world.file("d.env", "B=two\n# c\nA=zzz\n\nC=x=y\n");
        let o = run(&argv(&["--defaults", "d.env", "A", "B", "C"]), &sim.env, &sim.fs);
        assert_eq!(o.out, "A=1\nB=two\nC=x=y\n");
        assert_eq!(o.code, 0);
    }

    #[test]
    fn case3_missing_file() {
        let sim = Root::sim(3);
        let o = run(&argv(&["--defaults", "nope.env", "A"]), &sim.env, &sim.fs);
        assert_eq!(o.code, 2);
        assert!(o.out.is_empty());
        assert!(o.err.starts_with("envreport: nope.env: "));
    }

    #[test]
    fn case4_bad_line() {
        let sim = Root::sim(4);
        sim.world.file("d.env", "oops\n");
        let o = run(&argv(&["--defaults", "d.env", "A"]), &sim.env, &sim.fs);
        assert_eq!(o.code, 2);
        assert!(o.out.is_empty());
        assert!(o.err.starts_with("envreport: d.env:1: "));
    }

    #[test]
    fn case5_no_args() {
        let sim = Root::sim(5);
        let o = run(&argv(&[]), &sim.env, &sim.fs);
        assert_eq!(o.code, 2);
        assert!(o.err.starts_with("usage: envreport"));
    }

    #[test]
    fn empty_key_and_trim() {
        assert!(parse_defaults("f", "x=1\n =2\n").unwrap_err().starts_with("envreport: f:2: "));
        let m = parse_defaults("f", "  K  = v \n").unwrap();
        assert_eq!(m.get("K").map(String::as_str), Some(" v "));
    }
}
