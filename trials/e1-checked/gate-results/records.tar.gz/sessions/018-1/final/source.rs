use std::io::{self, BufRead, BufReader, Write};
use std::net::{TcpListener, TcpStream};
use std::thread;

fn handle(stream: TcpStream) -> io::Result<u64> {
    let mut writer = stream.try_clone()?;
    let mut reader = BufReader::new(stream);
    let mut buf = Vec::new();
    let mut answered = 0u64;
    loop {
        buf.clear();
        let n = reader.read_until(b'\n', &mut buf)?;
        if n == 0 || buf.last() != Some(&b'\n') {
            break;
        }
        buf.pop();
        let line = String::from_utf8_lossy(&buf);
        if line == "QUIT" {
            break;
        }
        let mut reply: String = line.chars().rev().collect();
        reply.push('\n');
        writer.write_all(reply.as_bytes())?;
        writer.flush()?;
        answered += 1;
    }
    Ok(answered)
}

/// Accepts exactly `clients` connections, handling each concurrently on its
/// own thread. Returns the total number of lines answered.
pub fn serve(listener: &TcpListener, clients: usize) -> io::Result<u64> {
    thread::scope(|s| {
        let mut handles = Vec::with_capacity(clients);
        let mut accept_err = None;
        for _ in 0..clients {
            match listener.accept() {
                Ok((stream, _)) => handles.push(s.spawn(move || handle(stream))),
                Err(e) => {
                    accept_err = Some(e);
                    break;
                }
            }
        }
        let mut total = 0u64;
        let mut first_err = accept_err;
        for h in handles {
            match h.join() {
                Ok(Ok(n)) => total += n,
                Ok(Err(e)) => {
                    if first_err.is_none() {
                        first_err = Some(e);
                    }
                }
                Err(_) => {
                    if first_err.is_none() {
                        first_err = Some(io::Error::other("handler panicked"));
                    }
                }
            }
        }
        match first_err {
            Some(e) => Err(e),
            None => Ok(total),
        }
    })
}

/// Connects to `addr`, sends each line and reads its reply, then sends `QUIT`.
pub fn exchange(addr: &str, lines: &[&str]) -> io::Result<Vec<String>> {
    let stream = TcpStream::connect(addr)?;
    let mut writer = stream.try_clone()?;
    let mut reader = BufReader::new(stream);
    let mut replies = Vec::with_capacity(lines.len());
    for line in lines {
        writer.write_all(line.as_bytes())?;
        writer.write_all(b"\n")?;
        writer.flush()?;
        let mut reply = String::new();
        let n = reader.read_line(&mut reply)?;
        if n == 0 || !reply.ends_with('\n') {
            return Err(io::Error::new(
                io::ErrorKind::UnexpectedEof,
                "connection closed before reply",
            ));
        }
        reply.pop();
        replies.push(reply);
    }
    writer.write_all(b"QUIT\n")?;
    writer.flush()?;
    Ok(replies)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Read;

    #[test]
    fn three_clients() {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        thread::scope(|s| {
            let srv = s.spawn(|| serve(&listener, 3).unwrap());
            let a = s.spawn(|| exchange(&addr, &["abc", "héllo"]).unwrap());
            let b = s.spawn(|| exchange(&addr, &["x"]).unwrap());
            let c = s.spawn(|| exchange(&addr, &[]).unwrap());
            assert_eq!(a.join().unwrap(), vec!["cba", "olléh"]);
            assert_eq!(b.join().unwrap(), vec!["x"]);
            assert!(c.join().unwrap().is_empty());
            assert_eq!(srv.join().unwrap(), 3);
        });
    }

    #[test]
    fn concurrent() {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        thread::scope(|s| {
            let srv = s.spawn(|| serve(&listener, 2).unwrap());
            let mut first = TcpStream::connect(&addr).unwrap();
            first.write_all(b"hold\n").unwrap();
            let mut buf = [0u8; 5];
            first.read_exact(&mut buf).unwrap();
            assert_eq!(&buf, b"dloh\n");
            let r = exchange(&addr, &["ab"]).unwrap();
            assert_eq!(r, vec!["ba"]);
            drop(first);
            assert_eq!(srv.join().unwrap(), 2);
        });
    }
}
