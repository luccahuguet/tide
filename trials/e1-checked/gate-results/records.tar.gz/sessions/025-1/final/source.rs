use std::io::Write;
use std::process::ExitCode;

#[derive(Debug, PartialEq)]
struct Args {
    ignore_case: bool,
    pattern: String,
    files: Vec<String>,
}

fn parse_args(args: &[String]) -> Result<Args, String> {
    let mut ignore_case = false;
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "--" {
            i += 1;
            break;
        }
        if a.len() > 1 && a.starts_with('-') {
            if a == "-i" {
                ignore_case = true;
                i += 1;
                continue;
            }
            return Err(format!("unknown option '{a}'"));
        }
        break;
    }
    let rest = &args[i..];
    if rest.is_empty() {
        return Err("missing pattern".to_string());
    }
    if rest.len() < 2 {
        return Err("missing file".to_string());
    }
    Ok(Args {
        ignore_case,
        pattern: rest[0].clone(),
        files: rest[1..].to_vec(),
    })
}

/// Returns matching (line number, line) pairs.
fn search<'a>(text: &'a str, pattern: &str, ignore_case: bool) -> Vec<(usize, &'a str)> {
    let lower_pat = pattern.to_ascii_lowercase();
    let mut out = Vec::new();
    let mut rest = text;
    let mut n = 0;
    while !rest.is_empty() {
        n += 1;
        let (line, next) = match rest.find('\n') {
            Some(p) => (&rest[..p], &rest[p + 1..]),
            None => (rest, ""),
        };
        rest = next;
        let line = line.strip_suffix('\r').unwrap_or(line);
        let hit = if ignore_case {
            line.to_ascii_lowercase().contains(&lower_pat)
        } else {
            line.contains(pattern)
        };
        if hit {
            out.push((n, line));
        }
    }
    out
}

fn main() -> ExitCode {
    let argv: Vec<String> = std::env::args().skip(1).collect();
    let args = match parse_args(&argv) {
        Ok(a) => a,
        Err(msg) => {
            eprintln!("usage: findtext [-i] PATTERN FILE... ({msg})");
            return ExitCode::from(2);
        }
    };
    let stdout = std::io::stdout();
    let mut out = std::io::BufWriter::new(stdout.lock());
    let mut matched = false;
    let mut error = false;
    for file in &args.files {
        let bytes = match std::fs::read(file) {
            Ok(b) => b,
            Err(e) => {
                let _ = out.flush();
                eprintln!("findtext: {file}: {e}");
                error = true;
                continue;
            }
        };
        let text = match String::from_utf8(bytes) {
            Ok(t) => t,
            Err(_) => {
                let _ = out.flush();
                eprintln!("findtext: {file}: not valid UTF-8");
                error = true;
                continue;
            }
        };
        for (n, line) in search(&text, &args.pattern, args.ignore_case) {
            matched = true;
            if writeln!(out, "{file}:{n}:{line}").is_err() {
                return ExitCode::from(2);
            }
        }
    }
    if out.flush().is_err() {
        return ExitCode::from(2);
    }
    if error {
        ExitCode::from(2)
    } else if matched {
        ExitCode::SUCCESS
    } else {
        ExitCode::from(1)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn s(v: &[&str]) -> Vec<String> {
        v.iter().map(|x| x.to_string()).collect()
    }

    #[test]
    fn parse_ok() {
        let a = parse_args(&s(&["-i", "two", "a.txt"])).unwrap();
        assert!(a.ignore_case);
        assert_eq!(a.pattern, "two");
        assert_eq!(a.files, s(&["a.txt"]));
        let a = parse_args(&s(&["", "a.txt"])).unwrap();
        assert_eq!(a.pattern, "");
        let a = parse_args(&s(&["--", "-x", "a.txt"])).unwrap();
        assert_eq!(a.pattern, "-x");
    }

    #[test]
    fn parse_err() {
        assert!(parse_args(&s(&["two"])).is_err());
        assert!(parse_args(&s(&[])).is_err());
        assert!(parse_args(&s(&["-x", "two", "a.txt"])).is_err());
        assert!(parse_args(&s(&["-i"])).is_err());
    }

    #[test]
    fn search_cases() {
        let a = "one\nTwo\nthree two\n";
        let b = "nothing\r\ntwo\r\n";
        assert_eq!(search(a, "two", false), vec![(3, "three two")]);
        assert_eq!(search(b, "two", false), vec![(2, "two")]);
        assert_eq!(search(a, "two", true), vec![(2, "Two"), (3, "three two")]);
        assert!(search(a, "zzz", false).is_empty());
        assert_eq!(search(a, "", false).len(), 3);
        assert_eq!(search("x\nlast", "last", false), vec![(2, "last")]);
    }
}
