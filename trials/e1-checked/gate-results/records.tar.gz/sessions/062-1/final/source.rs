use std::task::{TaskError, Tasks};
use std::time::{Clock, Duration};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Outcome {
    Done,
    TimedOut,
}

/// Starts every job at once; job `i` sleeps `jobs[i]`. Jobs still working
/// when `limit` passes are reported as `TimedOut`.
pub fn run_batch(tasks: &Tasks, clock: &Clock, jobs: &[Duration], limit: Duration) -> Vec<Outcome> {
    if jobs.is_empty() {
        return Vec::new();
    }
    let deadline = clock.now() + limit;
    let result: Result<Vec<Outcome>, TaskError> = tasks.scope(|s| {
        s.set_deadline(deadline);
        let handles: Vec<_> = jobs
            .iter()
            .map(|&d| {
                s.spawn(move || {
                    Ok(match clock.sleep(d) {
                        Ok(()) => Outcome::Done,
                        Err(_) => Outcome::TimedOut,
                    })
                })
            })
            .collect();
        let mut out = Vec::with_capacity(handles.len());
        for h in handles {
            out.push(h.join().unwrap_or(Outcome::TimedOut));
        }
        Ok(out)
    });
    match result {
        Ok(v) => v,
        Err(_) => jobs.iter().map(|_| Outcome::TimedOut).collect(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    fn ms(n: u64) -> Duration {
        Duration::from_millis(n)
    }

    #[sim_test(seeds = 20)]
    fn mixed(sim: SimRoot) {
        let r = run_batch(&sim.tasks, &sim.clock, &[ms(10), ms(500), ms(30)], ms(100));
        assert_eq!(r, vec![Outcome::Done, Outcome::TimedOut, Outcome::Done]);
        assert_eq!(sim.elapsed(), ms(100));
    }

    #[sim_test(seeds = 20)]
    fn all_done(sim: SimRoot) {
        let r = run_batch(&sim.tasks, &sim.clock, &[ms(5), ms(6)], Duration::from_secs(1));
        assert_eq!(r, vec![Outcome::Done, Outcome::Done]);
        assert_eq!(sim.elapsed(), ms(6));
    }

    #[sim_test(seeds = 20)]
    fn empty(sim: SimRoot) {
        let r = run_batch(&sim.tasks, &sim.clock, &[], ms(100));
        assert_eq!(r, vec![]);
        assert_eq!(sim.elapsed(), Duration::ZERO);
    }
}
