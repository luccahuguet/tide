use std::par::join;

const THRESHOLD: usize = 2048;

/// Sorts `v` ascending with a parallel merge sort.
pub fn sort_parallel(v: &mut [i64]) {
    let n = v.len();
    if n <= THRESHOLD {
        v.sort_unstable();
        return;
    }
    let mid = n / 2;
    {
        let (a, b) = v.split_at_mut(mid);
        join(|| sort_parallel(a), || sort_parallel(b));
    }
    merge_i64(v, mid);
}

fn merge_i64(v: &mut [i64], mid: usize) {
    if v[mid - 1] <= v[mid] {
        return;
    }
    let mut out: Vec<i64> = Vec::with_capacity(v.len());
    let (a, b) = v.split_at(mid);
    let mut i = 0;
    let mut j = 0;
    while i < a.len() && j < b.len() {
        if b[j] < a[i] {
            out.push(b[j]);
            j += 1;
        } else {
            out.push(a[i]);
            i += 1;
        }
    }
    out.extend_from_slice(&a[i..]);
    out.extend_from_slice(&b[j..]);
    v.copy_from_slice(&out);
}

/// Sorts `v` stably by `key` with a parallel merge sort.
pub fn sort_by_key_parallel<T, K, F>(v: &mut [T], key: F)
where
    T: Send + Pure,
    K: Ord,
    F: Fn(&T) -> K + Sync + Send + Pure,
{
    sort_by_key_rec(v, &key);
}

fn sort_by_key_rec<T, K, F>(v: &mut [T], key: &F)
where
    T: Send + Pure,
    K: Ord,
    F: Fn(&T) -> K + Sync + Send + Pure,
{
    let n = v.len();
    if n <= THRESHOLD {
        v.sort_by_key(|x| key(x));
        return;
    }
    let mid = n / 2;
    {
        let (a, b) = v.split_at_mut(mid);
        join(|| sort_by_key_rec(a, key), || sort_by_key_rec(b, key));
    }
    merge_by_key(v, mid, key);
}

fn merge_by_key<T, K, F>(v: &mut [T], mid: usize, key: &F)
where
    K: Ord,
    F: Fn(&T) -> K,
{
    let n = v.len();
    if key(&v[mid - 1]) <= key(&v[mid]) {
        return;
    }
    // idx[k] = source position of the element that belongs at position k.
    let mut idx: Vec<usize> = Vec::with_capacity(n);
    let mut i = 0;
    let mut j = mid;
    while i < mid && j < n {
        if key(&v[j]) < key(&v[i]) {
            idx.push(j);
            j += 1;
        } else {
            idx.push(i);
            i += 1;
        }
    }
    while i < mid {
        idx.push(i);
        i += 1;
    }
    while j < n {
        idx.push(j);
        j += 1;
    }
    // Apply the permutation in place by following cycles with swaps.
    let mut done = vec![false; n];
    for start in 0..n {
        if done[start] {
            continue;
        }
        let mut cur = start;
        loop {
            done[cur] = true;
            let next = idx[cur];
            if next == start {
                break;
            }
            v.swap(cur, next);
            cur = next;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn xorshift(n: usize) -> Vec<i64> {
        let mut s: u64 = 0x9E37_79B9_7F4A_7C15;
        let mut out = Vec::with_capacity(n);
        for _ in 0..n {
            s ^= s << 13;
            s ^= s >> 7;
            s ^= s << 17;
            out.push(s.cast_signed());
        }
        out
    }

    #[test]
    fn million_matches_sort() {
        let mut v = xorshift(1_000_000);
        let mut e = v.clone();
        e.sort();
        sort_parallel(&mut v);
        assert_eq!(v, e);
    }

    #[test]
    fn small_and_dup_values() {
        let mut v = xorshift(10_000);
        for x in v.iter_mut() {
            *x %= 5;
        }
        let mut e = v.clone();
        e.sort();
        sort_parallel(&mut v);
        assert_eq!(v, e);
    }

    #[test]
    fn edge_cases() {
        let mut e: Vec<i64> = vec![];
        sort_parallel(&mut e);
        assert!(e.is_empty());
        let mut one = vec![5i64];
        sort_parallel(&mut one);
        assert_eq!(one, vec![5]);
        let mut same = vec![3i64; 10_000];
        sort_parallel(&mut same);
        assert_eq!(same, vec![3i64; 10_000]);

        let mut e2: Vec<(i64, i64)> = vec![];
        sort_by_key_parallel(&mut e2, |p| p.0);
        assert!(e2.is_empty());
        let mut one2 = vec![(1i64, 2i64)];
        sort_by_key_parallel(&mut one2, |p| p.0);
        assert_eq!(one2, vec![(1, 2)]);
        let mut same2: Vec<(i64, usize)> = (0..10_000).map(|i| (4i64, i)).collect();
        let exp = same2.clone();
        sort_by_key_parallel(&mut same2, |p| p.0);
        assert_eq!(same2, exp);
    }

    #[test]
    fn stable_pairs() {
        let mut v: Vec<(i64, i64)> = (0..100_000i64).map(|i| (i % 7, i)).collect();
        sort_by_key_parallel(&mut v, |p| p.0);
        let mut e = v.clone();
        e.sort();
        assert_eq!(v, e);
        assert_eq!(v.len(), 100_000);
        for w in v.windows(2) {
            assert!(w[0] < w[1]);
        }
    }

    #[test]
    fn by_key_random_stable() {
        let r = xorshift(50_000);
        let mut v: Vec<(i64, usize)> = r.iter().enumerate().map(|(i, x)| (x % 100, i)).collect();
        let mut e = v.clone();
        e.sort_by_key(|p| p.0);
        sort_by_key_parallel(&mut v, |p| p.0);
        assert_eq!(v, e);
    }

    #[test]
    fn non_clone_strings() {
        let mut v: Vec<String> = (0..5000).map(|i| format!("{}", (i * 37) % 1000)).collect();
        let mut e = v.clone();
        e.sort_by_key(|s| s.len());
        sort_by_key_parallel(&mut v, |s| s.len());
        assert_eq!(v, e);
    }
}
