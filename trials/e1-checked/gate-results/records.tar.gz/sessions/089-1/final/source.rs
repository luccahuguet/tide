use std::task::Cancelled;
use std::time::{Clock, Duration};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Report {
    pub calls: u32,
    pub last_ok: Option<u32>,
    pub elapsed: Duration,
}

pub fn watch(
    clock: &Clock,
    interval: Duration,
    misses: u32,
    mut probe: impl FnMut() -> bool,
) -> Result<Report, Cancelled> {
    if misses == 0 {
        panic!("misses must be at least 1");
    }
    let start = clock.now();
    let mut next = start;
    let mut calls: u32 = 0;
    let mut last_ok: Option<u32> = None;
    let mut consecutive: u32 = 0;
    loop {
        let called_at = clock.now();
        let index = calls;
        let ok = probe();
        calls = calls.saturating_add(1);
        if ok {
            last_ok = Some(index);
            consecutive = 0;
        } else {
            consecutive = consecutive.saturating_add(1);
        }
        if consecutive >= misses {
            return Ok(Report {
                calls,
                last_ok,
                elapsed: called_at.duration_since(start),
            });
        }
        let now = clock.now();
        if interval.is_zero() {
            next = now;
        } else {
            next += interval;
            while next < now {
                next += interval;
            }
        }
        clock.sleep_until(next)?;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    #[sim_test(seeds = 20)]
    fn sequence(sim: SimRoot) {
        let results = [true, true, false, true, false, false];
        let mut i = 0;
        let r = watch(&sim.clock, Duration::from_millis(100), 2, || {
            let v = results[i];
            i += 1;
            v
        })
        .unwrap();
        assert_eq!(
            r,
            Report { calls: 6, last_ok: Some(3), elapsed: Duration::from_millis(500) }
        );
        assert_eq!(sim.elapsed(), Duration::from_millis(500));
    }

    #[sim_test(seeds = 20)]
    fn slow_probe(sim: SimRoot) {
        let clock = &sim.clock;
        let mut first = true;
        let r = watch(clock, Duration::from_millis(100), 1, || {
            if first {
                first = false;
                clock.sleep(Duration::from_millis(250)).unwrap();
                true
            } else {
                false
            }
        })
        .unwrap();
        assert_eq!(
            r,
            Report { calls: 2, last_ok: Some(0), elapsed: Duration::from_millis(300) }
        );
    }

    #[sim_test(seeds = 20)]
    fn always_false(sim: SimRoot) {
        let r = watch(&sim.clock, Duration::from_millis(100), 1, || false).unwrap();
        assert_eq!(r, Report { calls: 1, last_ok: None, elapsed: Duration::ZERO });
        assert_eq!(sim.elapsed(), Duration::ZERO);
    }

    #[sim_test(seeds = 20)]
    #[should_panic]
    fn zero_misses(sim: SimRoot) {
        let _ = watch(&sim.clock, Duration::from_millis(100), 0, || true);
    }
}
