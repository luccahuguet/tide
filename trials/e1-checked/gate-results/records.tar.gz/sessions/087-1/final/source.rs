use std::task::{Panicked, TaskError, Tasks};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TooLong;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct Summary {
    pub ok: u64,
    pub done: u32,
    pub too_long: u32,
    pub panicked: u32,
}

/// Collatz steps from `n` to 1, with trapping arithmetic.
pub fn steps(n: u64) -> Result<u32, TooLong> {
    if n == 0 {
        panic!("steps(0) has no Collatz sequence");
    }
    let mut n = n;
    let mut count: u32 = 0;
    while n != 1 {
        if n % 2 == 0 {
            n = n / 2;
        } else {
            n = 3 * n + 1;
        }
        count += 1;
        if count > 200 {
            return Err(TooLong);
        }
    }
    Ok(count)
}

/// Runs `steps` on every input concurrently, at most `workers` at once,
/// each isolated so a panic does not stop the others.
pub fn run_jobs(tasks: &Tasks, inputs: &[u64], workers: usize) -> Summary {
    let limited = tasks.limit(workers.max(1));
    let results: Result<Vec<Result<Result<u32, TooLong>, Panicked>>, TaskError> =
        limited.scope(|s| {
            let mut handles = Vec::new();
            for &n in inputs {
                handles.push(s.spawn(move || Ok(tasks.spawn_isolated(move || steps(n)))));
            }
            let mut out = Vec::new();
            for h in handles {
                out.push(h.join()?);
            }
            Ok(out)
        });
    let mut summary = Summary::default();
    // Children never return Err; a scope failure would only come from cancellation.
    let results = results.unwrap_or_default();
    for r in results {
        match r {
            Ok(Ok(c)) => {
                summary.ok += u64::from(c);
                summary.done += 1;
            }
            Ok(Err(TooLong)) => summary.too_long += 1,
            Err(_) => summary.panicked += 1,
        }
    }
    summary
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    #[test]
    fn steps_values() {
        assert_eq!(steps(1), Ok(0));
        assert_eq!(steps(6), Ok(8));
        assert_eq!(steps(27), Ok(111));
        assert_eq!(steps(6171), Err(TooLong));
    }

    #[test]
    #[should_panic]
    fn steps_zero_panics() {
        let _ = steps(0);
    }

    #[test]
    #[should_panic]
    fn steps_max_panics() {
        let _ = steps(u64::MAX);
    }

    #[sim_test(seeds = 20)]
    fn jobs_summary(sim: SimRoot) {
        let s = run_jobs(&sim.tasks, &[1, 6, 27, 0, u64::MAX, 6171], 2);
        assert_eq!(
            s,
            Summary { ok: 119, done: 3, too_long: 1, panicked: 2 }
        );
    }

    #[sim_test(seeds = 5)]
    fn jobs_empty(sim: SimRoot) {
        let s = run_jobs(&sim.tasks, &[], 3);
        assert_eq!(s, Summary::default());
    }
}
