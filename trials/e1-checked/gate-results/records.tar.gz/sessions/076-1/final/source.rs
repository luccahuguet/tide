//! Parallel merge sort using scoped threads.

use std::cmp::Ordering;
use std::thread;

const THRESHOLD: usize = 2048;

fn merge_sort<T, C>(v: &mut [T], cmp: &C)
where
    T: Send + Clone,
    C: Fn(&T, &T) -> Ordering + Sync,
{
    let n = v.len();
    if n <= THRESHOLD {
        v.sort_by(|a, b| cmp(a, b));
        return;
    }
    let mid = n / 2;
    {
        let (left, right) = v.split_at_mut(mid);
        thread::scope(|s| {
            s.spawn(|| merge_sort(left, cmp));
            merge_sort(right, cmp);
        });
    }
    merge(v, mid, cmp);
}

/// Stable merge of sorted `v[..mid]` and `v[mid..]`.
fn merge<T: Clone, C: Fn(&T, &T) -> Ordering>(v: &mut [T], mid: usize, cmp: &C) {
    if mid == 0 || mid == v.len() || cmp(&v[mid - 1], &v[mid]) != Ordering::Greater {
        return;
    }
    let buf: Vec<T> = v[..mid].to_vec();
    let (mut i, mut j, mut k) = (0, mid, 0);
    while i < buf.len() && j < v.len() {
        if cmp(&v[j], &buf[i]) == Ordering::Less {
            v[k] = v[j].clone();
            j += 1;
        } else {
            v[k] = buf[i].clone();
            i += 1;
        }
        k += 1;
    }
    while i < buf.len() {
        v[k] = buf[i].clone();
        i += 1;
        k += 1;
    }
}

/// Sorts ascending in parallel.
pub fn sort_parallel(v: &mut [i64]) {
    merge_sort(v, &|a: &i64, b: &i64| a.cmp(b));
}

/// Sorts stably by key in parallel.
pub fn sort_by_key_parallel<T, K, F>(v: &mut [T], key: F)
where
    T: Send + Clone,
    K: Ord,
    F: Fn(&T) -> K + Sync,
{
    merge_sort(v, &|a: &T, b: &T| key(a).cmp(&key(b)));
}

#[cfg(test)]
mod tests {
    use super::*;

    fn xorshift(n: usize) -> Vec<i64> {
        let mut x: u64 = 0x2545F4914F6CDD1D;
        (0..n)
            .map(|_| {
                x ^= x << 13;
                x ^= x >> 7;
                x ^= x << 17;
                x as i64
            })
            .collect()
    }

    #[test]
    fn million() {
        let mut v = xorshift(1_000_000);
        let mut w = v.clone();
        w.sort();
        sort_parallel(&mut v);
        assert_eq!(v, w);
    }

    #[test]
    fn small() {
        let mut e: Vec<i64> = vec![];
        sort_parallel(&mut e);
        assert!(e.is_empty());
        let mut one = vec![5];
        sort_parallel(&mut one);
        assert_eq!(one, vec![5]);
        let mut eq = vec![3i64; 10000];
        sort_parallel(&mut eq);
        assert_eq!(eq, vec![3i64; 10000]);
    }

    #[test]
    fn stable() {
        let mut v: Vec<(i64, i64)> = (0..100_000).map(|i| (i % 7, i)).collect();
        sort_by_key_parallel(&mut v, |p| p.0);
        let mut w = v.clone();
        w.sort();
        assert_eq!(v, w);
    }
}
