use std::fs::{Fs, OpenOptions};
use std::io::{self, Write};

const CURRENT: &str = "current.log";
const OLD1: &str = "old.1.log";
const OLD2: &str = "old.2.log";

pub struct RotLog {
    fs: Fs,
    max_bytes: u64,
    size: u64,
}

fn size_of(fs: &Fs, p: &str) -> io::Result<u64> {
    match fs.metadata(p) {
        Ok(m) => Ok(m.len()),
        Err(e) if e.kind() == io::ErrorKind::NotFound => Ok(0),
        Err(e) => Err(e),
    }
}

impl RotLog {
    pub fn open(fs: &Fs, max_bytes: u64) -> io::Result<RotLog> {
        let size = size_of(fs, CURRENT)?;
        Ok(RotLog { fs: fs.clone(), max_bytes, size })
    }

    pub fn append(&mut self, line: &str) -> io::Result<()> {
        if line.contains('\n') {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "line contains a newline",
            ));
        }
        let add = (line.len() as u64) + 1;
        if self.size > 0 && self.size + add > self.max_bytes {
            self.rotate()?;
        }
        let mut f = self.fs.open_with(
            CURRENT,
            OpenOptions::new().append(true).create(true),
        )?;
        let mut buf = Vec::with_capacity(line.len() + 1);
        buf.extend_from_slice(line.as_bytes());
        buf.push(b'\n');
        f.write_all(&buf)?;
        self.size += add;
        Ok(())
    }

    fn rotate(&mut self) -> io::Result<()> {
        match self.fs.rename(OLD1, OLD2) {
            Ok(()) => {}
            Err(e) if e.kind() == io::ErrorKind::NotFound => {}
            Err(e) => return Err(e),
        }
        self.fs.rename(CURRENT, OLD1)?;
        self.size = 0;
        Ok(())
    }
}

pub fn read_all(fs: &Fs) -> io::Result<Vec<String>> {
    let mut out = Vec::new();
    for p in [OLD2, OLD1, CURRENT] {
        match fs.read_to_string(p) {
            Ok(s) => out.extend(s.lines().map(|l| l.to_string())),
            Err(e) if e.kind() == io::ErrorKind::NotFound => {}
            Err(e) => return Err(e),
        }
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    fn rd(fs: &Fs, p: &str) -> String {
        fs.read_to_string(p).unwrap()
    }

    #[sim_test(seeds = 20)]
    fn case1_and_2(sim: SimRoot) {
        let mut log = RotLog::open(&sim.fs, 10).unwrap();
        log.append("aaaa").unwrap();
        log.append("bbbb").unwrap();
        log.append("cc").unwrap();
        assert_eq!(rd(&sim.fs, "old.1.log"), "aaaa\nbbbb\n");
        assert_eq!(rd(&sim.fs, "current.log"), "cc\n");
        assert_eq!(read_all(&sim.fs).unwrap(), vec!["aaaa", "bbbb", "cc"]);
        log.append("dddddddd").unwrap();
        log.append("e").unwrap();
        assert_eq!(read_all(&sim.fs).unwrap(), vec!["cc", "dddddddd", "e"]);
    }

    #[sim_test(seeds = 20)]
    fn case3_newline(sim: SimRoot) {
        let mut log = RotLog::open(&sim.fs, 10).unwrap();
        log.append("x").unwrap();
        let e = log.append("a\nb").unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::InvalidInput);
        assert_eq!(rd(&sim.fs, "current.log"), "x\n");
        assert!(sim.fs.read_to_string("old.1.log").is_err());
    }

    #[sim_test(seeds = 20)]
    fn case4_long(sim: SimRoot) {
        let mut log = RotLog::open(&sim.fs, 10).unwrap();
        let long = "x".repeat(20);
        log.append(&long).unwrap();
        assert_eq!(rd(&sim.fs, "current.log"), format!("{long}\n"));
        log.append("y").unwrap();
        assert_eq!(rd(&sim.fs, "old.1.log"), format!("{long}\n"));
        assert_eq!(rd(&sim.fs, "current.log"), "y\n");
    }

    #[sim_test(seeds = 20)]
    fn case5_reopen(sim: SimRoot) {
        {
            let mut log = RotLog::open(&sim.fs, 10).unwrap();
            log.append("a").unwrap();
        }
        let mut log = RotLog::open(&sim.fs, 10).unwrap();
        log.append("b").unwrap();
        assert_eq!(rd(&sim.fs, "current.log"), "a\nb\n");
    }

    #[sim_test(seeds = 20)]
    fn reopen_counts_size(sim: SimRoot) {
        sim.world.file("current.log", "123456789\n");
        let mut log = RotLog::open(&sim.fs, 10).unwrap();
        log.append("z").unwrap();
        assert_eq!(rd(&sim.fs, "old.1.log"), "123456789\n");
        assert_eq!(read_all(&sim.fs).unwrap(), vec!["123456789", "z"]);
    }
}
