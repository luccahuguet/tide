use std::task::Cancelled;
use std::time::{Clock, Duration};

#[derive(Debug, PartialEq)]
pub struct Report {
    pub calls: u32,
    pub last_ok: Option<u32>,
    pub elapsed: Duration,
}

pub fn watch(
    clock: &Clock,
    interval: Duration,
    misses: u32,
    mut probe: impl FnMut() -> bool,
) -> Result<Report, Cancelled> {
    assert!(misses > 0, "misses must be at least 1");
    let start = clock.now();
    let mut calls: u32 = 0;
    let mut last_ok: Option<u32> = None;
    let mut consecutive: u32 = 0;
    let mut tick: u32 = 0;
    loop {
        let ok = probe();
        let called_at = clock.now();
        let index = calls;
        calls = calls.saturating_add(1);
        if ok {
            last_ok = Some(index);
            consecutive = 0;
        } else {
            consecutive = consecutive.saturating_add(1);
        }
        if consecutive >= misses {
            return Ok(Report {
                calls,
                last_ok,
                elapsed: called_at.duration_since(start),
            });
        }
        let iv = interval.as_nanos();
        if iv == 0 {
            continue;
        }
        let now = clock.now();
        let since = now.duration_since(start).as_nanos();
        // First tick at or after `now`; ticks strictly before `now` passed.
        let due = since / iv + if since % iv == 0 { 0 } else { 1 };
        let due = u32::try_from(due).unwrap_or(u32::MAX);
        tick = tick.saturating_add(1).max(due);
        let at = start + interval * tick;
        clock.sleep_until(at)?;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    #[sim_test(seeds = 20)]
    fn case1(sim: SimRoot) {
        let results = [true, true, false, true, false, false];
        let mut i = 0usize;
        let r = watch(&sim.clock, Duration::from_millis(100), 2, || {
            let v = results[i];
            i += 1;
            v
        })
        .unwrap();
        assert_eq!(
            r,
            Report { calls: 6, last_ok: Some(3), elapsed: Duration::from_millis(500) }
        );
        assert_eq!(sim.elapsed(), Duration::from_millis(500));
    }

    #[sim_test(seeds = 20)]
    fn case2(sim: SimRoot) {
        let mut first = true;
        let clock = &sim.clock;
        let r = watch(&sim.clock, Duration::from_millis(100), 1, || {
            if first {
                first = false;
                clock.sleep(Duration::from_millis(250)).unwrap();
                true
            } else {
                false
            }
        })
        .unwrap();
        assert_eq!(
            r,
            Report { calls: 2, last_ok: Some(0), elapsed: Duration::from_millis(300) }
        );
    }

    #[sim_test(seeds = 20)]
    fn case3(sim: SimRoot) {
        let r = watch(&sim.clock, Duration::from_millis(100), 1, || false).unwrap();
        assert_eq!(r, Report { calls: 1, last_ok: None, elapsed: Duration::ZERO });
    }

    #[test]
    #[should_panic]
    fn case4() {
        let sim = Root::sim(1);
        let _ = watch(&sim.clock, Duration::from_millis(100), 0, || true);
    }
}
