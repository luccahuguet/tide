//! A histogram computed in parallel.

const CHUNK: usize = 4096;

fn count_chunk(chunk: &[u32], edges: &[u32]) -> Vec<u64> {
    let buckets = edges.len() - 1;
    let mut counts = vec![0u64; buckets];
    for &v in chunk {
        // Number of edges <= v.
        let idx = edges.partition_point(|e| *e <= v);
        if idx == 0 || idx > buckets {
            continue;
        }
        counts[idx - 1] += 1;
    }
    counts
}

/// Bucket `i` counts values `v` with `edges[i] <= v < edges[i + 1]`.
/// Panics if `edges` has fewer than two entries or does not increase strictly.
pub fn histogram(values: &[u32], edges: &[u32]) -> Vec<u64> {
    if edges.len() < 2 {
        panic!("histogram: edges must have at least two entries");
    }
    if !edges.windows(2).all(|w| w[0] < w[1]) {
        panic!("histogram: edges must increase strictly");
    }
    let chunks: Vec<&[u32]> = values.chunks(CHUNK).collect();
    let partials: Vec<Vec<u64>> = chunks.par_map(|c| count_chunk(c, edges));
    let mut total = vec![0u64; edges.len() - 1];
    for part in &partials {
        for (t, p) in total.iter_mut().zip(part.iter()) {
            *t += *p;
        }
    }
    total
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeSet;

    struct XorShift(u64);

    impl XorShift {
        fn next(&mut self) -> u64 {
            let mut x = self.0;
            x ^= x << 13;
            x ^= x >> 7;
            x ^= x << 17;
            self.0 = x;
            x
        }
        fn next_u32(&mut self) -> u32 {
            let v: u32 = (self.next() >> 32).truncate();
            v
        }
    }

    fn sequential(values: &[u32], edges: &[u32]) -> Vec<u64> {
        let mut out = vec![0u64; edges.len() - 1];
        for &v in values {
            for i in 0..edges.len() - 1 {
                if edges[i] <= v && v < edges[i + 1] {
                    out[i] += 1;
                }
            }
        }
        out
    }

    #[test]
    fn simple() {
        assert_eq!(histogram(&[0, 1, 5, 9, 10, 99], &[0, 5, 10]), vec![2, 2]);
    }

    #[test]
    fn below_first_edge_ignored() {
        assert_eq!(histogram(&[1, 2, 3, 7, 8], &[3, 7, 8]), vec![1, 1]);
    }

    #[test]
    fn million_values() {
        let mut rng = XorShift(0x9E37_79B9_7F4A_7C15);
        let values: Vec<u32> = (0..1_000_000).map(|_| rng.next_u32()).collect();
        let mut set = BTreeSet::new();
        while set.len() < 17 {
            set.insert(rng.next_u32());
        }
        let edges: Vec<u32> = set.into_iter().collect();
        assert_eq!(histogram(&values, &edges), sequential(&values, &edges));
        let small: Vec<u32> = values.iter().map(|v| v % 1000).collect();
        let edges2 = [0, 10, 100, 250, 999];
        assert_eq!(histogram(&small, &edges2), sequential(&small, &edges2));
    }

    #[test]
    fn empty_values() {
        assert_eq!(histogram(&[], &[0, 5, 10]), vec![0, 0]);
    }

    #[test]
    #[should_panic]
    fn equal_edges_panic() {
        let _ = histogram(&[1], &[5, 5]);
    }

    #[test]
    #[should_panic]
    fn single_edge_panics() {
        let _ = histogram(&[1], &[5]);
    }
}
