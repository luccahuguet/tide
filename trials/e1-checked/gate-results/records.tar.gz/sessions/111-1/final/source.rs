use std::collections::HashMap;
use std::hash::Hash;

const NIL: usize = usize::MAX;

struct Node<K, V> {
    key: K,
    val: V,
    prev: usize,
    next: usize,
}

/// A least-recently-used cache backed by a slab of nodes forming a
/// doubly linked list (head = most recent) and a key-to-slot map.
pub struct Lru<K, V> {
    cap: usize,
    map: HashMap<K, usize>,
    nodes: Vec<Node<K, V>>,
    head: usize,
    tail: usize,
}

impl<K: Eq + Hash + Clone, V> Lru<K, V> {
    pub fn new(capacity: usize) -> Self {
        if capacity == 0 {
            panic!("Lru capacity must be greater than 0");
        }
        Lru {
            cap: capacity,
            map: HashMap::new(),
            nodes: Vec::new(),
            head: NIL,
            tail: NIL,
        }
    }

    fn unlink(&mut self, i: usize) {
        let prev = self.nodes[i].prev;
        let next = self.nodes[i].next;
        if prev != NIL {
            self.nodes[prev].next = next;
        } else {
            self.head = next;
        }
        if next != NIL {
            self.nodes[next].prev = prev;
        } else {
            self.tail = prev;
        }
        self.nodes[i].prev = NIL;
        self.nodes[i].next = NIL;
    }

    fn push_front(&mut self, i: usize) {
        self.nodes[i].prev = NIL;
        self.nodes[i].next = self.head;
        if self.head != NIL {
            let h = self.head;
            self.nodes[h].prev = i;
        } else {
            self.tail = i;
        }
        self.head = i;
    }

    fn touch(&mut self, i: usize) {
        if self.head != i {
            self.unlink(i);
            self.push_front(i);
        }
    }

    pub fn get(&mut self, k: &K) -> Option<&V> {
        let i = *self.map.get(k)?;
        self.touch(i);
        Some(&self.nodes[i].val)
    }

    pub fn peek(&self, k: &K) -> Option<&V> {
        let i = *self.map.get(k)?;
        Some(&self.nodes[i].val)
    }

    pub fn put(&mut self, k: K, v: V) -> Option<(K, V)> {
        if let Some(&i) = self.map.get(&k) {
            self.nodes[i].val = v;
            self.touch(i);
            return None;
        }
        if self.map.len() < self.cap {
            let i = self.nodes.len();
            self.nodes.push(Node { key: k.clone(), val: v, prev: NIL, next: NIL });
            self.map.insert(k, i);
            self.push_front(i);
            None
        } else {
            // Reuse the least recently used slot.
            let i = self.tail;
            self.unlink(i);
            let old_key = std::mem::replace(&mut self.nodes[i].key, k.clone());
            let old_val = std::mem::replace(&mut self.nodes[i].val, v);
            self.map.remove(&old_key);
            self.map.insert(k, i);
            self.push_front(i);
            Some((old_key, old_val))
        }
    }

    pub fn len(&self) -> usize {
        self.map.len()
    }

    pub fn is_empty(&self) -> bool {
        self.map.is_empty()
    }

    pub fn keys_recent_first(&self) -> Vec<&K> {
        let mut out = Vec::with_capacity(self.map.len());
        let mut i = self.head;
        while i != NIL {
            out.push(&self.nodes[i].key);
            i = self.nodes[i].next;
        }
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn case1() {
        let mut c = Lru::new(2);
        assert_eq!(c.put("a", 1), None);
        assert_eq!(c.put("b", 2), None);
        assert_eq!(c.get(&"a"), Some(&1));
        assert_eq!(c.put("c", 3), Some(("b", 2)));
        assert_eq!(c.keys_recent_first(), vec![&"c", &"a"]);
    }

    #[test]
    fn case2() {
        let mut c = Lru::new(2);
        c.put("a", 1);
        c.put("b", 2);
        assert_eq!(c.peek(&"a"), Some(&1));
        assert_eq!(c.put("c", 3), Some(("a", 1)));
        assert_eq!(c.keys_recent_first(), vec![&"c", &"b"]);
    }

    #[test]
    fn case3() {
        let mut c = Lru::new(2);
        c.put("a", 1);
        c.put("b", 2);
        assert_eq!(c.put("a", 10), None);
        assert_eq!(c.len(), 2);
        assert_eq!(c.keys_recent_first(), vec![&"a", &"b"]);
        assert_eq!(c.peek(&"a"), Some(&10));
        assert_eq!(c.put("c", 3), Some(("b", 2)));
    }

    #[test]
    #[should_panic]
    fn case4() {
        let _c = Lru::<u32, u32>::new(0);
    }

    #[test]
    fn case5() {
        let mut c: Lru<u32, u32> = Lru::new(100_000);
        for i in 0..300_000u32 {
            let _ = c.put(i, i);
            let _ = c.get(&(i / 2));
        }
        assert_eq!(c.len(), 100_000);
    }

    #[test]
    fn capacity_one() {
        let mut c = Lru::new(1);
        assert_eq!(c.put(1, "x"), None);
        assert_eq!(c.put(2, "y"), Some((1, "x")));
        assert_eq!(c.get(&1), None);
        assert_eq!(c.get(&2), Some(&"y"));
        assert_eq!(c.keys_recent_first(), vec![&2]);
    }
}
