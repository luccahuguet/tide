use std::sync::Shared;
use std::task::{TaskError, Tasks};

/// How many candidate positions a search examines between cancellation checks.
const CHECK_EVERY: usize = 4096;

/// Searches one haystack, checking for cancellation at least every
/// `CHECK_EVERY` bytes. Returns `Ok(Some(pos))` on a match, `Ok(None)` if
/// there is none, and `Err(())` if the search was cancelled.
fn search(tasks: &Tasks, hay: &[u8], needle: &[u8]) -> Result<Option<usize>, ()> {
    let m = needle.len();
    if m > hay.len() {
        return Ok(None);
    }
    let last = hay.len() - m;
    let first = needle[0];
    let mut start = 0;
    while start <= last {
        if tasks.checkpoint().is_err() {
            return Err(());
        }
        let end = if last - start >= CHECK_EVERY { start + CHECK_EVERY } else { last + 1 };
        let mut p = start;
        while p < end {
            if hay[p] == first && &hay[p..p + m] == needle {
                return Ok(Some(p));
            }
            p += 1;
        }
        start = end;
    }
    Ok(None)
}

pub fn find_any(tasks: &Tasks, hays: &[String], needle: &str) -> Option<(usize, usize)> {
    assert!(!needle.is_empty(), "find_any: empty needle");
    let found: Shared<Option<(usize, usize)>> = Shared::new(None, tasks);
    let nb = needle.as_bytes();
    let res: Result<(), TaskError> = tasks.scope(|s| {
        for (i, h) in hays.iter().enumerate() {
            let found = found.clone();
            s.spawn(move || {
                match search(tasks, h.as_bytes(), nb) {
                    Ok(Some(pos)) => {
                        let _ = found.with(|v| {
                            if v.is_none() {
                                *v = Some((i, pos));
                            }
                        });
                        s.cancel();
                    }
                    Ok(None) | Err(()) => {}
                }
                Ok(())
            });
        }
        Ok(())
    });
    let _ = res;
    found.with(|v| *v).unwrap_or(None)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn s(v: &[&str]) -> Vec<String> {
        v.iter().map(|x| x.to_string()).collect()
    }

    #[test]
    fn one_of_three() {
        for seed in 0..20u64 {
            let sim = Root::sim(seed);
            let hays = s(&["hello world", "the quick brown fox", "lorem ipsum"]);
            assert_eq!(find_any(&sim.tasks, &hays, "brown"), Some((1, 10)));
        }
    }

    #[test]
    fn none_found() {
        for seed in 0..20u64 {
            let sim = Root::sim(seed);
            let hays = s(&["abc", "def", "ab"]);
            assert_eq!(find_any(&sim.tasks, &hays, "abcd"), None);
            assert_eq!(find_any(&sim.tasks, &[], "x"), None);
        }
    }

    #[test]
    fn two_contain() {
        for seed in 0..20u64 {
            let sim = Root::sim(seed);
            let hays = s(&["xxneedle", "nothing", "needle here"]);
            let r = find_any(&sim.tasks, &hays, "needle");
            assert!(r == Some((0, 2)) || r == Some((2, 0)), "{r:?}");
        }
    }

    #[test]
    fn across_chunk_boundary() {
        let sim = Root::sim(3);
        let mut h = "a".repeat(4094);
        h.push_str("needle");
        let hays = vec![h];
        assert_eq!(find_any(&sim.tasks, &hays, "needle"), Some((0, 4094)));
    }

    #[test]
    fn big() {
        for seed in 0..3u64 {
            let sim = Root::sim(seed);
            let mut hays: Vec<String> = Vec::new();
            for i in 0..8 {
                let mut h = "a".repeat(1_000_000);
                if i == 3 {
                    h.replace_range(999_000..999_006, "needle");
                }
                hays.push(h);
            }
            assert_eq!(find_any(&sim.tasks, &hays, "needle"), Some((3, 999_000)));
        }
    }

    #[test]
    #[should_panic]
    fn empty_needle() {
        let sim = Root::sim(0);
        let hays = s(&["abc"]);
        let _ = find_any(&sim.tasks, &hays, "");
    }
}
