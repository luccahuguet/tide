//! A small key-value store saved by atomic replace.

use std::collections::BTreeMap;
use std::fs::{self, File};
use std::io::{self, Write};
use std::path::{Path, PathBuf};

const FILE: &str = "store.kv";
const TMP: &str = "store.kv.tmp";

#[derive(Debug)]
pub struct Store {
    dir: PathBuf,
    map: BTreeMap<String, String>,
}

impl Store {
    pub fn open(dir: &Path) -> io::Result<Store> {
        let mut map = BTreeMap::new();
        match fs::read_to_string(dir.join(FILE)) {
            Ok(text) => {
                for line in text.lines() {
                    let (k, v) = line.split_once('\t').ok_or_else(|| {
                        io::Error::new(io::ErrorKind::InvalidData, "line without tab")
                    })?;
                    map.insert(k.to_string(), v.to_string());
                }
            }
            Err(e) if e.kind() == io::ErrorKind::NotFound => {}
            Err(e) => return Err(e),
        }
        Ok(Store {
            dir: dir.to_path_buf(),
            map,
        })
    }

    pub fn get(&self, key: &str) -> Option<&str> {
        self.map.get(key).map(String::as_str)
    }

    pub fn set(&mut self, key: &str, value: &str) -> io::Result<()> {
        if key.contains('\t') || key.contains('\n') {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "key may not contain tab or newline",
            ));
        }
        if value.contains('\n') {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "value may not contain newline",
            ));
        }
        let old = self.map.insert(key.to_string(), value.to_string());
        if let Err(e) = self.save() {
            match old {
                Some(v) => {
                    self.map.insert(key.to_string(), v);
                }
                None => {
                    self.map.remove(key);
                }
            }
            return Err(e);
        }
        Ok(())
    }

    pub fn remove(&mut self, key: &str) -> io::Result<bool> {
        let Some(old) = self.map.remove(key) else {
            return Ok(false);
        };
        if let Err(e) = self.save() {
            self.map.insert(key.to_string(), old);
            return Err(e);
        }
        Ok(true)
    }

    fn save(&self) -> io::Result<()> {
        let mut data = String::new();
        for (k, v) in &self.map {
            data.push_str(k);
            data.push('\t');
            data.push_str(v);
            data.push('\n');
        }
        let tmp = self.dir.join(TMP);
        {
            let mut f = File::create(&tmp)?;
            f.write_all(data.as_bytes())?;
            f.sync_all()?;
        }
        fs::rename(&tmp, self.dir.join(FILE))?;
        File::open(&self.dir)?.sync_all()?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tmpdir(name: &str) -> PathBuf {
        let d = std::env::temp_dir().join(format!("kvstore-test-{}-{}", name, std::process::id()));
        let _ = fs::remove_dir_all(&d);
        fs::create_dir_all(&d).unwrap();
        d
    }

    #[test]
    fn set_reopen() {
        let d = tmpdir("set");
        {
            let mut s = Store::open(&d).unwrap();
            s.set("b", "2").unwrap();
            s.set("a", "1").unwrap();
        }
        let s = Store::open(&d).unwrap();
        assert_eq!(s.get("a"), Some("1"));
        assert_eq!(fs::read_to_string(d.join(FILE)).unwrap(), "a\t1\nb\t2\n");
    }

    #[test]
    fn remove_works() {
        let d = tmpdir("remove");
        let mut s = Store::open(&d).unwrap();
        s.set("a", "1").unwrap();
        assert!(s.remove("a").unwrap());
        assert!(!s.remove("a").unwrap());
        let s = Store::open(&d).unwrap();
        assert_eq!(s.get("a"), None);
    }

    #[test]
    fn invalid_input() {
        let d = tmpdir("invalid");
        let mut s = Store::open(&d).unwrap();
        s.set("a", "1").unwrap();
        let e = s.set("x\ny", "v").unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::InvalidInput);
        assert_eq!(s.set("a", "x\ny").unwrap_err().kind(), io::ErrorKind::InvalidInput);
        assert_eq!(s.set("a\tb", "x").unwrap_err().kind(), io::ErrorKind::InvalidInput);
        assert_eq!(fs::read_to_string(d.join(FILE)).unwrap(), "a\t1\n");
        assert_eq!(s.get("a"), Some("1"));
    }

    #[test]
    fn invalid_data() {
        let d = tmpdir("data");
        fs::write(d.join(FILE), "oops\n").unwrap();
        assert_eq!(Store::open(&d).unwrap_err().kind(), io::ErrorKind::InvalidData);
    }

    #[test]
    fn tmp_ignored() {
        let d = tmpdir("tmp");
        fs::write(d.join(TMP), "garbage no tab").unwrap();
        let mut s = Store::open(&d).unwrap();
        s.set("k", "v").unwrap();
        assert!(!d.join(TMP).exists());
    }
}
