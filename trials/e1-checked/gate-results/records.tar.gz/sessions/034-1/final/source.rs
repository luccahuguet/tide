use std::process::ExitCode;

const USAGE: &str = "usage: colstats [--col N] [--sep C]";

#[derive(Debug, PartialEq)]
struct Options {
    col: usize,
    sep: char,
}

#[derive(Debug, PartialEq)]
enum Failure {
    Usage(String),
    Data(String),
}

/// Authority-free. `args` excludes the program name.
fn parse_args(args: &[String]) -> Result<Options, Failure> {
    let mut opts = Options { col: 1, sep: ',' };
    let mut it = args.iter();
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "--col" => {
                let v = it
                    .next()
                    .ok_or_else(|| Failure::Usage(format!("{USAGE}: --col needs a value")))?;
                let n: usize = v
                    .parse()
                    .map_err(|_| Failure::Usage(format!("{USAGE}: bad column {v:?}")))?;
                if n == 0 {
                    return Err(Failure::Usage(format!("{USAGE}: column must be at least 1")));
                }
                opts.col = n;
            }
            "--sep" => {
                let v = it
                    .next()
                    .ok_or_else(|| Failure::Usage(format!("{USAGE}: --sep needs a value")))?;
                let mut chars = v.chars();
                match (chars.next(), chars.next()) {
                    (Some(c), None) => opts.sep = c,
                    _ => {
                        return Err(Failure::Usage(format!(
                            "{USAGE}: separator must be one character"
                        )))
                    }
                }
            }
            other => {
                return Err(Failure::Usage(format!("{USAGE}: unexpected argument {other:?}")));
            }
        }
    }
    Ok(opts)
}

/// Authority-free.
fn stats(opts: &Options, input: &str) -> Result<String, Failure> {
    let mut count: u64 = 0;
    let mut sum: i64 = 0;
    let mut min = i64::MAX;
    let mut max = i64::MIN;
    for (i, line) in input.lines().enumerate() {
        let lineno = i + 1;
        if line.trim().is_empty() {
            continue;
        }
        let field = match line.split(opts.sep).nth(opts.col - 1) {
            Some(f) => f.trim(),
            None => {
                return Err(Failure::Data(format!(
                    "colstats: line {lineno}: too few fields (want column {})",
                    opts.col
                )))
            }
        };
        let v: i64 = field.parse().map_err(|_| {
            Failure::Data(format!("colstats: line {lineno}: not an integer: {field:?}"))
        })?;
        sum = sum
            .checked_add(v)
            .ok_or_else(|| Failure::Data(String::from("colstats: overflow")))?;
        count += 1;
        if v < min {
            min = v;
        }
        if v > max {
            max = v;
        }
    }
    if count == 0 {
        Ok(String::from("count=0\n"))
    } else {
        Ok(format!("count={count} sum={sum} min={min} max={max}\n"))
    }
}

#[cfg(test)]
fn run(args: &[String], input: &str) -> Result<String, Failure> {
    let opts = parse_args(args)?;
    stats(&opts, input)
}

#[tide::main]
fn main(root: Root) -> ExitCode {
    let args: Vec<String> = root.env.args().skip(1).collect();
    let opts = match parse_args(&args) {
        Ok(o) => o,
        Err(Failure::Usage(m)) | Err(Failure::Data(m)) => {
            eprintln!("{m}");
            return ExitCode::from(2);
        }
    };
    let mut input = String::new();
    if let Err(e) = root.stdin.read_to_string(&mut input) {
        eprintln!("colstats: cannot read standard input: {e}");
        return ExitCode::FAILURE;
    }
    match stats(&opts, &input) {
        Ok(out) => {
            print!("{out}");
            ExitCode::SUCCESS
        }
        Err(Failure::Usage(m)) => {
            eprintln!("{m}");
            ExitCode::from(2)
        }
        Err(Failure::Data(m)) => {
            eprintln!("{m}");
            ExitCode::FAILURE
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn a(xs: &[&str]) -> Vec<String> {
        xs.iter().map(|s| s.to_string()).collect()
    }

    #[test]
    fn column_two() {
        assert_eq!(
            run(&a(&["--col", "2"]), "a,1\nb,-5\n\nc,10\n").unwrap(),
            "count=3 sum=6 min=-5 max=10\n"
        );
    }

    #[test]
    fn sep_and_order() {
        assert_eq!(
            run(&a(&["--sep", ";", "--col", "1"]), "4;x\n2;y\n").unwrap(),
            "count=2 sum=6 min=2 max=4\n"
        );
    }

    #[test]
    fn empty() {
        assert_eq!(run(&a(&[]), "").unwrap(), "count=0\n");
        assert_eq!(run(&a(&[]), "\n  \n").unwrap(), "count=0\n");
    }

    #[test]
    fn bad_line() {
        match run(&a(&[]), "1\nx\n") {
            Err(Failure::Data(m)) => assert!(m.starts_with("colstats: line 2: ")),
            other => panic!("{other:?}"),
        }
        match run(&a(&["--col", "3"]), "1,2\n") {
            Err(Failure::Data(m)) => assert!(m.starts_with("colstats: line 1: ")),
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn overflow() {
        match run(&a(&[]), "9223372036854775807\n1\n") {
            Err(Failure::Data(m)) => assert!(m.starts_with("colstats: overflow")),
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn usage() {
        for case in [&["--col", "0"][..], &["--col"][..], &["--sep", "ab"][..], &["x"][..]] {
            match run(&a(case), "") {
                Err(Failure::Usage(m)) => assert!(m.starts_with("usage: colstats")),
                other => panic!("{other:?}"),
            }
        }
    }
}
