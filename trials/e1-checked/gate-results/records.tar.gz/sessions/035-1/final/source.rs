use std::collections::HashMap;
use std::sync::Shared;
use std::task::{TaskError, Tasks};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ReserveError {
    UnknownItem(String),
    Insufficient(String),
}

pub struct Warehouse {
    items: HashMap<String, Shared<u32>>,
}

impl Warehouse {
    pub fn new(tasks: &Tasks, stock: &[(&str, u32)]) -> Warehouse {
        let mut items: HashMap<String, Shared<u32>> = HashMap::new();
        for (name, qty) in stock {
            if !items.contains_key(*name) {
                items.insert(name.to_string(), Shared::new(*qty, tasks));
            }
        }
        Warehouse { items }
    }

    pub fn stock(&self, item: &str) -> Option<u32> {
        let cell = self.items.get(item)?;
        cell.with(|v| *v).ok()
    }

    pub fn reserve(&self, order: &[(&str, u32)]) -> Result<(), ReserveError> {
        // Aggregate lines by item, in order of first appearance.
        let mut agg: Vec<(&str, u64)> = Vec::new();
        for (name, qty) in order {
            match agg.iter_mut().find(|(n, _)| *n == *name) {
                Some(entry) => entry.1 += u64::from(*qty),
                None => agg.push((*name, u64::from(*qty))),
            }
        }
        // Known items up to the first unknown one.
        let mut cells: Vec<Shared<u32>> = Vec::new();
        let mut names: Vec<&str> = Vec::new();
        let mut amounts: Vec<u64> = Vec::new();
        let mut unknown: Option<&str> = None;
        for (name, qty) in &agg {
            match self.items.get(*name) {
                Some(c) => {
                    cells.push(c.clone());
                    names.push(*name);
                    amounts.push(*qty);
                }
                None => {
                    unknown = Some(*name);
                    break;
                }
            }
        }
        let apply = unknown.is_none();
        let outcome: Option<usize> = Shared::with_all(&cells, move |vals| {
            let mut new_vals: Vec<u32> = Vec::with_capacity(vals.len());
            for (i, v) in vals.iter().enumerate() {
                let have = u64::from(**v);
                if amounts[i] > have {
                    return Some(i);
                }
                match u32::try_from(have - amounts[i]) {
                    Ok(n) => new_vals.push(n),
                    Err(_) => return Some(i),
                }
            }
            if apply {
                for (i, v) in vals.iter_mut().enumerate() {
                    **v = new_vals[i];
                }
            }
            None
        })
        .expect("stock cell lock failed");
        if let Some(i) = outcome {
            return Err(ReserveError::Insufficient(names[i].to_string()));
        }
        if let Some(name) = unknown {
            return Err(ReserveError::UnknownItem(name.to_string()));
        }
        Ok(())
    }
}

pub fn run_orders(
    tasks: &Tasks,
    w: &Warehouse,
    orders: &[Vec<(&str, u32)>],
    workers: usize,
) -> Vec<Result<(), ReserveError>> {
    let limited = tasks.limit(workers.max(1));
    let res: Result<Vec<Result<(), ReserveError>>, TaskError> = limited.scope(|s| {
        let mut handles = Vec::with_capacity(orders.len());
        for order in orders {
            handles.push(s.spawn(move || Ok(w.reserve(order))));
        }
        let mut out = Vec::with_capacity(handles.len());
        for h in handles {
            out.push(h.join()?);
        }
        Ok(out)
    });
    res.expect("order tasks failed")
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    #[sim_test(seeds = 20)]
    fn basic(sim: SimRoot) {
        let w = Warehouse::new(&sim.tasks, &[("a", 5), ("b", 2)]);
        assert_eq!(w.reserve(&[("a", 2), ("b", 2)]), Ok(()));
        assert_eq!(w.stock("a"), Some(3));
        assert_eq!(w.stock("b"), Some(0));
        assert_eq!(
            w.reserve(&[("a", 1), ("b", 1)]),
            Err(ReserveError::Insufficient("b".to_string()))
        );
        assert_eq!(w.stock("a"), Some(3));
        assert_eq!(
            w.reserve(&[("a", 2), ("a", 2)]),
            Err(ReserveError::Insufficient("a".to_string()))
        );
        assert_eq!(w.stock("a"), Some(3));
        assert_eq!(
            w.reserve(&[("z", 1)]),
            Err(ReserveError::UnknownItem("z".to_string()))
        );
        assert_eq!(
            w.reserve(&[("a", 1), ("z", 1)]),
            Err(ReserveError::UnknownItem("z".to_string()))
        );
        assert_eq!(
            w.reserve(&[("a", 9), ("z", 1)]),
            Err(ReserveError::Insufficient("a".to_string()))
        );
        assert_eq!(w.stock("a"), Some(3));
        assert_eq!(w.stock("z"), None);
    }

    #[sim_test(seeds = 20)]
    fn concurrent(sim: SimRoot) {
        let w = Warehouse::new(&sim.tasks, &[("x", 600), ("y", 1000)]);
        let orders: Vec<Vec<(&str, u32)>> = (0..1000).map(|_| vec![("x", 1), ("y", 1)]).collect();
        let res = run_orders(&sim.tasks, &w, &orders, 8);
        assert_eq!(res.len(), 1000);
        let ok = res.iter().filter(|r| r.is_ok()).count();
        assert_eq!(ok, 600);
        assert!(res
            .iter()
            .filter(|r| r.is_err())
            .all(|r| *r == Err(ReserveError::Insufficient("x".to_string()))));
        assert_eq!(w.stock("x"), Some(0));
        assert_eq!(w.stock("y"), Some(400));
    }
}
