//! A bounded stack with stated pre- and postconditions.

#[derive(Debug, Clone)]
pub struct BoundedStack<T> {
    items: Vec<T>,
    capacity: usize,
}

impl<T> BoundedStack<T> {
    /// Requires `capacity >= 1`.
    pub fn new(capacity: usize) -> Self {
        assert!(capacity >= 1, "capacity must be at least 1");
        BoundedStack {
            items: Vec::with_capacity(capacity),
            capacity,
        }
    }

    /// Requires the stack not to be full. Leaves `len` one higher.
    pub fn push(&mut self, x: T) {
        assert!(!self.is_full(), "push onto a full stack");
        let before = self.items.len();
        self.items.push(x);
        debug_assert_eq!(self.items.len(), before + 1);
    }

    /// Leaves `len` one lower if non-empty, unchanged otherwise.
    pub fn pop(&mut self) -> Option<T> {
        self.items.pop()
    }

    pub fn peek(&self) -> Option<&T> {
        self.items.last()
    }

    pub fn len(&self) -> usize {
        self.items.len()
    }

    pub fn capacity(&self) -> usize {
        self.capacity
    }

    pub fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    pub fn is_full(&self) -> bool {
        self.items.len() >= self.capacity
    }

    /// Requires `n <= len`. Returns the top `n` items, top first.
    pub fn drain_top(&mut self, n: usize) -> Vec<T> {
        assert!(n <= self.items.len(), "drain_top: n exceeds len");
        let start = self.items.len() - n;
        let mut out: Vec<T> = self.items.drain(start..).collect();
        out.reverse();
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn push_pop() {
        let mut s = BoundedStack::new(3);
        assert!(s.is_empty());
        s.push(1);
        s.push(2);
        s.push(3);
        assert!(s.is_full());
        assert_eq!(s.len(), 3);
        assert_eq!(s.capacity(), 3);
        assert_eq!(s.pop(), Some(3));
        assert_eq!(s.pop(), Some(2));
        assert_eq!(s.pop(), Some(1));
        assert_eq!(s.pop(), None);
        assert_eq!(s.len(), 0);
    }

    #[test]
    #[should_panic]
    fn push_full() {
        let mut s = BoundedStack::new(1);
        s.push(1);
        s.push(2);
    }

    #[test]
    #[should_panic]
    fn new_zero() {
        let _ = BoundedStack::<i32>::new(0);
    }

    #[test]
    #[should_panic]
    fn drain_too_many() {
        let mut s = BoundedStack::new(5);
        s.push(1);
        s.push(2);
        s.drain_top(3);
    }

    #[test]
    fn drain() {
        let mut s = BoundedStack::new(3);
        s.push('a');
        s.push('b');
        s.push('c');
        assert_eq!(s.drain_top(2), vec!['c', 'b']);
        assert_eq!(s.len(), 1);
        assert_eq!(s.peek(), Some(&'a'));
    }

    #[test]
    fn strings() {
        let mut s = BoundedStack::new(3);
        s.push("a".to_string());
        s.push("b".to_string());
        s.push("c".to_string());
        assert!(s.is_full());
        assert_eq!(s.drain_top(2), vec!["c".to_string(), "b".to_string()]);
        assert_eq!(s.peek(), Some(&"a".to_string()));
        assert_eq!(s.pop(), Some("a".to_string()));
        assert_eq!(s.pop(), None);
    }
}
