//! In-place partition and selection with loop invariants.

/// Reorders `v` so every element less than `pivot` precedes every other
/// element, and returns how many elements are less than `pivot`.
/// Only swaps elements, so the multiset is preserved; allocates nothing.
#[ensures(result <= v.len())]
#[ensures(forall |i: usize| i < result ==> v[i] < pivot)]
#[ensures(forall |i: usize| result <= i && i < v.len() ==> v[i] >= pivot)]
pub fn partition(v: &mut [i32], pivot: i32) -> usize {
    let mut store = 0usize;
    let mut i = 0usize;
    while i < v.len() {
        invariant!(store <= i);
        invariant!(i <= v.len());
        if v[i] < pivot {
            v.swap(store, i);
            store += 1;
        }
        i += 1;
    }
    store
}

/// Returns the `k`-th smallest element (0-based) of `v`, reordering `v`
/// by repeated `partition`. Panics unless `k < v.len()`.
#[requires(k < v.len())]
pub fn select_kth(v: &mut [i32], k: usize) -> i32 {
    assert!(k < v.len(), "select_kth: k ({}) must be below len ({})", k, v.len());
    let mut lo = 0usize;
    let mut hi = v.len();
    loop {
        invariant!(lo <= k && k < hi && hi <= v.len());
        let pivot = v[lo + (hi - lo) / 2];
        // [lo, p) < pivot, [p, hi) >= pivot; pivot itself lies in [p, hi).
        let p = lo + partition(&mut v[lo..hi], pivot);
        if k < p {
            hi = p;
            continue;
        }
        let Some(next) = pivot.checked_add(1) else {
            // pivot is i32::MAX: everything in [p, hi) equals it.
            return pivot;
        };
        // [p, q) == pivot, [q, hi) > pivot; q > p.
        let q = p + partition(&mut v[p..hi], next);
        if k < q {
            return pivot;
        }
        lo = q;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn xorshift(n: usize, seed: u32) -> Vec<u32> {
        let mut x = seed;
        let mut out = Vec::with_capacity(n);
        for _ in 0..n {
            x ^= x.wrapping_shl(13);
            x ^= x.wrapping_shr(17);
            x ^= x.wrapping_shl(5);
            out.push(x);
        }
        out
    }

    fn sorted(v: &[i32]) -> Vec<i32> {
        let mut s = v.to_vec();
        s.sort();
        s
    }

    #[test]
    fn example_case() {
        let mut v = [3, 1, 4, 1, 5, 9, 2, 6];
        let orig = v;
        let n = partition(&mut v, 4);
        assert_eq!(n, 4);
        assert!(v[..4].iter().all(|x| *x < 4));
        assert!(v[4..].iter().all(|x| *x >= 4));
        assert_eq!(sorted(&v), sorted(&orig));
    }

    #[test]
    fn none_below_and_empty() {
        let mut v = [5, 6, 7, 5];
        assert_eq!(partition(&mut v, 5), 0);
        assert_eq!(sorted(&v), vec![5, 5, 6, 7]);
        let mut e: [i32; 0] = [];
        assert_eq!(partition(&mut e, 0), 0);
        let mut all = [1, 2, 3];
        assert_eq!(partition(&mut all, 10), 3);
    }

    #[test]
    fn select_random() {
        let base: Vec<i32> = xorshift(10_000, 2463534242).into_iter().map(|x| x.cast_signed()).collect();
        let s = sorted(&base);
        for k in [0usize, 1, 4999, 9999] {
            let mut v = base.clone();
            assert_eq!(select_kth(&mut v, k), s[k]);
            assert_eq!(sorted(&v), s);
        }
    }

    #[test]
    fn select_duplicates() {
        let base: Vec<i32> = xorshift(10_000, 88172645)
            .into_iter()
            .map(|x| i32::try_from(x % 7).unwrap() - 3)
            .collect();
        let s = sorted(&base);
        for k in [0usize, 1, 4999, 9999] {
            let mut v = base.clone();
            assert_eq!(select_kth(&mut v, k), s[k]);
        }
        let mut same = vec![i32::MAX; 100];
        assert_eq!(select_kth(&mut same, 50), i32::MAX);
        let mut mins = vec![i32::MIN, i32::MAX, i32::MIN];
        assert_eq!(select_kth(&mut mins, 2), i32::MAX);
    }

    #[test]
    #[should_panic]
    fn k_equal_len_panics() {
        let mut v = vec![1, 2, 3];
        let _ = select_kth(&mut v, 3);
    }
}
