use std::collections::HashMap;
use std::env::Env;
use std::fs::Fs;
use std::io::Write;
use std::process::ExitCode;

/// Parses a defaults file. On error returns the message (without newline).
fn parse_defaults(name: &str, text: &str) -> Result<HashMap<String, String>, String> {
    let mut map = HashMap::new();
    for (i, line) in text.lines().enumerate() {
        let lineno = i + 1;
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }
        match line.split_once('=') {
            None => {
                return Err(format!("envreport: {name}:{lineno}: missing '=' in line"));
            }
            Some((k, v)) => {
                let k = k.trim();
                if k.is_empty() {
                    return Err(format!("envreport: {name}:{lineno}: empty key"));
                }
                map.insert(k.to_string(), v.to_string());
            }
        }
    }
    Ok(map)
}

/// Runs the program; returns (stdout, stderr, exit code).
fn run(env: &Env, fs: &Fs) -> (String, String, u8) {
    let args: Vec<String> = env.args().skip(1).collect();
    let usage = "usage: envreport [--defaults FILE] NAME...\n".to_string();
    let mut defaults_file: Option<String> = None;
    let mut names: Vec<String> = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "--defaults" && names.is_empty() && defaults_file.is_none() {
            if i + 1 >= args.len() {
                return (String::new(), usage, 2);
            }
            defaults_file = Some(args[i + 1].clone());
            i += 2;
            continue;
        }
        names.push(a.clone());
        i += 1;
    }
    if names.is_empty() {
        return (String::new(), usage, 2);
    }
    let defaults = match &defaults_file {
        None => HashMap::new(),
        Some(f) => {
            let text = match fs.read_to_string(f) {
                Ok(t) => t,
                Err(e) => return (String::new(), format!("envreport: {f}: {e}\n"), 2),
            };
            match parse_defaults(f, &text) {
                Ok(m) => m,
                Err(msg) => return (String::new(), format!("{msg}\n"), 2),
            }
        }
    };
    let mut out = String::new();
    let mut all = true;
    for n in &names {
        let val = match env.var(n) {
            Ok(v) => Some(v),
            Err(_) => defaults.get(n).cloned(),
        };
        match val {
            Some(v) => out.push_str(&format!("{n}={v}\n")),
            None => {
                all = false;
                out.push_str(&format!("{n} is unset\n"));
            }
        }
    }
    (out, String::new(), if all { 0 } else { 1 })
}

#[tide::main]
fn main(root: Root) -> ExitCode {
    let (out, err, code) = run(&root.env, &root.fs);
    let mut so = std::io::stdout();
    let _ = so.write_all(out.as_bytes());
    let _ = so.flush();
    let mut se = std::io::stderr();
    let _ = se.write_all(err.as_bytes());
    let _ = se.flush();
    ExitCode::from(code)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn case1() {
        let sim = Root::sim(1);
        sim.world.env_var("A", "1");
        sim.world.args(["envreport", "A", "B"]);
        let (o, e, c) = run(&sim.env, &sim.fs);
        assert_eq!(o, "A=1\nB is unset\n");
        assert_eq!(e, "");
        assert_eq!(c, 1);
    }

    #[test]
    fn case2() {
        let sim = Root::sim(2);
        sim.world.env_var("A", "1");
        sim.world.file("d.env", "B=two\n# c\nA=zzz\n\nC=x=y\n");
        sim.world.args(["envreport", "--defaults", "d.env", "A", "B", "C"]);
        let (o, _e, c) = run(&sim.env, &sim.fs);
        assert_eq!(o, "A=1\nB=two\nC=x=y\n");
        assert_eq!(c, 0);
    }

    #[test]
    fn case3() {
        let sim = Root::sim(3);
        sim.world.args(["envreport", "--defaults", "nope.env", "A"]);
        let (o, e, c) = run(&sim.env, &sim.fs);
        assert_eq!(o, "");
        assert!(e.starts_with("envreport: nope.env: "));
        assert_eq!(c, 2);
    }

    #[test]
    fn case4() {
        let sim = Root::sim(4);
        sim.world.file("d.env", "oops\n");
        sim.world.args(["envreport", "--defaults", "d.env", "A"]);
        let (o, e, c) = run(&sim.env, &sim.fs);
        assert_eq!(o, "");
        assert!(e.starts_with("envreport: d.env:1: "));
        assert_eq!(c, 2);
    }

    #[test]
    fn case5() {
        let sim = Root::sim(5);
        sim.world.args(["envreport"]);
        let (o, e, c) = run(&sim.env, &sim.fs);
        assert_eq!(o, "");
        assert!(e.starts_with("usage: envreport"));
        assert_eq!(c, 2);
    }

    #[test]
    fn empty_key() {
        let r = parse_defaults("f", "  =x\n");
        assert!(r.unwrap_err().starts_with("envreport: f:1: "));
    }
}
