use std::collections::HashMap;
use std::sync::Shared;
use std::task::{TaskError, Tasks};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ReserveError {
    UnknownItem(String),
    Insufficient(String),
}

pub struct Warehouse {
    items: HashMap<String, Shared<u32>>,
}

impl Warehouse {
    pub fn new(tasks: &Tasks, stock: &[(&str, u32)]) -> Warehouse {
        let mut items = HashMap::new();
        for (name, qty) in stock {
            items.insert(name.to_string(), Shared::new(*qty, tasks));
        }
        Warehouse { items }
    }

    pub fn stock(&self, item: &str) -> Option<u32> {
        let cell = self.items.get(item)?;
        Some(cell.with(|v| *v).expect("stock cell poisoned"))
    }

    pub fn reserve(&self, order: &[(&str, u32)]) -> Result<(), ReserveError> {
        // Aggregate lines by item, in order of first appearance.
        let mut pos: HashMap<&str, usize> = HashMap::new();
        // (name, total quantity, index into `cells` if known)
        let mut lines: Vec<(&str, u64, Option<usize>)> = Vec::new();
        let mut cells: Vec<Shared<u32>> = Vec::new();
        for (name, qty) in order {
            match pos.get(name) {
                Some(&i) => {
                    lines[i].1 += u64::from(*qty);
                }
                None => {
                    let idx = match self.items.get(*name) {
                        Some(cell) => {
                            cells.push(cell.clone());
                            Some(cells.len() - 1)
                        }
                        None => None,
                    };
                    pos.insert(name, lines.len());
                    lines.push((name, u64::from(*qty), idx));
                }
            }
        }
        let lines_ref = &lines;
        let outcome = Shared::with_all(&cells, move |vals: &mut [&mut u32]| {
            // Check every line before writing anything.
            for (i, (_, total, idx)) in lines_ref.iter().enumerate() {
                match idx {
                    None => return Err((i, false)),
                    Some(k) => {
                        if u64::from(*vals[*k]) < *total {
                            return Err((i, true));
                        }
                    }
                }
            }
            for (_, total, idx) in lines_ref.iter() {
                if let Some(k) = idx {
                    let cur = u64::from(*vals[*k]);
                    *vals[*k] = u32::try_from(cur - *total).unwrap_or(0);
                }
            }
            Ok(())
        })
        .expect("stock cells poisoned");
        match outcome {
            Ok(()) => Ok(()),
            Err((i, insufficient)) => {
                let name = lines[i].0.to_string();
                if insufficient {
                    Err(ReserveError::Insufficient(name))
                } else {
                    Err(ReserveError::UnknownItem(name))
                }
            }
        }
    }
}

pub fn run_orders(
    tasks: &Tasks,
    w: &Warehouse,
    orders: &[Vec<(&str, u32)>],
    workers: usize,
) -> Vec<Result<(), ReserveError>> {
    let limited = tasks.limit(workers.max(1));
    let res: Result<Vec<Result<(), ReserveError>>, TaskError> = limited.scope(|s| {
        let mut handles = Vec::new();
        for order in orders {
            handles.push(s.spawn(move || Ok(w.reserve(order))));
        }
        let mut out = Vec::new();
        for h in handles {
            out.push(h.join()?);
        }
        Ok(out)
    });
    res.expect("order tasks failed")
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    #[sim_test(seeds = 20)]
    fn basic(sim: SimRoot) {
        let w = Warehouse::new(&sim.tasks, &[("a", 5), ("b", 2)]);
        assert_eq!(w.reserve(&[("a", 2), ("b", 2)]), Ok(()));
        assert_eq!(w.stock("a"), Some(3));
        assert_eq!(w.stock("b"), Some(0));
        assert_eq!(
            w.reserve(&[("a", 1), ("b", 1)]),
            Err(ReserveError::Insufficient("b".to_string()))
        );
        assert_eq!(w.stock("a"), Some(3));
        assert_eq!(
            w.reserve(&[("a", 2), ("a", 2)]),
            Err(ReserveError::Insufficient("a".to_string()))
        );
        assert_eq!(w.stock("a"), Some(3));
        assert_eq!(
            w.reserve(&[("z", 1)]),
            Err(ReserveError::UnknownItem("z".to_string()))
        );
        assert_eq!(w.stock("z"), None);
        assert_eq!(
            w.reserve(&[("a", 9), ("z", 1)]),
            Err(ReserveError::Insufficient("a".to_string()))
        );
        assert_eq!(
            w.reserve(&[("z", 1), ("a", 9)]),
            Err(ReserveError::UnknownItem("z".to_string()))
        );
    }

    #[sim_test(seeds = 20)]
    fn concurrent(sim: SimRoot) {
        let w = Warehouse::new(&sim.tasks, &[("x", 600), ("y", 1000)]);
        let orders: Vec<Vec<(&str, u32)>> = (0..1000).map(|_| vec![("x", 1), ("y", 1)]).collect();
        let res = run_orders(&sim.tasks, &w, &orders, 8);
        assert_eq!(res.len(), 1000);
        let ok = res.iter().filter(|r| r.is_ok()).count();
        assert_eq!(ok, 600);
        for r in &res {
            if let Err(e) = r {
                assert_eq!(*e, ReserveError::Insufficient("x".to_string()));
            }
        }
        assert_eq!(w.stock("x"), Some(0));
        assert_eq!(w.stock("y"), Some(400));
    }
}
