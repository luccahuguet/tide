use std::sync::mpsc;
use std::thread;
use std::time::{Duration, Instant};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Outcome {
    Done,
    TimedOut,
}

/// Starts every job concurrently on its own thread; job `i` sleeps for
/// `jobs[i]`. Returns as soon as all jobs finish or `limit` passes.
pub fn run_batch(jobs: &[Duration], limit: Duration) -> Vec<Outcome> {
    let mut out = vec![Outcome::TimedOut; jobs.len()];
    if jobs.is_empty() {
        return out;
    }
    let start = Instant::now();
    let deadline = start.checked_add(limit);
    let (tx, rx) = mpsc::channel::<usize>();
    for (i, &d) in jobs.iter().enumerate() {
        let tx = tx.clone();
        thread::spawn(move || {
            thread::sleep(d);
            let _ = tx.send(i);
        });
    }
    drop(tx);
    let mut remaining = jobs.len();
    while remaining > 0 {
        let msg = match deadline {
            None => rx.recv().ok(),
            Some(dl) => {
                let now = Instant::now();
                if now >= dl {
                    break;
                }
                match rx.recv_timeout(dl - now) {
                    Ok(i) => Some(i),
                    Err(mpsc::RecvTimeoutError::Timeout) => break,
                    Err(mpsc::RecvTimeoutError::Disconnected) => None,
                }
            }
        };
        match msg {
            Some(i) => {
                // Only count it if it really finished before the limit.
                if out[i] == Outcome::TimedOut {
                    out[i] = Outcome::Done;
                    remaining -= 1;
                }
            }
            None => break,
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use Outcome::*;

    fn ms(n: u64) -> Duration {
        Duration::from_millis(n)
    }

    #[test]
    fn mixed() {
        let t = Instant::now();
        let r = run_batch(&[ms(10), ms(500), ms(30)], ms(100));
        let e = t.elapsed();
        assert_eq!(r, vec![Done, TimedOut, Done]);
        assert!(e >= ms(100) && e < ms(300), "{e:?}");
    }

    #[test]
    fn all_done() {
        let t = Instant::now();
        let r = run_batch(&[ms(5), ms(6)], ms(1000));
        let e = t.elapsed();
        assert_eq!(r, vec![Done, Done]);
        assert!(e >= ms(6) && e < ms(500), "{e:?}");
    }

    #[test]
    fn empty() {
        let t = Instant::now();
        assert_eq!(run_batch(&[], ms(100)), vec![]);
        assert!(t.elapsed() < ms(100));
    }
}
