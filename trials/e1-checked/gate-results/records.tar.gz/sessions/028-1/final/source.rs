use std::fmt;
use std::ops::{Add, Mul, Neg, Sub};

#[derive(Debug, Clone, PartialEq)]
pub struct Poly {
    coeffs: Vec<i64>,
}

impl Poly {
    pub fn new(mut coeffs: Vec<i64>) -> Poly {
        while coeffs.last() == Some(&0) {
            coeffs.pop();
        }
        Poly { coeffs }
    }

    pub fn coeffs(&self) -> &[i64] {
        &self.coeffs
    }

    pub fn degree(&self) -> Option<usize> {
        if self.coeffs.is_empty() {
            None
        } else {
            Some(self.coeffs.len() - 1)
        }
    }

    pub fn eval(&self, x: i64) -> Option<i64> {
        let mut acc: i64 = 0;
        for &c in self.coeffs.iter().rev() {
            acc = acc.checked_mul(x)?.checked_add(c)?;
        }
        Some(acc)
    }
}

impl Add for &Poly {
    type Output = Poly;
    fn add(self, rhs: &Poly) -> Poly {
        let n = self.coeffs.len().max(rhs.coeffs.len());
        let v = (0..n)
            .map(|i| {
                self.coeffs.get(i).copied().unwrap_or(0) + rhs.coeffs.get(i).copied().unwrap_or(0)
            })
            .collect();
        Poly::new(v)
    }
}

impl Sub for &Poly {
    type Output = Poly;
    fn sub(self, rhs: &Poly) -> Poly {
        let n = self.coeffs.len().max(rhs.coeffs.len());
        let v = (0..n)
            .map(|i| {
                self.coeffs.get(i).copied().unwrap_or(0) - rhs.coeffs.get(i).copied().unwrap_or(0)
            })
            .collect();
        Poly::new(v)
    }
}

impl Mul for &Poly {
    type Output = Poly;
    fn mul(self, rhs: &Poly) -> Poly {
        if self.coeffs.is_empty() || rhs.coeffs.is_empty() {
            return Poly::new(Vec::new());
        }
        let mut v = vec![0i64; self.coeffs.len() + rhs.coeffs.len() - 1];
        for (i, &a) in self.coeffs.iter().enumerate() {
            for (j, &b) in rhs.coeffs.iter().enumerate() {
                v[i + j] += a * b;
            }
        }
        Poly::new(v)
    }
}

impl Add for Poly {
    type Output = Poly;
    fn add(self, rhs: Poly) -> Poly {
        &self + &rhs
    }
}

impl Sub for Poly {
    type Output = Poly;
    fn sub(self, rhs: Poly) -> Poly {
        &self - &rhs
    }
}

impl Mul for Poly {
    type Output = Poly;
    fn mul(self, rhs: Poly) -> Poly {
        &self * &rhs
    }
}

impl Neg for Poly {
    type Output = Poly;
    fn neg(self) -> Poly {
        Poly::new(self.coeffs.into_iter().map(|c| -c).collect())
    }
}

impl Neg for &Poly {
    type Output = Poly;
    fn neg(self) -> Poly {
        -(self.clone())
    }
}

impl fmt::Display for Poly {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if self.coeffs.is_empty() {
            return write!(f, "0");
        }
        let mut first = true;
        for (deg, &c) in self.coeffs.iter().enumerate().rev() {
            if c == 0 {
                continue;
            }
            let neg = c < 0;
            let mag = c.unsigned_abs();
            if first {
                if neg {
                    write!(f, "-")?;
                }
            } else if neg {
                write!(f, " - ")?;
            } else {
                write!(f, " + ")?;
            }
            first = false;
            if deg == 0 {
                write!(f, "{mag}")?;
            } else {
                if mag != 1 {
                    write!(f, "{mag}")?;
                }
                if deg == 1 {
                    write!(f, "x")?;
                } else {
                    write!(f, "x^{deg}")?;
                }
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn display() {
        assert_eq!(Poly::new(vec![5, -1, 3]).to_string(), "3x^2 - x + 5");
        assert_eq!(Poly::new(vec![-2, 0, 0, -1]).to_string(), "-x^3 - 2");
        assert_eq!(Poly::new(vec![1]).to_string(), "1");
        assert_eq!(Poly::new(vec![-1, 1]).to_string(), "x - 1");
        let z = Poly::new(vec![0, 0]);
        assert_eq!(z.to_string(), "0");
        assert_eq!(z.degree(), None);
        assert!(z.coeffs().is_empty());
    }

    #[test]
    fn arith() {
        let x = Poly::new(vec![0, 1]);
        let one = Poly::new(vec![1]);
        let p = (x.clone() + one.clone()) * (x.clone() - one.clone());
        assert_eq!(p.coeffs(), &[-1, 0, 1]);
        let s = &x + &one;
        assert_eq!(s.coeffs(), &[1, 1]);
        assert_eq!(x.degree(), Some(1));
        let a = Poly::new(vec![3, 4]);
        assert_eq!(a.clone() - a, Poly::new(vec![]));
        assert_eq!((-Poly::new(vec![0, 1])).to_string(), "-x");
        assert_eq!((&x * &one).coeffs(), &[0, 1]);
    }

    #[test]
    fn eval() {
        assert_eq!(Poly::new(vec![-1, 0, 1]).eval(3), Some(8));
        assert_eq!(Poly::new(vec![0, 0, 0, 1]).eval(3_000_000), None);
        assert_eq!(Poly::new(vec![]).eval(5), Some(0));
    }
}
