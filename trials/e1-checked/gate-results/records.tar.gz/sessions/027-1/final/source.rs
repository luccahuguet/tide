use std::sync::Mutex;
use std::sync::atomic::{AtomicBool, Ordering};

const CHUNK: usize = 4096;

/// Searches one haystack in chunks, checking `stop` before each chunk.
/// Returns the byte offset of the first occurrence, or None (also when stopped).
fn search(hay: &[u8], needle: &[u8], stop: &AtomicBool) -> Option<usize> {
    if needle.len() > hay.len() {
        return None;
    }
    let last_start = hay.len() - needle.len(); // inclusive
    let first = needle[0];
    let mut start = 0usize;
    while start <= last_start {
        if stop.load(Ordering::Relaxed) {
            return None;
        }
        let end = (start + CHUNK).min(last_start + 1); // exclusive bound on match starts
        for pos in start..end {
            if hay[pos] == first && &hay[pos..pos + needle.len()] == needle {
                return Some(pos);
            }
        }
        start = end;
    }
    None
}

pub fn find_any(hays: &[String], needle: &str) -> Option<(usize, usize)> {
    assert!(!needle.is_empty(), "needle must not be empty");
    let found = AtomicBool::new(false);
    let result: Mutex<Option<(usize, usize)>> = Mutex::new(None);
    let nb = needle.as_bytes();
    std::thread::scope(|s| {
        for (i, hay) in hays.iter().enumerate() {
            let found = &found;
            let result = &result;
            s.spawn(move || {
                if let Some(pos) = search(hay.as_bytes(), nb, found) {
                    if found
                        .compare_exchange(false, true, Ordering::SeqCst, Ordering::SeqCst)
                        .is_ok()
                    {
                        *result.lock().unwrap() = Some((i, pos));
                    }
                }
            });
        }
    });
    result.into_inner().unwrap()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn v(x: &[&str]) -> Vec<String> {
        x.iter().map(|s| s.to_string()).collect()
    }

    #[test]
    fn one_of_three() {
        assert_eq!(find_any(&v(&["abc", "xxneedle", "zzz"]), "needle"), Some((1, 2)));
    }

    #[test]
    fn none_cases() {
        assert_eq!(find_any(&v(&["abc", "def"]), "q"), None);
        assert_eq!(find_any(&[], "q"), None);
        assert_eq!(find_any(&v(&["ab"]), "abc"), None);
    }

    #[test]
    fn two_contain() {
        let r = find_any(&v(&["needle", "x", "aaneedle"]), "needle");
        assert!(r == Some((0, 0)) || r == Some((2, 2)));
    }

    #[test]
    fn big() {
        let mut hays: Vec<String> = (0..8).map(|_| "a".repeat(1_000_000)).collect();
        hays[3].replace_range(999_000..999_006, "needle");
        assert_eq!(find_any(&hays, "needle"), Some((3, 999000)));
    }

    #[test]
    fn across_chunk_boundary() {
        let mut h = "a".repeat(10000);
        h.replace_range(4094..4100, "needle");
        assert_eq!(find_any(&[h], "needle"), Some((0, 4094)));
        let mut h = "a".repeat(8192);
        h.replace_range(8186..8192, "needle");
        assert_eq!(find_any(&[h], "needle"), Some((0, 8186)));
    }

    #[test]
    fn first_occurrence() {
        assert_eq!(find_any(&v(&["xabab ab"]), "ab"), Some((0, 1)));
    }

    #[test]
    #[should_panic]
    fn empty_needle() {
        find_any(&v(&["abc"]), "");
    }
}
