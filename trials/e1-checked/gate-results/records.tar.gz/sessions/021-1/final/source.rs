use std::fs::Fs;
use std::process::ExitCode;

const USAGE: &str = "usage: findtext [-i] PATTERN FILE...";

#[derive(Debug, PartialEq)]
struct Options {
    ignore_case: bool,
    pattern: String,
    files: Vec<String>,
}

/// Authority-free. `args` excludes the program name.
fn parse_args(args: &[String]) -> Option<Options> {
    let mut ignore_case = false;
    let mut i = 0;
    while i < args.len() {
        let a = args[i].as_str();
        if a == "--" {
            i += 1;
            break;
        }
        if a.len() > 1 && a.starts_with('-') {
            if a == "-i" {
                ignore_case = true;
                i += 1;
                continue;
            }
            return None;
        }
        break;
    }
    if i >= args.len() {
        return None;
    }
    let pattern = args[i].clone();
    let files: Vec<String> = args[i + 1..].to_vec();
    if files.is_empty() {
        return None;
    }
    Some(Options { ignore_case, pattern, files })
}

/// Authority-free: appends matching lines of `text` to `out`; returns whether any matched.
fn search(name: &str, text: &str, pattern: &str, ignore_case: bool, out: &mut String) -> bool {
    let pat = if ignore_case { pattern.to_ascii_lowercase() } else { pattern.to_string() };
    let mut any = false;
    for (idx, line) in text.lines().enumerate() {
        let hit = if ignore_case {
            line.to_ascii_lowercase().contains(pat.as_str())
        } else {
            line.contains(pat.as_str())
        };
        if hit {
            any = true;
            out.push_str(&format!("{}:{}:{}\n", name, idx + 1, line));
        }
    }
    any
}

/// Returns the exit code; writes stdout text to `out` and stderr text to `err`.
fn run(fs: &Fs, args: &[String], out: &mut String, err: &mut String) -> u8 {
    let opts = match parse_args(args) {
        Some(o) => o,
        None => {
            err.push_str(USAGE);
            err.push('\n');
            return 2;
        }
    };
    let mut matched = false;
    let mut errored = false;
    for f in &opts.files {
        let bytes = match fs.read(f.as_str()) {
            Ok(b) => b,
            Err(e) => {
                err.push_str(&format!("findtext: {}: {}\n", f, e));
                errored = true;
                continue;
            }
        };
        let text = match String::from_utf8(bytes) {
            Ok(t) => t,
            Err(_) => {
                err.push_str(&format!("findtext: {}: not valid UTF-8\n", f));
                errored = true;
                continue;
            }
        };
        if search(f, &text, &opts.pattern, opts.ignore_case, out) {
            matched = true;
        }
    }
    if errored {
        2
    } else if matched {
        0
    } else {
        1
    }
}

#[tide::main]
fn main(root: Root) -> ExitCode {
    let args: Vec<String> = root.env.args().skip(1).collect();
    let fs = root.fs.read_only();
    let mut out = String::new();
    let mut err = String::new();
    let code = run(&fs, &args, &mut out, &mut err);
    print!("{out}");
    eprint!("{err}");
    ExitCode::from(code)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn go(argv: &[&str]) -> (String, String, u8) {
        let sim = Root::sim(1);
        sim.world.file("a.txt", "one\nTwo\nthree two\n");
        sim.world.file("b.txt", "nothing\r\ntwo\r\n");
        sim.world.file("bad.txt", [0xffu8, 0xfe, b'\n']);
        let args: Vec<String> = argv.iter().map(|s| s.to_string()).collect();
        let mut out = String::new();
        let mut err = String::new();
        let code = run(&sim.fs, &args, &mut out, &mut err);
        (out, err, code)
    }

    #[test]
    fn case1() {
        let (o, e, c) = go(&["two", "a.txt", "b.txt"]);
        assert_eq!(o, "a.txt:3:three two\nb.txt:2:two\n");
        assert_eq!(e, "");
        assert_eq!(c, 0);
    }

    #[test]
    fn case2() {
        let (o, _, c) = go(&["-i", "two", "a.txt"]);
        assert_eq!(o, "a.txt:2:Two\na.txt:3:three two\n");
        assert_eq!(c, 0);
    }

    #[test]
    fn case3() {
        let (o, _, c) = go(&["zzz", "a.txt"]);
        assert_eq!(o, "");
        assert_eq!(c, 1);
        let (o, _, c) = go(&["", "a.txt"]);
        assert_eq!(o, "a.txt:1:one\na.txt:2:Two\na.txt:3:three two\n");
        assert_eq!(c, 0);
    }

    #[test]
    fn case4() {
        let (o, e, c) = go(&["two", "missing.txt", "a.txt"]);
        assert_eq!(o, "a.txt:3:three two\n");
        assert!(e.starts_with("findtext: missing.txt: "));
        assert_eq!(c, 2);
        let (o, e, c) = go(&["two", "bad.txt", "a.txt"]);
        assert_eq!(o, "a.txt:3:three two\n");
        assert!(e.starts_with("findtext: bad.txt: "));
        assert_eq!(c, 2);
    }

    #[test]
    fn case5() {
        for argv in [&["two"][..], &["-x", "two", "a.txt"][..], &[][..]] {
            let (o, e, c) = go(argv);
            assert_eq!(o, "");
            assert!(e.starts_with("usage: findtext"));
            assert_eq!(c, 2);
        }
    }
}
