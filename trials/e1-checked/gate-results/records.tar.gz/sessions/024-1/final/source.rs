use std::fmt;
use std::ops::{Add, Mul, Neg, Sub};

#[derive(Debug, Clone, PartialEq)]
pub struct Poly {
    coeffs: Vec<i64>,
}

impl Poly {
    pub fn new(coeffs: Vec<i64>) -> Poly {
        let mut coeffs = coeffs;
        while coeffs.last() == Some(&0) {
            coeffs.pop();
        }
        Poly { coeffs }
    }

    pub fn coeffs(&self) -> &[i64] {
        &self.coeffs
    }

    pub fn degree(&self) -> Option<usize> {
        if self.coeffs.is_empty() {
            None
        } else {
            Some(self.coeffs.len() - 1)
        }
    }

    pub fn eval(&self, x: i64) -> Option<i64> {
        let mut acc: i64 = 0;
        for c in self.coeffs.iter().rev() {
            acc = acc.checked_mul(x)?.checked_add(*c)?;
        }
        Some(acc)
    }
}

fn add_slices(a: &[i64], b: &[i64]) -> Poly {
    let n = a.len().max(b.len());
    let mut out = Vec::with_capacity(n);
    for i in 0..n {
        let x = a.get(i).copied().unwrap_or(0);
        let y = b.get(i).copied().unwrap_or(0);
        out.push(x + y);
    }
    Poly::new(out)
}

fn sub_slices(a: &[i64], b: &[i64]) -> Poly {
    let n = a.len().max(b.len());
    let mut out = Vec::with_capacity(n);
    for i in 0..n {
        let x = a.get(i).copied().unwrap_or(0);
        let y = b.get(i).copied().unwrap_or(0);
        out.push(x - y);
    }
    Poly::new(out)
}

fn mul_slices(a: &[i64], b: &[i64]) -> Poly {
    if a.is_empty() || b.is_empty() {
        return Poly::new(Vec::new());
    }
    let mut out = vec![0i64; a.len() + b.len() - 1];
    for (i, x) in a.iter().enumerate() {
        for (j, y) in b.iter().enumerate() {
            out[i + j] += *x * *y;
        }
    }
    Poly::new(out)
}

impl Add for Poly {
    type Output = Poly;
    fn add(self, rhs: Poly) -> Poly {
        add_slices(&self.coeffs, &rhs.coeffs)
    }
}

impl Add for &Poly {
    type Output = Poly;
    fn add(self, rhs: &Poly) -> Poly {
        add_slices(&self.coeffs, &rhs.coeffs)
    }
}

impl Sub for Poly {
    type Output = Poly;
    fn sub(self, rhs: Poly) -> Poly {
        sub_slices(&self.coeffs, &rhs.coeffs)
    }
}

impl Sub for &Poly {
    type Output = Poly;
    fn sub(self, rhs: &Poly) -> Poly {
        sub_slices(&self.coeffs, &rhs.coeffs)
    }
}

impl Mul for Poly {
    type Output = Poly;
    fn mul(self, rhs: Poly) -> Poly {
        mul_slices(&self.coeffs, &rhs.coeffs)
    }
}

impl Mul for &Poly {
    type Output = Poly;
    fn mul(self, rhs: &Poly) -> Poly {
        mul_slices(&self.coeffs, &rhs.coeffs)
    }
}

impl Neg for Poly {
    type Output = Poly;
    fn neg(self) -> Poly {
        Poly::new(self.coeffs.iter().map(|c| -*c).collect())
    }
}

impl Neg for &Poly {
    type Output = Poly;
    fn neg(self) -> Poly {
        Poly::new(self.coeffs.iter().map(|c| -*c).collect())
    }
}

impl fmt::Display for Poly {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if self.coeffs.is_empty() {
            return write!(f, "0");
        }
        let mut first = true;
        for (deg, c) in self.coeffs.iter().enumerate().rev() {
            let c = *c;
            if c == 0 {
                continue;
            }
            let neg = c < 0;
            let mag: u64 = c.unsigned_abs();
            if first {
                if neg {
                    write!(f, "-")?;
                }
            } else if neg {
                write!(f, " - ")?;
            } else {
                write!(f, " + ")?;
            }
            first = false;
            if deg == 0 {
                write!(f, "{}", mag)?;
            } else {
                if mag != 1 {
                    write!(f, "{}", mag)?;
                }
                if deg == 1 {
                    write!(f, "x")?;
                } else {
                    write!(f, "x^{}", deg)?;
                }
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn display_cases() {
        assert_eq!(Poly::new(vec![5, -1, 3]).to_string(), "3x^2 - x + 5");
        assert_eq!(Poly::new(vec![-2, 0, 0, -1]).to_string(), "-x^3 - 2");
        assert_eq!(Poly::new(vec![1]).to_string(), "1");
        assert_eq!(Poly::new(vec![-1]).to_string(), "-1");
        assert_eq!(Poly::new(vec![0, 2]).to_string(), "2x");
    }

    #[test]
    fn zero() {
        let z = Poly::new(vec![0, 0]);
        assert_eq!(z.to_string(), "0");
        assert_eq!(z.degree(), None);
        assert!(z.coeffs().is_empty());
        assert_eq!(z.eval(5), Some(0));
    }

    #[test]
    fn arithmetic() {
        let x1 = Poly::new(vec![1, 1]);
        let xm1 = Poly::new(vec![-1, 1]);
        let p = x1 * xm1;
        assert_eq!(p.coeffs(), &[-1, 0, 1]);
        assert_eq!(p.degree(), Some(2));
        let a = Poly::new(vec![1, 2]);
        let b = Poly::new(vec![3, 0, 4]);
        let s = &a + &b;
        assert_eq!(s.coeffs(), &[4, 2, 4]);
        assert_eq!((&a * &b).coeffs(), &[3, 6, 4, 8]);
        assert_eq!((&b - &a).coeffs(), &[2, -2, 4]);
        assert_eq!(a.coeffs(), &[1, 2]);
        assert_eq!(b.coeffs(), &[3, 0, 4]);
    }

    #[test]
    fn negation() {
        let a = Poly::new(vec![3, 4]);
        let z = a.clone() - a;
        assert_eq!(z, Poly::new(vec![]));
        assert_eq!((-Poly::new(vec![0, 1])).to_string(), "-x");
    }

    #[test]
    fn evaluation() {
        assert_eq!(Poly::new(vec![-1, 0, 1]).eval(3), Some(8));
        assert_eq!(Poly::new(vec![0, 0, 0, 1]).eval(3_000_000), None);
    }
}
