use serde::Deserialize;
use std::collections::BTreeMap;
use std::io::{Read, Write};

#[derive(Deserialize)]
#[serde(rename_all = "lowercase")]
enum Op {
    Read,
    Write,
}

#[derive(Deserialize)]
struct Record {
    user: String,
    bytes: u64,
    op: Op,
}

/// Returns (stdout, stderr, exit code).
fn run(input: &str) -> (String, String, i32) {
    let mut totals: BTreeMap<String, (u64, u64)> = BTreeMap::new();
    let mut err = String::new();
    let mut code = 0;
    for (i, line) in input.lines().enumerate() {
        if line.trim().is_empty() {
            continue;
        }
        match serde_json::from_str::<Record>(line) {
            Ok(rec) => {
                let entry = totals.entry(rec.user).or_insert((0, 0));
                let slot = match rec.op {
                    Op::Read => &mut entry.0,
                    Op::Write => &mut entry.1,
                };
                match slot.checked_add(rec.bytes) {
                    Some(v) => *slot = v,
                    None => {
                        err.push_str("usage: overflow\n");
                        return (String::new(), err, 1);
                    }
                }
            }
            Err(e) => {
                err.push_str(&format!("usage: line {}: {}\n", i + 1, e));
                code = 1;
            }
        }
    }
    let mut out = String::new();
    for (user, (r, w)) in &totals {
        out.push_str(&format!("{user} read={r} write={w}\n"));
    }
    (out, err, code)
}

fn main() {
    let mut buf = Vec::new();
    let _ = std::io::stdin().read_to_end(&mut buf);
    let input = String::from_utf8_lossy(&buf);
    let (out, err, code) = run(&input);
    let _ = std::io::stderr().write_all(err.as_bytes());
    let mut so = std::io::stdout();
    let _ = so.write_all(out.as_bytes());
    let _ = so.flush();
    std::process::exit(code);
}

#[cfg(test)]
mod tests {
    use super::run;

    const A: &str = r#"{"user":"bo","bytes":5,"op":"read"}"#;
    const B: &str = r#"{"user":"al","bytes":7,"op":"write","extra":1}"#;
    const C: &str = r#"{"user":"bo","bytes":3,"op":"write"}"#;

    #[test]
    fn basic() {
        let (o, e, c) = run(&format!("{A}\n{B}\n{C}\n"));
        assert_eq!(o, "al read=0 write=7\nbo read=5 write=3\n");
        assert_eq!(e, "");
        assert_eq!(c, 0);
    }

    #[test]
    fn bad_line() {
        let (o, e, c) = run(&format!("{A}\n{{bad\n{B}\n{C}\n"));
        assert_eq!(o, "al read=0 write=7\nbo read=5 write=3\n");
        assert!(e.starts_with("usage: line 2: "));
        assert_eq!(c, 1);
    }

    #[test]
    fn bad_values() {
        let (_, e, c) = run(r#"{"user":"a","bytes":1,"op":"delete"}"#);
        assert!(e.starts_with("usage: line 1: "));
        assert_eq!(c, 1);
        let (_, e, c) = run(r#"{"user":"a","bytes":-1,"op":"read"}"#);
        assert!(e.starts_with("usage: line 1: "));
        assert_eq!(c, 1);
    }

    #[test]
    fn empty_and_blank() {
        assert_eq!(run(""), (String::new(), String::new(), 0));
        assert_eq!(run("\n  \n"), (String::new(), String::new(), 0));
    }

    #[test]
    fn overflow() {
        let l = r#"{"user":"a","bytes":18446744073709551615,"op":"read"}"#;
        let (o, e, c) = run(&format!("{l}\n{l}\n"));
        assert_eq!(o, "");
        assert!(e.starts_with("usage: overflow"));
        assert_eq!(c, 1);
    }
}
