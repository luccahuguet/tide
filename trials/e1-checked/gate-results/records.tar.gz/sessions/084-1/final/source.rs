use std::fs::Fs;
use std::io;

#[derive(Debug, PartialEq)]
pub struct Summary {
    pub files: u64,
    pub dirs: u64,
    pub bytes: u64,
    pub largest: Option<(String, u64)>,
}

fn walk(
    fs: &Fs,
    abs: &str,
    rel: &str,
    files: &mut Vec<(String, u64)>,
    dirs: &mut u64,
) -> io::Result<()> {
    let mut names: Vec<String> = Vec::new();
    for entry in fs.read_dir(abs)? {
        let entry = entry?;
        names.push(entry.file_name().to_string_lossy().into_owned());
    }
    names.sort();
    for name in names {
        let child_abs = format!("{}/{}", abs, name);
        let child_rel = if rel.is_empty() {
            name.clone()
        } else {
            format!("{}/{}", rel, name)
        };
        let md = fs.metadata(&child_abs)?;
        if md.is_dir() {
            *dirs += 1;
            walk(fs, &child_abs, &child_rel, files, dirs)?;
        } else if md.is_file() {
            files.push((child_rel, md.len()));
        }
    }
    Ok(())
}

fn collect(fs: &Fs, dir: &str) -> io::Result<(Vec<(String, u64)>, u64)> {
    let md = fs.metadata(dir)?;
    if !md.is_dir() {
        return Err(io::Error::new(io::ErrorKind::NotFound, "not a directory"));
    }
    let base = dir.trim_end_matches('/');
    let base = if base.is_empty() && dir.starts_with('/') { "/" } else { base };
    let base = if base.is_empty() { "." } else { base };
    let mut files = Vec::new();
    let mut dirs = 0u64;
    walk(fs, base, "", &mut files, &mut dirs)?;
    files.sort_by(|a, b| b.1.cmp(&a.1).then_with(|| a.0.cmp(&b.0)));
    Ok((files, dirs))
}

pub fn summarize(fs: &Fs, dir: &str) -> io::Result<Summary> {
    let (files, dirs) = collect(fs, dir)?;
    let mut bytes = 0u64;
    for f in &files {
        bytes += f.1;
    }
    Ok(Summary {
        files: files.len() as u64,
        dirs,
        bytes,
        largest: files.first().cloned(),
    })
}

pub fn top_n(fs: &Fs, dir: &str, n: usize) -> io::Result<Vec<(String, u64)>> {
    let (mut files, _) = collect(fs, dir)?;
    files.truncate(n);
    Ok(files)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sim::SimRoot;

    fn setup(sim: &SimRoot) {
        sim.world.file("data/a.txt", "hello");
        sim.world.file("data/sub/b.bin", "0123456789");
        sim.world.file("data/sub/deeper/c", "abcdefghij");
        sim.fs.create_dir_all("data/empty").unwrap();
    }

    #[sim_test(seeds = 5)]
    fn summary(sim: SimRoot) {
        setup(&sim);
        let s = summarize(&sim.fs, "data").unwrap();
        assert_eq!(
            s,
            Summary { files: 3, dirs: 3, bytes: 25, largest: Some(("sub/b.bin".to_string(), 10)) }
        );
    }

    #[sim_test(seeds = 5)]
    fn top(sim: SimRoot) {
        setup(&sim);
        assert_eq!(
            top_n(&sim.fs, "data", 2).unwrap(),
            vec![("sub/b.bin".to_string(), 10), ("sub/deeper/c".to_string(), 10)]
        );
        assert_eq!(top_n(&sim.fs, "data", 0).unwrap(), vec![]);
    }

    #[sim_test(seeds = 5)]
    fn empty(sim: SimRoot) {
        setup(&sim);
        let s = summarize(&sim.fs, "data/empty").unwrap();
        assert_eq!(s, Summary { files: 0, dirs: 0, bytes: 0, largest: None });
    }

    #[sim_test(seeds = 5)]
    fn missing(sim: SimRoot) {
        setup(&sim);
        assert_eq!(summarize(&sim.fs, "nope").unwrap_err().kind(), io::ErrorKind::NotFound);
        assert_eq!(top_n(&sim.fs, "nope", 1).unwrap_err().kind(), io::ErrorKind::NotFound);
    }
}
