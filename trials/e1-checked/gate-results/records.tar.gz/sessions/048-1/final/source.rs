use std::collections::{BTreeMap, HashMap, HashSet};
use std::io;
use std::path::Path;

#[derive(Debug, PartialEq, Eq, Clone, thiserror::Error)]
pub enum PlanError {
    #[error("duplicate source: {0}")]
    DuplicateSource(String),
    #[error("duplicate target: {0}")]
    DuplicateTarget(String),
}

pub fn plan(moves: &[(&str, &str)]) -> Result<Vec<(String, String)>, PlanError> {
    let mut srcs = HashSet::new();
    let mut dsts = HashSet::new();
    for &(s, d) in moves {
        if !srcs.insert(s) {
            return Err(PlanError::DuplicateSource(s.to_string()));
        }
        if !dsts.insert(d) {
            return Err(PlanError::DuplicateTarget(d.to_string()));
        }
    }
    let all: HashSet<&str> = moves.iter().flat_map(|&(s, d)| [s, d]).collect();

    let mut pending: BTreeMap<&str, &str> = BTreeMap::new();
    let mut inv: HashMap<&str, &str> = HashMap::new();
    for &(s, d) in moves {
        if s != d {
            pending.insert(s, d);
            inv.insert(d, s);
        }
    }
    let mut out = Vec::new();

    // Paths: start from moves whose target is not a source.
    let ends: Vec<(&str, &str)> = pending
        .iter()
        .filter(|(_, d)| !pending.contains_key(**d))
        .map(|(s, d)| (*s, *d))
        .collect();
    for (s, d) in ends {
        pending.remove(s);
        out.push((s.to_string(), d.to_string()));
        let mut cur = s;
        while let Some(&p) = inv.get(cur) {
            pending.remove(p);
            out.push((p.to_string(), cur.to_string()));
            cur = p;
        }
    }

    // Remaining: cycles.
    while let Some((&s, &d)) = pending.iter().next() {
        pending.remove(s);
        let mut tmp = format!("{s}.tmp");
        while all.contains(tmp.as_str()) {
            tmp.push_str(".tmp");
        }
        out.push((s.to_string(), tmp.clone()));
        let mut cur = s;
        loop {
            let p = inv[cur];
            if p == s {
                break;
            }
            pending.remove(p);
            out.push((p.to_string(), cur.to_string()));
            cur = p;
        }
        debug_assert_eq!(cur, d);
        out.push((tmp, d.to_string()));
    }
    Ok(out)
}

pub fn apply(dir: &Path, steps: &[(String, String)]) -> io::Result<()> {
    let mut produced: HashSet<&str> = HashSet::new();
    for (s, d) in steps {
        let ok = produced.contains(s.as_str()) || dir.join(s).symlink_metadata().is_ok();
        if !ok {
            return Err(io::Error::new(
                io::ErrorKind::NotFound,
                format!("source not found: {s}"),
            ));
        }
        produced.insert(d.as_str());
    }
    for (s, d) in steps {
        std::fs::rename(dir.join(s), dir.join(d))?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn check(moves: &[(&str, &str)]) {
        let steps = plan(moves).unwrap();
        let mut fs: HashMap<String, usize> = HashMap::new();
        for (i, (s, _)) in moves.iter().enumerate() {
            fs.insert(s.to_string(), i);
        }
        for (s, d) in &steps {
            assert!(!fs.contains_key(d), "target exists: {d} in {steps:?}");
            let v = fs.remove(s).expect("source missing");
            fs.insert(d.clone(), v);
        }
        for (i, (_, d)) in moves.iter().enumerate() {
            assert_eq!(fs.remove(*d), Some(i));
        }
        assert!(fs.is_empty(), "{fs:?}");
    }

    #[test]
    fn plans() {
        check(&[("a", "b"), ("b", "a")]);
        check(&[("a", "b"), ("b", "c")]);
        check(&[("a", "b"), ("b", "c"), ("c", "a")]);
        check(&[("a", "a.tmp"), ("a.tmp", "a")]);
        check(&[("a", "b"), ("b", "a"), ("x", "y"), ("c", "d"), ("d", "e"), ("e", "c"), ("q", "q")]);
        assert_eq!(plan(&[("a", "a")]).unwrap(), vec![]);
        assert_eq!(
            plan(&[("a", "b"), ("a", "c")]),
            Err(PlanError::DuplicateSource("a".into()))
        );
        assert_eq!(
            plan(&[("a", "c"), ("b", "c")]),
            Err(PlanError::DuplicateTarget("c".into()))
        );
    }

    #[test]
    fn apply_files() {
        let dir = std::env::temp_dir().join(format!("renameplan-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("a"), "1").unwrap();
        std::fs::write(dir.join("b"), "2").unwrap();
        apply(&dir, &plan(&[("a", "b"), ("b", "a")]).unwrap()).unwrap();
        assert_eq!(std::fs::read_to_string(dir.join("a")).unwrap(), "2");
        assert_eq!(std::fs::read_to_string(dir.join("b")).unwrap(), "1");
        let e = apply(&dir, &[("x".into(), "y".into())]).unwrap_err();
        assert_eq!(e.kind(), io::ErrorKind::NotFound);
        assert!(!dir.join("y").exists());
        std::fs::remove_dir_all(&dir).unwrap();
    }
}
