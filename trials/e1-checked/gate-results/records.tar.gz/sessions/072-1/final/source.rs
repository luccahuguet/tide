use std::collections::BTreeMap;
use std::json;
use std::process::ExitCode;

#[derive(Debug, Clone, Copy, PartialEq, Decode)]
enum Op {
    #[codec(rename = "read")]
    Read,
    #[codec(rename = "write")]
    Write,
}

#[derive(Debug, Decode)]
struct Rec {
    user: String,
    bytes: u64,
    op: Op,
}

#[derive(Debug, PartialEq)]
struct Report {
    /// Standard output text.
    out: String,
    /// Standard error lines, without the newline.
    errs: Vec<String>,
    /// Whether the program fails.
    failed: bool,
}

/// Authority-free: computes the whole report from the input text.
fn run(input: &str) -> Report {
    let mut totals: BTreeMap<String, (u64, u64)> = BTreeMap::new();
    let mut errs = Vec::new();
    let mut failed = false;
    let mut overflow = false;
    for (i, line) in input.lines().enumerate() {
        if line.trim().is_empty() {
            continue;
        }
        let n = i + 1;
        match json::decode::<Rec>(line.as_bytes()) {
            Ok(rec) => {
                let entry = totals.entry(rec.user).or_insert((0, 0));
                let slot = match rec.op {
                    Op::Read => &mut entry.0,
                    Op::Write => &mut entry.1,
                };
                match slot.checked_add(rec.bytes) {
                    Some(v) => *slot = v,
                    None => overflow = true,
                }
            }
            Err(e) => {
                errs.push(format!("usage: line {n}: {e}"));
                failed = true;
            }
        }
    }
    if overflow {
        errs.push(String::from("usage: overflow"));
        return Report { out: String::new(), errs, failed: true };
    }
    let mut out = String::new();
    for (user, (r, w)) in &totals {
        out.push_str(&format!("{user} read={r} write={w}\n"));
    }
    Report { out, errs, failed }
}

#[tide::main]
fn main(root: Root) -> ExitCode {
    let mut input = String::new();
    if let Err(e) = root.stdin.read_to_string(&mut input) {
        eprintln!("usage: cannot read standard input: {e}");
        return ExitCode::FAILURE;
    }
    let report = run(&input);
    for e in &report.errs {
        eprintln!("{e}");
    }
    print!("{}", report.out);
    if report.failed { ExitCode::FAILURE } else { ExitCode::SUCCESS }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn totals_sorted() {
        let r = run("{\"user\":\"bo\",\"bytes\":5,\"op\":\"read\"}\n{\"user\":\"al\",\"bytes\":7,\"op\":\"write\",\"extra\":1}\n{\"user\":\"bo\",\"bytes\":3,\"op\":\"write\"}\n");
        assert_eq!(r.out, "al read=0 write=7\nbo read=5 write=3\n");
        assert!(r.errs.is_empty());
        assert!(!r.failed);
    }

    #[test]
    fn bad_line() {
        let r = run("{\"user\":\"bo\",\"bytes\":5,\"op\":\"read\"}\n{bad\n{\"user\":\"al\",\"bytes\":7,\"op\":\"write\",\"extra\":1}\n{\"user\":\"bo\",\"bytes\":3,\"op\":\"write\"}\n");
        assert_eq!(r.out, "al read=0 write=7\nbo read=5 write=3\n");
        assert_eq!(r.errs.len(), 1);
        assert!(r.errs[0].starts_with("usage: line 2: "));
        assert!(r.failed);
    }

    #[test]
    fn bad_op_and_negative() {
        let r = run("{\"user\":\"a\",\"bytes\":1,\"op\":\"delete\"}\n\n{\"user\":\"a\",\"bytes\":-1,\"op\":\"read\"}\n");
        assert_eq!(r.out, "");
        assert_eq!(r.errs.len(), 2);
        assert!(r.errs[0].starts_with("usage: line 1: "));
        assert!(r.errs[1].starts_with("usage: line 3: "));
        assert!(r.failed);
    }

    #[test]
    fn empty() {
        let r = run("");
        assert_eq!(r, Report { out: String::new(), errs: vec![], failed: false });
    }

    #[test]
    fn overflow() {
        let r = run("{\"user\":\"a\",\"bytes\":18446744073709551615,\"op\":\"read\"}\n{\"user\":\"a\",\"bytes\":18446744073709551615,\"op\":\"read\"}\n");
        assert_eq!(r.out, "");
        assert_eq!(r.errs, vec![String::from("usage: overflow")]);
        assert!(r.failed);
    }
}
