use std::fmt;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CalcError {
    DivByZero { pos: usize },
    Overflow { pos: usize },
    Unexpected { pos: usize },
}

impl fmt::Display for CalcError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            CalcError::DivByZero { pos } => write!(f, "division by zero at {pos}"),
            CalcError::Overflow { pos } => write!(f, "overflow at {pos}"),
            CalcError::Unexpected { pos } => write!(f, "unexpected input at {pos}"),
        }
    }
}

impl std::error::Error for CalcError {}

enum Expr {
    Num(i64),
    Neg(usize, Box<Expr>),
    Bin(u8, usize, Box<Expr>, Box<Expr>),
}

struct Parser<'a> {
    s: &'a [u8],
    i: usize,
}

impl Parser<'_> {
    fn skip(&mut self) {
        while self.i < self.s.len() && self.s[self.i].is_ascii_whitespace() {
            self.i += 1;
        }
    }

    fn peek(&mut self) -> Option<u8> {
        self.skip();
        self.s.get(self.i).copied()
    }

    fn expr(&mut self) -> Result<Expr, CalcError> {
        let mut lhs = self.term()?;
        while let Some(c @ (b'+' | b'-')) = self.peek() {
            let pos = self.i;
            self.i += 1;
            let rhs = self.term()?;
            lhs = Expr::Bin(c, pos, Box::new(lhs), Box::new(rhs));
        }
        Ok(lhs)
    }

    fn term(&mut self) -> Result<Expr, CalcError> {
        let mut lhs = self.unary()?;
        while let Some(c @ (b'*' | b'/' | b'%')) = self.peek() {
            let pos = self.i;
            self.i += 1;
            let rhs = self.unary()?;
            lhs = Expr::Bin(c, pos, Box::new(lhs), Box::new(rhs));
        }
        Ok(lhs)
    }

    fn unary(&mut self) -> Result<Expr, CalcError> {
        match self.peek() {
            Some(b'-') => {
                let pos = self.i;
                self.i += 1;
                let e = self.unary()?;
                Ok(Expr::Neg(pos, Box::new(e)))
            }
            Some(b'(') => {
                self.i += 1;
                let e = self.expr()?;
                match self.peek() {
                    Some(b')') => {
                        self.i += 1;
                        Ok(e)
                    }
                    _ => Err(CalcError::Unexpected { pos: self.i }),
                }
            }
            Some(c) if c.is_ascii_digit() => {
                let start = self.i;
                let mut v: Option<i64> = Some(0);
                while self.i < self.s.len() && self.s[self.i].is_ascii_digit() {
                    let d = (self.s[self.i] - b'0') as i64;
                    v = v
                        .and_then(|v| v.checked_mul(10))
                        .and_then(|v| v.checked_add(d));
                    self.i += 1;
                }
                v.map(Expr::Num)
                    .ok_or(CalcError::Overflow { pos: start })
            }
            _ => Err(CalcError::Unexpected { pos: self.i }),
        }
    }
}

fn evaluate(e: &Expr) -> Result<i64, CalcError> {
    match e {
        Expr::Num(n) => Ok(*n),
        Expr::Neg(pos, e) => evaluate(e)?
            .checked_neg()
            .ok_or(CalcError::Overflow { pos: *pos }),
        Expr::Bin(op, pos, l, r) => {
            let a = evaluate(l)?;
            let b = evaluate(r)?;
            let pos = *pos;
            let res = match op {
                b'+' => a.checked_add(b),
                b'-' => a.checked_sub(b),
                b'*' => a.checked_mul(b),
                _ => {
                    if b == 0 {
                        return Err(CalcError::DivByZero { pos });
                    }
                    if *op == b'/' {
                        a.checked_div(b)
                    } else {
                        a.checked_rem(b)
                    }
                }
            };
            res.ok_or(CalcError::Overflow { pos })
        }
    }
}

pub fn eval(src: &str) -> Result<i64, CalcError> {
    let mut p = Parser {
        s: src.as_bytes(),
        i: 0,
    };
    let e = p.expr()?;
    if p.peek().is_some() {
        return Err(CalcError::Unexpected { pos: p.i });
    }
    evaluate(&e)
}

#[cfg(test)]
mod tests {
    use super::*;
    use CalcError::*;

    #[test]
    fn values() {
        assert_eq!(eval("1 + 2 * 3"), Ok(7));
        assert_eq!(eval("(1+2)*3"), Ok(9));
        assert_eq!(eval("-(-4) % 3"), Ok(1));
        assert_eq!(eval("7 / -2"), Ok(-3));
        assert_eq!(eval("- 9223372036854775807 - 1"), Ok(i64::MIN));
        assert_eq!(eval("10 - 3 - 2"), Ok(5));
    }

    #[test]
    fn errors() {
        assert_eq!(eval("1 / (2 - 2)"), Err(DivByZero { pos: 2 }));
        assert_eq!(eval("9223372036854775807 + 1"), Err(Overflow { pos: 20 }));
        assert_eq!(eval("9223372036854775808"), Err(Overflow { pos: 0 }));
        assert_eq!(eval("-9223372036854775808"), Err(Overflow { pos: 1 }));
        assert_eq!(eval("-(-9223372036854775807 - 1)"), Err(Overflow { pos: 0 }));
        assert_eq!(eval("2 *"), Err(Unexpected { pos: 3 }));
        assert_eq!(eval("(1"), Err(Unexpected { pos: 2 }));
        assert_eq!(eval("1 2"), Err(Unexpected { pos: 2 }));
        assert_eq!(eval(""), Err(Unexpected { pos: 0 }));
        assert_eq!(eval("a"), Err(Unexpected { pos: 0 }));
    }

    #[test]
    fn display() {
        assert_eq!(DivByZero { pos: 2 }.to_string(), "division by zero at 2");
        assert_eq!(Overflow { pos: 3 }.to_string(), "overflow at 3");
        assert_eq!(Unexpected { pos: 4 }.to_string(), "unexpected input at 4");
    }
}
