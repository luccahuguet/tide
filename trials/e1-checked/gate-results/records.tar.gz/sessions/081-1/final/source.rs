use std::fs;
use std::io;
use std::path::Path;

#[derive(Debug, PartialEq, Clone)]
pub struct Summary {
    pub files: u64,
    pub dirs: u64,
    pub bytes: u64,
    pub largest: Option<(String, u64)>,
}

fn walk(dir: &Path, prefix: &str, files: &mut Vec<(String, u64)>, dirs: &mut u64) -> io::Result<()> {
    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let name = entry.file_name().to_string_lossy().into_owned();
        let rel = if prefix.is_empty() { name } else { format!("{prefix}/{name}") };
        let meta = fs::symlink_metadata(entry.path())?;
        let ft = meta.file_type();
        if ft.is_dir() {
            *dirs += 1;
            walk(&entry.path(), &rel, files, dirs)?;
        } else if ft.is_file() {
            files.push((rel, meta.len()));
        }
    }
    Ok(())
}

fn collect(dir: &Path) -> io::Result<(Vec<(String, u64)>, u64)> {
    let meta = fs::metadata(dir)?;
    if !meta.is_dir() {
        return Err(io::Error::new(io::ErrorKind::NotADirectory, "not a directory"));
    }
    let mut files = Vec::new();
    let mut dirs = 0;
    walk(dir, "", &mut files, &mut dirs)?;
    files.sort_by(|a, b| b.1.cmp(&a.1).then_with(|| a.0.cmp(&b.0)));
    Ok((files, dirs))
}

pub fn summarize(dir: &Path) -> io::Result<Summary> {
    let (files, dirs) = collect(dir)?;
    Ok(Summary {
        files: files.len() as u64,
        dirs,
        bytes: files.iter().map(|f| f.1).sum(),
        largest: files.first().cloned(),
    })
}

pub fn top_n(dir: &Path, n: usize) -> io::Result<Vec<(String, u64)>> {
    let (mut files, _) = collect(dir)?;
    files.truncate(n);
    Ok(files)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;

    fn setup(name: &str) -> PathBuf {
        let root = std::env::temp_dir().join(format!("treesize_{}_{}", name, std::process::id()));
        let _ = fs::remove_dir_all(&root);
        let data = root.join("data");
        fs::create_dir_all(data.join("sub/deeper")).unwrap();
        fs::create_dir_all(data.join("empty")).unwrap();
        fs::write(data.join("a.txt"), b"12345").unwrap();
        fs::write(data.join("sub/b.bin"), b"0123456789").unwrap();
        fs::write(data.join("sub/deeper/c"), b"0123456789").unwrap();
        data
    }

    #[test]
    fn cases() {
        let data = setup("cases");
        assert_eq!(
            summarize(&data).unwrap(),
            Summary { files: 3, dirs: 3, bytes: 25, largest: Some(("sub/b.bin".into(), 10)) }
        );
        assert_eq!(
            top_n(&data, 2).unwrap(),
            vec![("sub/b.bin".to_string(), 10), ("sub/deeper/c".to_string(), 10)]
        );
        assert_eq!(top_n(&data, 0).unwrap(), vec![]);
        assert_eq!(
            summarize(&data.join("empty")).unwrap(),
            Summary { files: 0, dirs: 0, bytes: 0, largest: None }
        );
        assert_eq!(summarize(&data.join("nope")).unwrap_err().kind(), io::ErrorKind::NotFound);
        assert_eq!(top_n(&data.join("nope"), 1).unwrap_err().kind(), io::ErrorKind::NotFound);
        let _ = fs::remove_dir_all(data.parent().unwrap());
    }
}
