//! A concurrent line server over TCP, and its client.

use std::io::{self, BufRead, BufReader, Write};
use std::net::{TcpListener, TcpStream};
use std::thread;

/// Handles one connection; returns the number of lines answered.
fn handle(stream: TcpStream) -> u64 {
    let mut writer = match stream.try_clone() {
        Ok(w) => w,
        Err(_) => return 0,
    };
    let mut reader = BufReader::new(stream);
    let mut count = 0u64;
    let mut buf = Vec::new();
    loop {
        buf.clear();
        match reader.read_until(b'\n', &mut buf) {
            Ok(0) | Err(_) => break,
            Ok(_) => {}
        }
        if buf.last() != Some(&b'\n') {
            // Unterminated final line: end of input.
            break;
        }
        buf.pop();
        let line = match std::str::from_utf8(&buf) {
            Ok(s) => s,
            Err(_) => break,
        };
        if line == "QUIT" {
            break;
        }
        let mut reply: String = line.chars().rev().collect();
        reply.push('\n');
        if writer.write_all(reply.as_bytes()).is_err() || writer.flush().is_err() {
            break;
        }
        count += 1;
    }
    count
}

/// Accepts exactly `clients` connections, handles them concurrently, and
/// returns the total number of lines answered.
pub fn serve(listener: &TcpListener, clients: usize) -> io::Result<u64> {
    thread::scope(|s| {
        let mut handles = Vec::with_capacity(clients);
        let mut accept_err = None;
        for _ in 0..clients {
            match listener.accept() {
                Ok((stream, _)) => handles.push(s.spawn(move || handle(stream))),
                Err(e) => {
                    accept_err = Some(e);
                    break;
                }
            }
        }
        let total: u64 = handles.into_iter().map(|h| h.join().unwrap_or(0)).sum();
        match accept_err {
            Some(e) => Err(e),
            None => Ok(total),
        }
    })
}

/// Connects to `addr`, sends each line and reads its reply, then sends
/// `QUIT`, and returns the replies.
pub fn exchange(addr: &str, lines: &[&str]) -> io::Result<Vec<String>> {
    let stream = TcpStream::connect(addr)?;
    let mut writer = stream.try_clone()?;
    let mut reader = BufReader::new(stream);
    let mut replies = Vec::with_capacity(lines.len());
    for line in lines {
        let mut msg = String::with_capacity(line.len() + 1);
        msg.push_str(line);
        msg.push('\n');
        writer.write_all(msg.as_bytes())?;
        writer.flush()?;
        let mut reply = String::new();
        let n = reader.read_line(&mut reply)?;
        if n == 0 || !reply.ends_with('\n') {
            return Err(io::Error::new(
                io::ErrorKind::UnexpectedEof,
                "connection closed before reply",
            ));
        }
        reply.pop();
        replies.push(reply);
    }
    writer.write_all(b"QUIT\n")?;
    writer.flush()?;
    Ok(replies)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::mpsc;

    #[test]
    fn three_clients() {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let server = thread::spawn(move || serve(&listener, 3).unwrap());
        let a = addr.clone();
        let b = addr.clone();
        let c = addr.clone();
        let t1 = thread::spawn(move || exchange(&a, &["abc", "héllo"]).unwrap());
        let t2 = thread::spawn(move || exchange(&b, &["x"]).unwrap());
        let t3 = thread::spawn(move || exchange(&c, &[]).unwrap());
        assert_eq!(t1.join().unwrap(), vec!["cba", "olléh"]);
        assert_eq!(t2.join().unwrap(), vec!["x"]);
        assert!(t3.join().unwrap().is_empty());
        assert_eq!(server.join().unwrap(), 3);
    }

    #[test]
    fn concurrent() {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let server = thread::spawn(move || serve(&listener, 2).unwrap());
        let (tx, rx) = mpsc::channel::<()>();
        let a = addr.clone();
        let first = thread::spawn(move || {
            let mut s = TcpStream::connect(&a).unwrap();
            s.write_all(b"hold\n").unwrap();
            let mut r = BufReader::new(s.try_clone().unwrap());
            let mut line = String::new();
            r.read_line(&mut line).unwrap();
            assert_eq!(line, "dloh\n");
            rx.recv().unwrap();
            drop(s);
        });
        let got = exchange(&addr, &["second"]).unwrap();
        assert_eq!(got, vec!["dnoces"]);
        tx.send(()).unwrap();
        first.join().unwrap();
        assert_eq!(server.join().unwrap(), 2);
    }

    #[test]
    fn unterminated_and_empty_lines() {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap().to_string();
        let server = thread::spawn(move || serve(&listener, 1).unwrap());
        let mut s = TcpStream::connect(&addr).unwrap();
        s.write_all(b"\npartial").unwrap();
        s.shutdown(std::net::Shutdown::Write).unwrap();
        let mut out = String::new();
        io::Read::read_to_string(&mut s, &mut out).unwrap();
        assert_eq!(out, "\n");
        assert_eq!(server.join().unwrap(), 1);
    }
}
