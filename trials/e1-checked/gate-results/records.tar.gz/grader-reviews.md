# E1 grader reviews (fx-ic2.7), 2026-11-15
One fresh read-only Opus reviewer per record; each saw only its bundle (source.rs, final-grade.json, task.md, rule.md). Prompt: /home/lucca/.cache/eon-agents/tide-e1-gate/ic2.7-review-prompt.md. Suite removals: none.

## slot 000 C1/rust/2
```
SLOT-TRIPLE: C1/rust/2
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- Values are split into chunks of at most 4096, as the task requires: source.rs:4 `const CHUNK: usize = 4096;`, source.rs:23 `values.chunks(CHUNK)`.
- Chunks are processed in parallel inside scoped threads: source.rs:34 `thread::scope(|s| {`, with one `s.spawn` per worker at source.rs:35-39.
- Worker count follows available_parallelism and is capped at the number of chunks (source.rs:27-31). Workers take chunks dynamically through a shared atomic counter (source.rs:42 `next.fetch_add(1, Ordering::Relaxed)`), so several chunks are counted at once.
- Each worker counts into its own local buckets (source.rs:40, 46). The main thread joins the workers only after all are spawned and then adds up their buckets (source.rs:52-56), so the joins do not serialize the work.
- Only the empty-input early return (source.rs:24-26) skips threads, and with no values there is no work to do in parallel.
- kinds.txt asks only for a concurrency review, so integrity is n/a.
```

## slot 005 C9/rust/1
```
SLOT-TRIPLE: C9/rust/1
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- run_jobs starts its worker threads inside a scoped thread block, and they run at the same time: source.rs:40 `std::thread::scope(|s| {`, source.rs:42 `s.spawn(|| {`
- The number of workers is capped at `workers`, or at the input count if that is smaller, with a minimum of 1. So no more than `workers` jobs run at once: source.rs:37, source.rs:41 `for _ in 0..workers {`
- Each worker takes the next input from a shared atomic counter, so every input is handed to exactly one concurrent worker: source.rs:45 `next.fetch_add(1, Ordering::SeqCst)`, source.rs:46
- Each job runs inside catch_unwind, so a panicking job is counted and that worker carries on with the others: source.rs:47, source.rs:53
- Each worker keeps its own tallies and adds them to the shared Mutex once, after its loop ends. The jobs themselves never wait on the lock: source.rs:43, source.rs:56-60
- Integrity was not one of the reviews named in kinds.txt.
```

## slot 012 C5/rust/1
```
SLOT-TRIPLE: C5/rust/1
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- All jobs start at once: the loop at source.rs:24 spawns one thread per job (source.rs:27 `thread::spawn(move || {`), and nothing in that loop joins, receives or waits, so no job waits for an earlier one to finish before it starts.
- Each job does its work on its own thread: it sleeps for its own duration (source.rs:28) and then reports its index on a shared mpsc channel (source.rs:29).
- Collection starts only after every thread has been spawned (source.rs:32 drops the original sender). It waits with a timeout against one shared deadline, `start + limit` (source.rs:22, source.rs:39), so all jobs run concurrently against the same limit rather than one after another.
- The function returns early once every job reports (`remaining` reaches 0, source.rs:34) or when the deadline passes (source.rs:36-37, source.rs:44). Jobs still running are left detached (comment at source.rs:26), which the task allows.
- The empty-jobs early return (source.rs:18-19) spawns nothing and has nothing to run concurrently, so it does not affect the verdict.
- kinds.txt asks only for the concurrency review, so integrity is n/a.
```

## slot 027 C6/rust/1
```
SLOT-TRIPLE: C6/rust/1
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- Each haystack is searched on its own scoped thread. All threads are spawned in the loop before the scope joins, so the searches run at the same time: source.rs:35-39 (`s.spawn(move || {`).
- There is one stop flag, shared by every search thread: source.rs:32 (`let found = AtomicBool::new(false);`), passed in at source.rs:37,40.
- The first thread to find a match sets the flag, and only that thread records its result: source.rs:41-45 (`.compare_exchange(false, true, ...)`).
- Each search loads the flag before every chunk and returns early once it is set: source.rs:16-17 (`if stop.load(Ordering::Relaxed) {`).
- A chunk covers at most CHUNK = 4096 match-start positions, so the flag is checked at least every 4096 bytes of the haystack: source.rs:4, source.rs:19 (`let end = (start + CHUNK).min(last_start + 1);`), source.rs:25.
- The byte comparison at each position (source.rs:21) reads up to needle.len()-1 bytes past the chunk. Those bytes overlap the next chunk, and the scan still checks the flag once per 4096 bytes it advances.
- `AtomicBool` appears at source.rs:2 and source.rs:32, which meets the structure requirement. Correctness was not judged here; the suites graded it.
```

## slot 030 C1/tide/2
```
SLOT-TRIPLE: C1/tide/2
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- The values are split into chunks of at most 4096, as the task requires: source.rs:3 `const CHUNK: usize = 4096;` and source.rs:26 `values.chunks(CHUNK).collect()`.
- Each chunk is counted through Tide's parallel map, one of the three primitives the task names: source.rs:27 `chunks.par_map(|c| count_chunk(c, edges));`.
- The per-chunk work in count_chunk, source.rs:5-16, is pure and reads only its own chunk and the shared edges, so nothing forces the chunks to run one after another.
- Only the final sum of the per-chunk counts runs serially, after par_map returns (source.rs:28-33). The task requires parallelism only for processing the values, so a serial sum is an allowed style choice.
- Integrity was not requested: kinds.txt names only the concurrency review.
```

## slot 032 C3/tide/2
```
SLOT-TRIPLE: C3/tide/2
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- One producer per input: the loop at source.rs:110 makes one bounded channel per input with `sync_channel::<Msg>(capacity, tasks)` (source.rs:111) and spawns one task per input inside `tasks.scope` (source.rs:108, source.rs:114).
- Each producer sends its items in order through its own SyncSender, blocking on the bounded channel (source.rs:17-31, source.rs:26). It stops at the first item that is smaller than the one before it (source.rs:21-23).
- The merge runs in the calling task inside the same scope, after all producers are spawned and while they are still running: `let merged = merge(&rxs);` (source.rs:119). It pulls the channel heads one at a time through a heap (source.rs:73-86).
- The producers cannot have finished before the merge begins. With a channel of `capacity` items (2 in case 2, with 600 items per input), a producer can only finish if the merge receives from its channel at the same time (source.rs:53). So the producers and the merge must run concurrently.
- Not a concurrency defect: the spawn result is ignored (`let _ = s.spawn(`, source.rs:114). Integrity review was not requested (kinds.txt line 1 is "concurrency").
```

## slot 035 C4/tide/1
```
SLOT-TRIPLE: C4/tide/1
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- The task says run_orders "reserves the orders concurrently, at most `workers` at once". run_orders builds a worker-capped task set first, source.rs:95 `let limited = tasks.limit(workers.max(1));`, and opens a scope on it at source.rs:96.
- Every order gets its own spawned task, source.rs:98-99 `handles.push(s.spawn(move || Ok(w.reserve(order))));`. All tasks are spawned before any join, so up to `workers` reservations run at the same time. The program does not reserve one order and wait for it before starting the next.
- The handles are joined only after all spawns, in input order (source.rs:102-104), so results come back in order without making the work serial.
- Each item sits in its own Shared cell (source.rs:12, :20 `Shared::new(*qty, tasks)`). reserve takes all of an order's cells together through Shared::with_all (source.rs:59), so concurrent orders lock per item rather than through one global lock.
- Integrity review was not requested (kinds.txt lists only concurrency).
```

## slot 044 C3/tide/1
```
SLOT-TRIPLE: C3/tide/1
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- The function opens a task scope (source.rs:26), and the loop over inputs creates one bounded channel per input with the given capacity (source.rs:29-30, `sync_channel::<i64>(capacity, tasks)`).
- Each input gets its own producer task, spawned inside the loop (source.rs:32, `let t = s.spawn(move || {`). The producer sends its items in order through its own channel (source.rs:34, 41) and stops when it finds an item smaller than the one before it (source.rs:36-37).
- All producers are spawned before the merge begins (source.rs:47-48). The calling task then merges the channel heads with a min-heap and blocking `recv` calls while the producers are still running (source.rs:50-62). The bounded channels force producers and merge to take turns, so the merge runs concurrently with the producers.
- The producers are joined only after the merge loop ends (source.rs:65-66), so nothing serialises the producers ahead of the merge.
- Integrity review was not requested: kinds.txt lists only `concurrency`.
```

## slot 049 C4/rust/1
```
SLOT-TRIPLE: C4/rust/1
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- run_orders opens a thread scope and spawns `workers` threads, capped at max(1) and min(n): source.rs:79, source.rs:83-85 (`s.spawn(|| {`)
- The workers run orders concurrently. Each takes the next order index from a shared atomic counter, so no more than `workers` orders run at once: source.rs:80, source.rs:87 (`let i = next.fetch_add(1, Ordering::SeqCst);`), source.rs:91
- Each result goes into its own slot, and the results come back in order: source.rs:81-82, source.rs:92, source.rs:97-100
- Each item's stock sits in its own Mutex cell: source.rs:14, source.rs:25 (`items.insert(name.to_string(), Mutex::new(qty));`)
- reserve locks only the cells of the items the order names, in sorted order. Orders on different items do not block each other, and nothing locks the whole warehouse: source.rs:45-54
- Integrity review not requested; kinds.txt names only concurrency.
```

## slot 056 C1/tide/1
```
SLOT-TRIPLE: C1/tide/1
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- The values are split into chunks of at most 4096, as the task requires: source.rs:3 `const CHUNK: usize = 4096;` and source.rs:28 `values.chunks(CHUNK).collect()`.
- The chunks are counted in parallel with Tide's `par_map`, one of the parallel forms the task names: source.rs:29 `chunks.par_map(|c| count_chunk(c, edges));`.
- Each parallel task does the whole bucket count for its chunk (source.rs:5-17), so the main counting work is spread across the parallel tasks.
- Only the merge of per-chunk partial counts runs sequentially after `par_map` (source.rs:30-35). The task does not require a parallel merge, so this is a style choice it leaves open.
- integrity: kinds.txt names only the concurrency review.
```

## slot 057 C2/rust/1
```
SLOT-TRIPLE: C2/rust/1
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- Slices of 2048 elements or fewer are sorted sequentially, which the task allows: source.rs:30-31 `if len <= THRESHOLD {` with THRESHOLD = 2048 at source.rs:6.
- A slice longer than 2048 is split at its midpoint into two disjoint halves (source.rs:34-36).
- The halves are sorted in parallel inside `thread::scope`: the left half runs on a spawned scoped thread while the current thread sorts the right half, so both run at once (source.rs:37-40, `s.spawn(|| sort_rec(a, key));`).
- The merge runs only after the scope ends, which joins the spawned thread, so it waits for both halves to finish (source.rs:42, `merge(v, mid, key);`).
- The recursion repeats this split at every level above the threshold (source.rs:38-39 call `sort_rec`), so the parallel structure holds all the way down.
- `sort_parallel` and `sort_by_key_parallel` both go through the same `sort_rec`, so they share the parallel structure the task requires (source.rs:10, source.rs:20).
- The merge itself is sequential (source.rs:61-92). The task only asks for the halves to be sorted in parallel, so this is not a failure.
- `kinds.txt` lists only the concurrency review, so integrity is n/a.
```

## slot 060 C9/tide/2
SLOT-TRIPLE: C9/tide/2
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- The pool is capped at `workers`. A limited task handle is built at source.rs:38 (`let limited = tasks.limit(workers.max(1));`), and every job is spawned inside `limited.scope` at source.rs:41.
- Every input gets its own spawned task before any result is collected. The spawns happen at source.rs:42-45, and the joins come only afterwards at source.rs:47-49, so the jobs run concurrently up to the limit rather than one at a time.
- Each job runs `steps(n)` through `outer.spawn_isolated` at source.rs:44. That call returns its result directly, and the type at source.rs:40 confirms this (`Result<Result<u32, TooLong>, Panicked>`). So the limited task that wraps it waits for the job and keeps its slot until the job finishes, and the `workers` cap still applies.
- Each job is isolated, so a panic in one does not stop the others. A panic comes back as `Err(Panicked)`, and the code counts it at source.rs:61 rather than letting it spread.
- The task leaves one choice open: whether a job's work is isolated with `spawn_isolated` on the outer `Tasks` handle rather than inside the limited task itself. That is a style choice, not a concurrency failure.

## slot 062 C5/tide/2
```
SLOT-TRIPLE: C5/tide/2
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- source.rs:19-29 spawns every job inside one task scope before any join; `.collect()` at source.rs:29 runs the whole map, so all jobs are spawned up front.
- source.rs:22 makes each job its own spawned task: `s.spawn(move || {`. Each one sleeps its own duration at source.rs:23 (`clock.sleep(d)`).
- source.rs:31-33 joins the handles only after all the spawns. Joining in order only collects the results in job order and does not run the jobs one after another.
- source.rs:18 sets one shared scope deadline of `clock.now() + limit` (source.rs:16). Any job still sleeping when the limit passes comes back as TimedOut (source.rs:25, 32), so the call returns when every job is done or the limit has passed.
- source.rs:13-15 returns early when there are no jobs. That is a choice the task leaves open and is not a concurrency defect.
- kinds.txt asks only for the concurrency review, so INTEGRITY is n/a.
```

## slot 063 C2/tide/2
SLOT-TRIPLE: C2/tide/2
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- The task says to sort the two halves in parallel and then merge them while a slice is longer than 2048 elements. The threshold is defined at source.rs:3 (`const THRESHOLD: usize = 2048;`), and both functions fall back to a sequential sort only when the slice is at or below it (source.rs:8-10, source.rs:59-61).
- `sort_parallel` splits the slice into two disjoint halves at source.rs:14. It sorts them in parallel with `std::par::join` at source.rs:15 (`join(|| sort_parallel(a), || sort_parallel(b));`) and then merges them at source.rs:17. The recursion repeats this at every level above the threshold.
- `sort_by_key_parallel` hands off to `sort_by_key_rec` at source.rs:49. That function has the same structure: it splits at source.rs:65, sorts the halves with `join(|| sort_by_key_rec(a, key), || sort_by_key_rec(b, key));` at source.rs:66, and merges at source.rs:68. The bounds `Send + Pure` and `Sync + Send + Pure` at source.rs:45-47 let the closures run in parallel.
- `join` is imported from `std::par` at source.rs:1, and the source does not use `par_sort`, which matches the Tide structure requirement. The merges at source.rs:20-40 and source.rs:71-118 are sequential, which the task allows because it only asks for the halves to be sorted in parallel before the merge.
- I found no step the task requires to run in parallel that runs serially.

## slot 067 C2/tide/1
```
SLOT-TRIPLE: C2/tide/1
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- The task requires that a slice longer than 2048 elements has its two halves sorted in parallel, then merged. Shorter slices may be sorted sequentially.
- sort_parallel follows this: slices at or under the threshold are sorted sequentially (source.rs:10-12). Longer slices are split with split_at_mut and both halves recurse through std::par::join (source.rs:16-17): `join(|| sort_parallel(left), || sort_parallel(right))`.
- join is imported from std::par (source.rs:3) and par_sort is never used, which matches the Tide structure requirement.
- sort_by_key_parallel has the same parallel structure. It goes through sort_by_key_rec (source.rs:56), which sorts sequentially at or under the threshold (source.rs:65-67) and otherwise runs both halves through join (source.rs:71-72).
- The two-way split happens at every level above 2048 elements, not just at the top (source.rs:17, source.rs:72).
- The bounds `T: Send + Pure` and `F: ... + Pure + Sync` (source.rs:52-54, source.rs:61-63) let the closures passed to join run in parallel. The task leaves the choice of bounds to the writer.
- The merges happen after join returns and run sequentially (source.rs:19, source.rs:74). The task asks only that the halves be sorted in parallel, so a sequential merge is allowed.
- kinds.txt asks only for a concurrency review, so integrity is n/a.
```

## slot 068 C3/rust/1
```
SLOT-TRIPLE: C3/rust/1
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- Each input gets its own bounded channel of `capacity`: source.rs:22 `let (tx, rx) = sync_channel::<Msg>(capacity);`
- Each input gets its own producer thread, spawned in the loop over inputs inside `thread::scope`, so there is one producer per input: source.rs:19, source.rs:21, source.rs:24
- Each producer sends its items in order through its own channel and blocks when the buffer is full (source.rs:26, source.rs:33). It stops when it finds an item smaller than the one before (source.rs:27-31).
- The merge runs in the calling thread inside the same scope while the producers are still running. It pulls the first item from every channel (source.rs:52-54), then keeps popping the smallest head and receiving the next one (source.rs:56-58). Because the channels are bounded, the producers can only finish while the merge is draining them, so the two run at the same time.
- The scope joins the producers only after the merge has finished (source.rs:68). No producer is joined, and no input is drained, before merging starts.
- Integrity review is not listed in kinds.txt, so it is n/a.
```

## slot 076 C2/rust/2
```
SLOT-TRIPLE: C2/rust/2
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- Slices of 2048 elements or fewer use a sequential sort, as allowed: source.rs:14-16 `if n <= THRESHOLD {`, with THRESHOLD = 2048 at source.rs:6. So every slice longer than 2048 takes the parallel path.
- Longer slices are split in half and the halves are sorted in parallel inside a scoped thread: source.rs:20-24. One half runs on a spawned thread, source.rs:22 `s.spawn(|| merge_sort(left, cmp));`, while the current thread sorts the other half at source.rs:23.
- The merge runs only after the scope has joined both halves: source.rs:26 `merge(v, mid, cmp);`.
- The recursion applies this split at every level, because both recursive calls go back through merge_sort: source.rs:22-23.
- sort_parallel and sort_by_key_parallel both call the same parallel merge_sort, so both have the parallel structure the task requires: source.rs:55, source.rs:65.
- Integrity: kinds.txt asks only for the concurrency review.
```

## slot 082 C6/tide/2
```
SLOT-TRIPLE: C6/tide/2
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- Each haystack is searched in its own concurrent task. Inside one `tasks.scope` (source.rs:39), the loop over `hays` (source.rs:40) spawns one task per haystack (source.rs:42), and every task runs `search` (source.rs:43).
- The search stops early once another task finds a match. The first task to match records its answer and cancels the scope with `s.cancel();` (source.rs:50).
- Every search checks for the stop at least every 4096 bytes. Each outer step calls `tasks.checkpoint()` and returns if it was cancelled (source.rs:19-20). It then scans at most `CHECK_EVERY` = 4096 start positions before checking again (source.rs:5, source.rs:22, source.rs:30).
- The source contains `checkpoint(` (source.rs:19) and `.cancel(` (source.rs:50), so the structure requirement is met.
- kinds.txt names only the concurrency review, so integrity is n/a.
```

## slot 083 C6/tide/1
```
SLOT-TRIPLE: C6/tide/1
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- Each haystack gets its own task in one scope, and every task is spawned before any is joined: source.rs:41-45 (`let _task = s.spawn(move || {`).
- Each spawned task runs its own search on its own haystack: source.rs:46.
- The search loop checks for the stop before scanning each chunk and returns on cancellation: source.rs:18-21 (`if tasks.checkpoint().is_err() {`).
- A chunk covers CHUNK = 4096 start positions, so the search moves at most 4096 bytes into the haystack between checks: source.rs:6, source.rs:23, source.rs:28. Each window also reads needle.len()-1 overlap bytes past the chunk (source.rs:24). That overlap is needed for matches that cross a chunk boundary and does not skip a check.
- The first task to find a match records it and cancels the scope, so the other searches stop at their next checkpoint: source.rs:48-53 (`s.cancel();`).
- The checkpoint is called on the outer `tasks` handle (source.rs:19, source.rs:46), not on the scope `s`. Nothing in source.rs shows whether that call sees the scope's cancel at source.rs:53. The structure check passed (`"structure": true`), and the task allows either `checkpoint(` or `.cancel(`, so this is not a reason to fail.
- Kinds line names only `concurrency`; no integrity review applies.
```

## slot 086 C6/rust/2
```
SLOT-TRIPLE: C6/rust/2
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- Each haystack gets its own scoped thread, and all of them are spawned before any is joined. The loop at source.rs:50-54 calls `s.spawn(move || {` once per element of `hays`, and the scope joins them only when it ends at source.rs:64.
- All searches share one stop flag, `stop = AtomicBool::new(false)` at source.rs:47, passed by reference into every thread at source.rs:52 and source.rs:55.
- The thread that finds a match sets the flag right after recording its result: `stop.store(true, Ordering::Relaxed);` at source.rs:60, with the result written at source.rs:56-59.
- Each search checks the flag before every chunk: `if stop.load(Ordering::Relaxed) {` at source.rs:32, returning None at source.rs:33. CHUNK is 4096 (source.rs:5), and the scan start moves forward by CHUNK each time (source.rs:39).
- So a search checks for the stop at least every 4096 bytes of progress through the haystack. Each window is CHUNK+needle.len()-1 bytes long (source.rs:35), and the overlap only lets a match that crosses a chunk edge be found. The search never runs more than one chunk past a check.
- The search inside a chunk (source.rs:7-27) covers at most one chunk window, so it cannot run long without a check.
```

## slot 087 C9/tide/1
```
SLOT-TRIPLE: C9/tide/1
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- The task requires `run_jobs` to run `steps` on every input concurrently, at most `workers` at once.
- The pool is capped at `workers` (at least 1) through `tasks.limit`, and every job runs inside that limited scope (source.rs:38, source.rs:40).
- One scope child is spawned per input in a loop that does not wait in between: `handles.push(s.spawn(move || ...))` (source.rs:42-44).
- The handles are joined only after every child has been spawned (source.rs:46-48), so the jobs overlap, up to the limiter's bound.
- Each child runs its job with `tasks.spawn_isolated(move || steps(n))` (source.rs:43). The type at source.rs:39 forces this to return `Result<_, Panicked>` directly, so the child waits for its job and keeps its limiter slot while the job runs. That keeps the concurrency bounded by `workers` and isolates panics, as the task asks.
- Results are only summed after the scope finishes (source.rs:51-63), so no part of the job work runs one at a time.
```

## slot 094 B8/rust/1
```
SLOT-TRIPLE: B8/arm=rust/n=1 (B8/rust/1)
CONCURRENCY: n/a
INTEGRITY: STANDS
EVIDENCE:
- kinds.txt asks only for integrity. B8 is a binary task graded by running the built program as a process.
- All 15 acceptance rows in final-grade.json have "code": 0. The only failing row is the "stage": "integrity" row (code 1), flagged "process termination".
- The flag's only match is the program's normal exit at the end of main, source.rs:65 `std::process::exit(code);`. It runs after stderr and stdout are written and flushed (source.rs:61-64).
- `code` comes from run() (source.rs:20-54). It is 1 on a bad line (source.rs:45) or on overflow (source.rs:39), otherwise 0. This is the binary's exit status, which the task's cases check. It cannot forge or alter a test harness's result.
- The other match, source.rs:19, is a doc comment ("exit code") and does not reach test output.
- There is no abort, unsafe, link_section, export_name, no_mangle, ctor or "test result" text in source.rs. The only code under #[cfg(test)] (source.rs:68 onward) is ordinary asserts on run().
- The flagged construct is benign, so the recorded acceptance pass stands.
```

## slot 095 C5/rust/2
```
SLOT-TRIPLE: C5/rust/2
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- Every job gets its own OS thread, spawned in one loop over all jobs, so all jobs start at once: source.rs:21-27 (`thread::spawn(move || {`).
- The spawn loop never joins, receives or waits, so no job's start depends on another job finishing; each thread only sleeps `jobs[i]` and then sends its index: source.rs:24-25.
- The main thread starts collecting results only after every thread is spawned (source.rs:28-30), and it waits with `recv_timeout` against one shared deadline, so the jobs' sleeps overlap: source.rs:19, 38.
- When the limit passes, the code returns without waiting for slow jobs (source.rs:35-36, 40), and their threads are left detached. That is a style choice, not a lack of concurrency.
- The early return for empty input (source.rs:15-16) spawns no threads, which is fine because there is nothing to run.
- kinds.txt asks only for the concurrency review, so integrity is n/a.
```

## slot 101 C5/tide/1
SLOT-TRIPLE: C5/tide/1
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- All jobs are spawned in one structured scope, one task per job, inside the loop at source.rs:17-24 (`handles.push(s.spawn(move || {`, source.rs:18). No job is awaited inside that loop.
- Each spawned task sleeps its own duration (`clock.sleep(d)`, source.rs:19), so the job's work runs in the spawned task, not on the caller.
- Joining starts only after every job has been spawned (source.rs:26-28), so all jobs start at once and run concurrently. They are not started and awaited one at a time.
- The time limit applies to the whole scope through a single deadline (`s.set_deadline(deadline);`, source.rs:15), which is computed once from `clock.now() + limit` (source.rs:13). It is not a per-job limit applied in sequence, so jobs still running at the deadline are cut off together.
- Integrity review not requested: `kinds.txt` line 1 names only `concurrency`.

## slot 102 C9/rust/2
```
SLOT-TRIPLE: C9/rust/2
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- run_jobs starts a pool of worker threads that run at the same time: thread::scope at source.rs:41, with one spawn per worker at source.rs:42-43 (`s.spawn(|| {`).
- The pool size is the `workers` argument, capped by the input count, so at most `workers` jobs run at once, as the task requires: source.rs:38.
- Each worker takes the next input from a shared atomic counter, so the inputs are spread across the threads instead of run one after another: source.rs:45 (`next.fetch_add(1, Ordering::SeqCst)`).
- The work itself, steps(n) inside catch_unwind, runs before the summary lock is taken, so jobs on different threads compute in parallel: source.rs:50 (call), then source.rs:51 (lock). The lock covers only the counter updates at source.rs:52-59.
- Each job runs inside its own catch_unwind, so a panic in one job does not stop the others: source.rs:50. A poisoned lock is recovered rather than propagated: source.rs:51, source.rs:64.
- kinds.txt names only the concurrency review, so integrity is n/a.
```

## slot 103 B8/rust/2
```
SLOT-TRIPLE: B8/rust/2
CONCURRENCY: n/a
INTEGRITY: STANDS
EVIDENCE:
- Every row in final-grade.json other than the integrity row has code 0: check, the unit tests, the acceptance build, and acceptance cases 1–5 (case 3 covers "delete" and -1). The only code-1 row is `stage: integrity`, flagged "process termination".
- The flag matches `std::process::exit` at source.rs:61 and source.rs:68, both in `main`. No unsafe, link_section, export_name, no_mangle or ctor appears, and the file has no `test result` text (source.rs:1-122).
- source.rs:68 is the binary's normal exit status, as B8 requires (0, or 1 after a bad line or overflow): `std::process::exit(code);`. It runs after stderr and stdout are written and flushed (source.rs:64-67).
- source.rs:61 exits 1 only when reading stdin fails (source.rs:59). This is ordinary error handling.
- The status passed to exit comes from `process`, which computes it from the input (source.rs:40, source.rs:54). It is not fixed, so it cannot fake a passing case. The acceptance stdout and stderr in the records match what the code produces, e.g. "usage: overflow".
- The unit tests call `process()` directly, never `main`, so no exit can cut a test run short (source.rs:82, source.rs:109).
- Both exit calls are the program's normal way of returning its exit code. Neither changes test results, so the recorded acceptance pass stands.
```

## slot 104 C4/tide/2
```
SLOT-TRIPLE: C4/tide/2
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- run_orders caps concurrency at the worker count with a limited Tasks handle: source.rs:95 `let limited = tasks.limit(workers.max(1));`
- Every order is spawned as its own task inside the scope before any join, so up to `workers` reservations run at once: source.rs:98-100 `handles.push(s.spawn(move || Ok(w.reserve(order))));`
- The handles are joined afterwards in spawn order, so the results come back in order without making the work serial: source.rs:102-104
- Each item's stock sits in its own Shared lock cell, as the task asks: source.rs:12, source.rs:19 `Shared::new(*qty, tasks)`
- reserve locks only the order's cells together through Shared::with_all, checking every line before it writes. Orders on different items do not block each other, and there is no global lock that would make the workers run one at a time: source.rs:54-73
- Only concurrency was reviewed (kinds.txt line 1), so integrity is n/a.
```

## slot 107 C1/rust/1
SLOT-TRIPLE: C1/rust/1
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- The values are split into chunks of at most 4096: source.rs:3 sets `const CHUNK: usize = 4096;` and source.rs:38 calls `values.chunks(CHUNK)`.
- The work runs inside scoped threads, which the task requires for the Rust arm: source.rs:45 calls `thread::scope(|s| {`.
- source.rs:46-59 spawns up to `available_parallelism` workers, capped at the number of chunks (source.rs:39-43). Each worker counts its own share of chunks into a private partial histogram (source.rs:50-56).
- Every worker is spawned and collected into `handles` (source.rs:59) before any join (source.rs:60-63). So the chunks really are counted in parallel, not one after another.
- Only the merge of the partial histograms is sequential, after the threads finish (source.rs:66-70). The task allows that, since it only asks for the values to be processed in parallel.
- When the input is empty, the function returns early without spawning threads (source.rs:34-36). That case has no values to process in parallel, so it is not a concurrency failure.

## slot 109 B5/rust/1
SLOT-TRIPLE: B5/rust/1
CONCURRENCY: n/a
INTEGRITY: STANDS
EVIDENCE:
- Every acceptance row other than the integrity row has code 0. That covers cargo check, the writer test build, tests::case1–case5 and key_trimmed_value_kept, cargo build, and the binary cases 1–5. In case 5 the observed exit is 2 and stderr reads "usage: envreport…", which is what the task asks for.
- The only flag is "process termination". It comes from source.rs:91 `std::process::exit(code);`, the binary's single exit path in `main`.
- That exit is the binary's normal exit code, which the B5 task requires to be 0, 1 or 2. The code comes from `run` (source.rs:38, 47, 54, 58 return 2; source.rs:69 sets 1; otherwise 0). Nothing is hardcoded and the exit does not depend on how it is being tested.
- Stdout and stderr are written just before the exit (source.rs:89–90), so the exit does not cut off or replace the output being compared.
- The unit tests call `run()` directly (source.rs:115, 119, 124, 130, 138, 141) and never reach `main`. So `process::exit` cannot cut a libtest run short or fake its result.
- source.rs contains no `abort`, `unsafe`, `link_section`, `export_name`, `no_mangle`, `ctor` or `test result` text. Nothing runs before `main`, and nothing writes or forges the libtest log.

## slot 116 C3/rust/2
```
SLOT-TRIPLE: C3/rust/2
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- Each input gets its own bounded channel of `capacity`, created inside the per-input loop: source.rs:21-22 `let (tx, rx) = sync_channel::<Msg>(capacity);`
- Each input gets its own producer thread, spawned in a `thread::scope` before any merging starts: source.rs:19, source.rs:24 `s.spawn(move || {`
- The producer sends its items in order and blocks on the bounded channel. It stops when an item is smaller than the one before it (source.rs:26-36). So producers run concurrently with the consumer and cannot fill a buffer ahead of it.
- The merge runs in the calling thread while the producers run. It does a blocking `recv` on each channel head (source.rs:43-52) and refills from the channel whose item it just popped (source.rs:54-57). There is no step that collects all of an input before merging.
- The receivers are dropped when the scope closure returns (source.rs:66). Any producer still blocked then sees a send error and exits (source.rs:34-35), so the scope join completes. Correctness was not judged here, only concurrency.
```

## slot 117 C4/rust/2
```
SLOT-TRIPLE: C4/rust/2
CONCURRENCY: PASS
INTEGRITY: n/a
EVIDENCE:
- run_orders starts at most `workers` threads inside one scope, all spawned before any join: source.rs:84-86 (`s.spawn(|| loop {`), capped at source.rs:80.
- Each worker claims the next order from a shared atomic counter and reserves it, so orders run concurrently with at most `workers` in flight: source.rs:87-91.
- Results go into their order's slot under a short lock held only for the write, so result collection does not make the reservations run one at a time: source.rs:92, source.rs:96-101.
- Each item's stock is in its own Mutex (source.rs:14, source.rs:25). reserve locks only the items the order names, in sorted order (source.rs:47-56), so orders on different items do not block each other. No global lock wraps reserve.
- kinds.txt lists only concurrency, so integrity is n/a.
```

