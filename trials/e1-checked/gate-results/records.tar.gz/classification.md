# E1 failure classification (fx-ic2.10), 2026-11-15
One fresh read-only Opus classifier per failing trial (bundle: snapshots, grade records, task text, classes.md, and for Tide the reference). Prompt: T/ic2.10-prompt.md.
Adjudication (fx-ic2.7, reopened): /home/lucca/.cache/eon-agents/tide-e1-gate/ic2.7-c3-disputes.md. All four C3 suite disputes are not valid. Each C3 final failure is a structure-check failure that stands under protocol §6; no test removed, no regrade. Entries 044 and 068 are corrected to 'ordinary bug', TOOLCHAIN-DEFECT no (the harness applied the task's literal wording exactly).

## slot 029 C10/tide/2
TRIPLE: C10/tide/2
FAILURE: first-check
CLASS: ordinary bug
TOOLCHAIN-DEFECT: no
SUITE-DISPUTE: no
EVIDENCE:
- The failure is in the check stage of the writer's own tests (`tide-admit --test` on package lib.rs). It exits with code 1 and error E0277: "`tide_std::cell::Cell<()>` cannot be shared between threads safely" at lib.rs:134:37 (first-grade.json:369-372).
- The library check exits 0 (first-grade.json:180). The acceptance suite also checks clean against the library (first-grade.json:559, stage L). So the only failure is in the writer's own test module.
- Column 37 of first-source.rs:134 is the non-`move` child closure `let first = s.spawn(|| {`. That closure uses `rx.recv()` (first-source.rs:142), so it borrows `rx`, which is the `Receiver` from `sync_channel` at first-source.rs:129.
- `Scope::spawn` requires `f: ... + Send + 's` (reference.md:593). A closure that holds `&Receiver` is `Send` only if `Receiver: Sync`. The `Receiver`'s `Cell<()>` marker is not `Sync`, so rustc correctly rejects the borrow.
- This is not a Tide-specific rule. Reference 7.3 says channels "are Rust's `std::sync::mpsc`" (reference.md:688), and Rust's `Receiver` is `!Sync` too. Reference §1 keeps ownership, borrowing and std traits as in Rust (reference.md:29-31). Plain Rust 2024 with `std::thread::scope` would reject the same code, so this is neither a leaked Rust habit nor a Tide design gap.
- Reference 7.1 does say "Children may borrow anything that outlives the `scope` call" (reference.md:605) without restating the `Sync` requirement. But the `Send + 's` bound printed on `spawn` covers that, so I don't count it as a reference gap.
- The writer's fix confirms the diagnosis: final-source.rs:134-136 and :150 rebind `net` and `addr` as references and switch to `s.spawn(move || ...)`, so the child owns `rx` (and `tx`) instead of borrowing them.
- I found no toolchain defect: the diagnostic is correct and points at the right span.
- No suite dispute: the failure happens before any acceptance test runs, in the writer's own test code.

## slot 032 C3/tide/2
```
TRIPLE: C3/tide/2
FAILURE: final
CLASS: ordinary bug
TOOLCHAIN-DEFECT: no
SUITE-DISPUTE: suspected
EVIDENCE:
- The only failing item in the final record is the structure check: final-grade.json:2 reads `"structure": false`.
- Every build and test stage passed. All stage `code` values are 0, including the "L" stage (final-grade.json:1662-1673).
- All four acceptance cases passed. Cases 1-3 pass 20/20 seeds (final-grade.json:2037, 2221, 2405). case4 is `should panic ... ok`, with the cause "capacity must be positive" at lib.rs:107 (final-grade.json:2589).
- The writer's own tests passed too: basic_cases, many_inputs and unsorted are each `ok` (final-grade.json:920, 1104, 1288).
- The task's structure clause asks that the source contain the literal text `sync_channel(` (task.md:63-64, C3 "Tide:" bullet).
- The writer called the function with a turbofish, so that literal text never appears: final-source.rs:111 `let (tx, rx) = sync_channel::<Msg>(capacity, tasks);`. The only other occurrence is the import list, final-source.rs:3 `use std::sync::mpsc::{sync_channel, Receiver, SyncSender};`.
- The turbofish was not needed: the type is already fixed by `rxs: Vec<Receiver<Msg>>` (final-source.rs:109). Writing it that way missed a stated literal requirement. It is not a Rust habit, because turbofish is valid in Tide, and it is not a reference gap: reference.md §7.3 (line 690) shows the form `sync_channel(n, tasks)`.
- The first snapshot is identical to the final one, and first-grade.json:2 also reads `"structure": false`.
- Why I suspect a suite dispute: the check is a text match standing in for "uses a bounded sync_channel per producer". The program does exactly that. It calls `sync_channel` once per input with `capacity` (final-source.rs:110-117) and merges the channel heads in the calling task (final-source.rs:119), as the task's first bullet requires. A grader reading the code, as the preface says graders do for concurrency, would confirm it. The trial fails only on how the call is spelled, not on what the program does.
```
ADJUDICATED: SUITE-DISPUTE not valid (structure check stands).

## slot 033 C10/tide/1
```
TRIPLE: C10/tide/1
FAILURE: first-check
CLASS: Rust habit leaked
TOOLCHAIN-DEFECT: no
SUITE-DISPUTE: no
EVIDENCE:
- Stage: all three check runs fail with the same diagnostic (lib check, lib --test, and acceptance stage L), each with exit code 1: "lib.rs:13:1: error: FX0401: no module can hold this impl" (first-grade.json:183, :372, :562). No test ran.
- The rejected item is first-source.rs:13, `impl From<SrvError> for io::Error {`. Both the trait (`From`) and the type (`io::Error`) belong to std, so the impl's only local part is the generic argument.
- Rust 2024's orphan rule accepts this impl because `SrvError` is local. Writing `?` conversion into a foreign error type this way is the standard Rust idiom, and here it feeds the `?` at first-source.rs:68 that turns the scope's `SrvError` into `io::Result`.
- The reference states the rule plainly: reference.md:319-320 (§5.2 Impl placement) says an `impl` lives in the module that defines the type, or for trait impls the trait (`FX0401`). This impl satisfies neither condition, so it is not a reference gap.
- The reference also explains the pattern that led here: §7.1 (reference.md:619-620) says a scope's error enum needs a `#[from] TaskError` variant, and the task's signature requires `io::Result` (task.md, C10 Tide signature line). The reference gives no example of converting such an enum back into `io::Error`. That makes the Rust habit easy to fall into, but the rule itself is not missing.
- The diagnostic's suggested fix works and the writer used something like it: final-source.rs:13 turns the impl into an inherent `impl SrvError` with an `into_io` method, called at final-source.rs:69 via `.map_err(SrvError::into_io)?`.
- No suite dispute: the failure is a static checker rejection before any acceptance test ran, so it does not depend on the task wording, timing or the environment.
```

## slot 044 C3/tide/1
```
TRIPLE: C3/tide/1
FAILURE: final
CLASS: ordinary bug (a spelling slip against a literal structure check; no behaviour fault)
TOOLCHAIN-DEFECT: yes
SUITE-DISPUTE: suspected
EVIDENCE:
- Only the structure gate failed: final-grade.json:2 is `"structure": false`. Every other stage exited 0.
- All tests passed. The writer's own basic, many and unsorted passed 20/20 seeds (final-grade.json:920,1104,1288).
- The acceptance cases also passed: case1, case2 and case3 at 20/20 seeds (final-grade.json:2037,2221,2405).
- case4 "should panic ... ok" panicked at lib.rs:24 with "capacity must be positive" (final-grade.json:2589).
- The task's structure rule is that the source contains `sync_channel(` (task.md, C3, Tide signature bullet).
- The source never has that exact substring. The import at final-source.rs:3 has no parenthesis: `use std::sync::mpsc::{sync_channel, Receiver};`
- The only call uses a turbofish (final-source.rs:30): `let (tx, rx) = sync_channel::<i64>(capacity, tasks);`
- That is a real bounded `sync_channel` call with `capacity`, one per producer, as reference.md §7.3 (line 690) teaches with `sync_channel(n, tasks)`.
- The program does what the rule exists to confirm: per-input bounded channels, producers spawned in `tasks.scope` (final-source.rs:26-32), and the heads merged in the calling task (final-source.rs:50-62).
- Toolchain defect (harness): the structure check is a literal text match. It rejects a valid generic call to the required function, so a program that meets the requirement is failed for its spelling.
- Why not reference gap or Rust habit: the reference has no rule against the turbofish, and turbofish is ordinary Rust 2024 syntax. Taken alone, the writer's part is a trivial spelling slip.
- Suite dispute: the task text (C3, "structure:" parenthetical) says what the source should contain but not that the check is an exact substring. A reasonable reading is "the program uses `sync_channel`", which it does.
- first-source.rs and final-source.rs are identical, so the writer never changed this spelling.
```
CORRECTED by adjudication: CLASS: ordinary bug; TOOLCHAIN-DEFECT: no; SUITE-DISPUTE: not valid (structure check stands).

## slot 047 B4/tide/2
I've checked the failing stage, the source lines and the reference sections; the classification is below.

```
TRIPLE: B4/tide/2
FAILURE: first-check
CLASS: Rust habit leaked
TOOLCHAIN-DEFECT: no
SUITE-DISPUTE: no
EVIDENCE:
- The first check failed when the writer's own lib.rs was compiled, before any acceptance test ran.
  All three builds exit 1: lib, own `--test`, and acceptance stage "L" (first-grade.json:180, :369, :559-570).
- The diagnostic is E0308 at lib.rs:47:12 and lib.rs:50:12, "expected `bool`, found `Result<bool, Error>`"
  (first-grade.json:183). The `--test` build adds E0600 at lib.rs:100:17,
  "cannot apply unary operator `!`" to `Result<bool, io::Error>` (first-grade.json:372).
- The cited lines use `Fs::exists` as a plain bool: first-source.rs:47 `if self.fs.exists(OLD1) {`,
  first-source.rs:50 `if self.fs.exists(CURRENT) {`, and the test at first-source.rs:100
  `assert!(!sim.fs.exists("old.1.log"));`.
- The reference does decide the type. reference.md:386-389 (§6.3) lists `exists` among the `Fs` methods that
  work "as std::fs", and Rust's `std::fs::exists` returns `io::Result<bool>`.
  reference.md:557 (§6.9) also names `Path::exists` as a banned habit and says to use `fs` instead.
  So the writer carried over the habit of `Path::exists() -> bool`, which is Rust's convenience method.
- Partly mitigating: §6.3 gives no explicit return type for `exists`, so the reader has to know that
  `std::fs::exists` is fallible. The rule still decides it, so this is not a reference gap.
- Not a toolchain defect: the checker applied the documented signature correctly.
- No suite dispute: the failure is a type error in the writer's own code and does not depend on
  anything the task leaves open (task.md:52-58, behaviour of rotation and `open`).
```

## slot 051 B6/tide/1
```
TRIPLE: B6/tide/1
FAILURE: first-check
CLASS: Rust habit leaked
TOOLCHAIN-DEFECT: no
SUITE-DISPUTE: no
EVIDENCE:
- Stage: the `--test` check of the writer's own package failed with exit 1 (first-grade.json:365-369). The plain library check before it exited 0 (first-grade.json:180), so the library code itself was admitted.
- Diagnostic: four E0600 errors, "cannot apply unary operator `!` to type `Result<bool, io::Error>`", at lib.rs 62:17, 63:17, 72:17 and 79:17 (first-grade.json:372).
- Cause: the writer's tests treat `Fs::exists` as if it returned a plain bool, as Rust's `Path::exists` does, for example first-source.rs:62 `assert!(!sim.fs.exists("out/ok"));`. The same mistake is at first-source.rs:63, 72 and 79.
- The reference teaches the right type. reference.md:387-388 lists `exists` among the Fs methods that behave "as std::fs", and `std::fs::exists` returns `io::Result<bool>`. reference.md:557 also says `Path::exists` is not admitted and points to `fs` instead. Tide's std follows that rule, so this is not a toolchain defect.
- A single rereading of the signature could leave the return type unclear, but "as std::fs" settles it. The writer fell back on the familiar bool-returning `Path::exists`, which is a Rust habit and not a reference gap.
- Confirmed by the fix: final-source.rs:62, 63, 72 and 79 change only by adding `.unwrap()`, e.g. final-source.rs:62 `assert!(!sim.fs.exists("out/ok").unwrap());`.
- Not a suite dispute: the failure is a compile error in the writer's own tests, and no acceptance test was involved.
```

## slot 068 C3/rust/1
```
TRIPLE: C3/rust/1
FAILURE: final
CLASS: toolchain defect (harness: structure check matches literal text only)
TOOLCHAIN-DEFECT: yes
SUITE-DISPUTE: suspected
EVIDENCE:
- Only the structure check failed: final-grade.json:2 `"structure": false`. Every stage exits 0 (cargo check :139, test build :288, all runs).
- The writer's tests and the acceptance tests pass: final-grade.json:600,754,908,1062 (basic, many, unsorted, zero_cap) and :1675,1829,1983,2137 (`ok case1`…`ok case4`).
- The program does use a bounded channel. It just spells the call with a turbofish, so the text `sync_channel(` never appears:
  final-source.rs:22 `let (tx, rx) = sync_channel::<Msg>(capacity);`
  final-source.rs:3 `use std::sync::mpsc::{Receiver, sync_channel};`
- The check is a plain substring search, so it rejects a real `sync_channel` call written with explicit generics. This is a harness bug, not a program bug: the behaviour matches the task (one producer per input at final-source.rs:21-38, bounded channel of `capacity`, merge in the caller at :41-67).
- None of the four classes fits. There is no Rust habit (this is the Rust arm and the code is idiomatic Rust 2024), no reference gap (no reference in a Rust trial), and no behavioural bug.
- Suite dispute: task.md §C3, in its Rust signature bullet, gives "the source contains `sync_channel(`" as a structure check. Its purpose is to confirm bounded channels are used (§C3's first bullet; the Preface's note that a grader reads the source to confirm concurrency). It does not ask for a particular spelling. The turbofish form meets that purpose, so the failure comes from how literally the check reads the text, not from what the program does.
- The first snapshot has the same pattern and the same failure (first-source.rs:22; first-grade.json:2 `"structure": false`). It is not listed for classification.
```
CORRECTED by adjudication: CLASS: ordinary bug; TOOLCHAIN-DEFECT: no; SUITE-DISPUTE: not valid (structure check stands).

## slot 112 A10/rust/2
```
TRIPLE: A10/rust/2
FAILURE: first-check
CLASS: ordinary bug
TOOLCHAIN-DEFECT: no
SUITE-DISPUTE: no
EVIDENCE:
- Stage: `cargo check --offline --locked --all-targets` exited 101 (first-grade.json:133-139). No acceptance test ran.
- Diagnostic E0599 at src/lib.rs:107 (first-grade.json:142): no method named `as_ptr_range` found for `&'static str`.
- The failing line is in the writer's own unit test `slices`, not the library code (first-source.rs:105-109): `let r = T.as_ptr_range();`
- `as_ptr_range` is a slice (`[T]`) method that `str` does not have. This is a plain API slip in a self-written pointer check. It is not a Rust habit leaking into Tide, since this is the Rust arm and the writer used std as the preface allows (task.md:9-11).
- The library items compiled with no diagnostics: `Doc`, `sentences`, `longest`, `words_of`, and `with_word` with `+ use<'a, 'w>` (first-source.rs:56-84). rustc reported only this one error.
- The final snapshot fixes it by going through bytes (final-source.rs:107): `let r = T.as_bytes().as_ptr_range();`
- No suite dispute: the failure is a compile error in the writer's own test and is deterministic. No acceptance test ran, so no test's reading of the task text is in question.
```

## slot 116 C3/rust/2
TRIPLE: C3/rust/2
FAILURE: final
CLASS: ordinary bug
TOOLCHAIN-DEFECT: no
SUITE-DISPUTE: suspected
EVIDENCE:
- The only failed stage is the structure check: final-grade.json:2 has `"structure": false`. Every check and test command exited with code 0. That covers the writer's tests basic, large, unsorted and zero_capacity, and the acceptance tests case1 to case4 (final-grade.json:1674, :1828, :1982, :2136). There are no diagnostics and no panics other than the expected capacity-0 panic.
- task.md:64-66 (C3, Rust signature) requires that the source contain the literal text `sync_channel(`.
- The source creates its channels only with a turbofish call, final-source.rs:22 `let (tx, rx) = sync_channel::<Msg>(capacity);`, so the text `sync_channel(` never appears. The other match, final-source.rs:3, is an import with no `(` after the name.
- The program does what the task asks. It uses one bounded `sync_channel` per input and one scoped producer thread each (final-source.rs:19-38), and merges with a heap in the calling thread (final-source.rs:41-57). The writer missed a spelling requirement, which is an ordinary bug and not a behaviour error.
- Why I flag a suite dispute: in the task's own words (task.md:62-66) the structure note is a proxy for "uses bounded channels." `sync_channel::<Msg>(capacity)` is the same std call with an explicit type argument. A plain substring check rejects that legal spelling, so the check tests the spelling rather than the behaviour. A check that allowed an optional turbofish would pass this source.
- It is not a Rust habit leak or a reference gap, because this is the Rust arm and no reference applies. It is not a toolchain defect either, because the harness applied the check exactly as task.md states it.
ADJUDICATED: SUITE-DISPUTE not valid (structure check stands).

