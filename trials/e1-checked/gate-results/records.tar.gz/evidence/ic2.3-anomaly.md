# fx-ic2.3 batch 1-3 anomaly: investigation report

Scope: run /home/lucca/.cache/eon-agents/tide-e1-gate/run, sessions 000-1 (C1/rust/2),
001-1 (B6/rust/1), 002-1 (A9/tide/1); gate worktree at 675c26e (clean tree). Read-only:
only Python inspection ran; no writer, grading or compile was started.

## Verdict

**valid**, with a harness accounting defect that affects only the recorded output-token
field. Pass/fail results stand. A real writer produced each graded solution, and the frozen
suites compiled and ran against it. The output-token counts in trial.json and the summary are
too low: 419/522/24 recorded, 2072/3112/3443 actual.

## Mechanism (the token defect)

- The CLI 2.1.321 stream-json emits one `assistant` event per content block. Each event of a
  message carries that message's start-of-stream usage snapshot, where `output_tokens` is a
  placeholder (3-16). Only the final `result` event carries cumulative usage.
- coordinator.py:108 keys messages by id, so the last event per id wins. coordinator.py:115-117
  then sums each message's `usage`, which is that snapshot. Per-id output snapshots:
  000-1 [4,4,4],[415]; 001-1 [5,5],[16,16],[501]; 002-1 [16],[5,5,5],[3,3].
  The sums of 419, 522 and 24 equal the recorded figures exactly.
- The `result` event (writer.jsonl, last line) gives output_tokens 2072 / 3112 / 3443, with
  thinking 160 / 327 / 207. `modelUsage` gives the same values.
- Unaffected fields: summed input, cache-read and cache-creation equal the result event in all
  three sessions (4/4703/18960, 6/10460/19800, 6/41959/33349). `peak_context`
  (coordinator.py:118) uses only input-side fields, which are final at message start, so
  18962 / 19802 / 36728 are correct.
- `turns` counts distinct assistant message ids (2/3/3); the CLI's `num_turns` is 3/4/4.
  Two definitions, not a bug; the report should name which one it uses.
- Tokens are "recorded but not gated" (protocol.md 7.4, lines 197-203); no verdict uses them.

## Evidence that grading was real

- Staging: the writer's entry file is staged empty (harness.py:531, `reference` is false for
  gate sessions). The workdir held only the expected writer files: Cargo.toml, Cargo.lock and
  prompt.md for rust; reference.md, reference-companion.md, tide.toml and prompt.md for tide.
- Writer activity: each session made exactly one Write to src/lib.rs, then one
  `mcp__e1__test` call. The content written is byte-identical to snapshot-01/source.rs,
  final/source.rs and the frozen workdir file. Sizes and SHA-256 prefixes:
  000-1 3216 B 72dce95b3046314f; 001-1 4787 B 67b7c5a5b82b6683; 002-1 5472 B 241519a8464fb932.
  Each matches final/identity.json and trial.json `final_sha256`. A single 3-5 KB Write
  agrees with 2-3.4k real output tokens and 28-36 s of writer time.
- Not the reference: no final equals its reference solution (reference sizes 926 / 1861 /
  2410 B, different hashes). C1 and B6 share 4 and 7 long lines with their references. A9
  shares 28, nearly all type, field and signature declarations. All 44 identifiers in those
  28 lines occur in the writer-visible prompt.md or reference.md, so the shared API shape
  comes from the task specification.
- No leak: the writer's tool calls touched only its own workdir: Read Cargo.toml (B6), Read
  reference.md (A9), Write, and mcp test. No writer log contains a `references/`, `suites/` or
  `tasks.md` path. The only worktree path in the logs is the vendored crate directory, which
  appears in the writer's own cargo test output. Audit: 0 breaches and 0 denied requests.
- Suite applied: grade reads final/source.rs (harness.py:732). package() writes the frozen
  suite into tests/acceptance.rs (harness.py:371). The suites tree hash, recomputed now over
  37 tracked files, is 266980350754c1c9..., which equals state.json `suites_tree_sha256`.
- Not vacuous: in each final-grade.json, the acceptance listing returned exactly the frozen
  ACCEPTANCE_TESTS names, expected 5 and observed 5 with equality true (harness.py:461). Each
  of the 5 tests then ran alone, exited 0 and logged its libtest `ok <name>` record
  (harness.py:475). The writer's own tests also passed: 6 / 4 / 6, plus doctests for rust.
  First grade: rust `cargo check --all-targets` built the suite against the candidate (exit 0);
  tide check-lib, check-test and acceptance metadata link all exited 0. grading-1 copies agree.
- Scaffold cannot pass (inference, not run): it is empty, and each suite references 1 / 2 / 5
  public items that only the candidate defines.

## Per-result standing

| Slot | Triple | First | Final | Stands | Token correction (out / thinking) |
| --- | --- | --- | --- | --- | --- |
| 000 | C1/rust/2 | pass | pass | yes | 419 -> 2072 / 160 |
| 001 | B6/rust/1 | pass | pass | yes | 522 -> 3112 / 327 |
| 002 | A9/tide/1 | pass | pass | yes | 24 -> 3443 / 207 |

The short sessions are real: Opus wrote each solution in one pass, tested once, and stopped.

## Minimal fix

- In coordinator.audit (coordinator.py:112-117), take `tokens` from the last `result`
  event's `usage`: input_tokens, cache_read_input_tokens, cache_creation_input_tokens,
  output_tokens, plus `output_tokens_details.thinking_tokens` if it should be recorded. Keep
  the per-message loop for `turns`, `models` and `peak_context`. A missing result event is
  already a `cli_error` fault (coordinator.py:331-338), so no fallback is needed.
- Test (harness_test.py, near line 775): give the audit two `assistant` events with the same
  message id and a snapshot usage, plus a `result` event with cumulative usage. Assert that
  tokens equal the result event's usage. The current fixture has a single event with
  input_tokens only, so it cannot catch this.
- No rerun needed: recompute the three trials' token fields from the retained writer.jsonl
  result events (summary-time correction or bead note), without editing the run directory.

## What would have caught it, and the effect on readiness

- standin.py emits no `assistant` usage and no `result` event: dry runs never tested tokens.
- The real-writer probe did exercise it, and it shows the same defect: probe.json audit
  output_tokens is 25, while the probe's `result` event reports 1205 (per-id snapshots
  [4,4],[16,16,16,16],[5,5]). A readiness check comparing the audit's token totals with the
  probe's result-event usage would have caught it.
- Other readiness evidence is unaffected: confinement, denial, staging, suite freeze, canaries
  and grading use no token field.

DONE
