# fx-ic2.7: C3 suite disputes (grader adjudication, protocol §6)

Date: 2026-11-15. Grader role, read-only. Inputs: the four classification
entries and bundles, sessions/<slot>-1/final-grade.json and final/source.rs,
tasks.md §C3, harness.py `structure()`, protocol.md §6 and §7.2.

## Common facts (all four records)

- Every acceptance test passed: all 14 result entries in each final-grade.json
  have code 0 (check, build, the writer's own tests, acceptance cases 1 to 4;
  case 4 is the expected capacity-0 panic). No test failed.
- The only failing item is the structure check (`"structure": false`).
- The C3 task text states the structure requirement for both arms in the
  same words: a literal "the source contains" clause naming one exact
  token, written in code formatting, in its Tide and Rust signature bullets.
- harness.py implements that clause as a plain substring test over the whole
  final source (comments included), the same test for both arms. It is the
  task's wording, applied exactly.
- Each final source names the channel function only in its import list and in
  a call written with an explicit type argument (turbofish), so the required
  token never occurs. Verified: zero occurrences in each
  sessions/<slot>-1/final/source.rs, which is byte-identical to the bundle's
  final-source.rs. In each, the first snapshot fails the same way.

## Per record

| Slot | Trial | What failed | Dispute | Final verdict |
| --- | --- | --- | --- | --- |
| 032 | C3/tide/2 | structure check only | not valid | FAIL stands |
| 044 | C3/tide/1 | structure check only | not valid | FAIL stands |
| 068 | C3/rust/1 | structure check only | not valid | FAIL stands |
| 116 | C3/rust/2 | structure check only | not valid | FAIL stands |

Reason, same for all four:

1. Not a suite dispute. §6 lets a suite lose a test only when a disputed
   result shows that the test checks something the task text leaves open.
   No acceptance test failed in any of the four trials, so there is no
   test to remove. The structure check is not a suite test; §6 governs it
   separately.
2. The structure failure stands. §6 says a fixed text search checks the
   requirement "as the task words it". The task words it as a literal
   containment of one exact token, and the search implements that wording
   exactly. The wording is not ambiguous: "the source contains" plus a
   code-formatted token names a substring, not a behaviour. The writers
   missed the stated text; a call without the type argument, or a comment
   with the token (which §6 says suffices), would have passed.
3. The classifiers' argument (that the check is a proxy for "uses bounded
   channels", which these programs do) is about the requirement's purpose.
   §6 rules out that reading: it checks text, not purpose. Accepting it would
   loosen a frozen check after the fact, which §6's freeze forbids
   ("No test is added or tightened", and a structure check is not among
   the things that may lose anything).

Classification follow-up (for the §7.4 record, not a verdict change):
068's class "toolchain defect (harness)" and 044's "TOOLCHAIN-DEFECT: yes"
do not hold. The harness applied the task's wording exactly, so neither
record shows a harness defect. Both read correctly as the class 032 and 116
already carry: an ordinary bug, a slip against a stated literal structure
requirement with no behaviour fault. I recommend the classification record
correct those two fields. All four SUITE-DISPUTE flags resolve to "not valid".

## Test removals and effect on other trials

- No test is removed from either arm's C3 suite.
- No structure check changes.
- So no other C3 trial changes verdict, in either arm. The failure mode hits
  both arms equally (two Tide, two Rust), so leaving it in place does not
  bias the arm comparison.

## Regrading

Not needed. Nothing changes: all four records keep their existing grades
(final FAIL on structure). The existing per-test results already settle
every point above, and no trial's grade inputs change.

DONE
