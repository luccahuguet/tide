#!/usr/bin/env bash
# E1 gate-slot preflight (fx-ic2.2 run procedure). Read-only except --scan, which writes
# RUN/store-before.json through the harness's own store-scan.
# Usage: preflight.sh RUN SLOT_MINUTES [--scan]
#   SLOT_MINUTES: the slot length from the formula; every window check covers now .. now+SLOT_MINUTES.
#   QUIET_LOG (env, optional): a file that receives eon-overseer's '<ts> eon-overseer: QUIET OVER' lines.
# Exit 0: every check passed (and the scan, with --scan). 1: a check failed. 2: usage.
set -u
RUN=${1:?usage: preflight.sh RUN SLOT_MINUTES [--scan]}
MIN=${2:?usage: preflight.sh RUN SLOT_MINUTES [--scan]}
SCAN=${3:-}
G=/home/lucca/pjs/lab/tide/.worktrees/fx-ic2
R=675c26e126df6db6090a94ddde6acc8004fe454d
O=/home/lucca/.cache/eon-agents/eon-overseer
fail=0
ok()  { echo "PASS $*"; }
bad() { echo "FAIL $*"; fail=1; }
now=$(date +%s); end=$(( now + MIN * 60 ))
echo "preflight $(date -u +%FT%TZ) slot ${MIN} min -> ends $(date -u -d @$end +%FT%TZ)"

# 1. Load.
l=$(cut -d' ' -f1 /proc/loadavg)
awk -v l="$l" 'BEGIN{exit !(l < 12)}' && ok "load $l < 12" || bad "load $l >= 12"

# 2. Quiet windows. heavy.sh's own hold, the standing 03:00Z/15:00Z slots (stop starting at
#    02:55Z/14:55Z) and every booking in eon-overseer's list must stay clear of now..end.
q=$(cat "$O/quiet-until" 2>/dev/null || echo 0); case "$q" in ''|*[!0-9]*) q=0;; esac
if [ "$now" -ge "$q" ]; then ok "quiet-until $(date -u -d @$q +%TZ) passed"
# An E1 window granted by eon-overseer sets quiet-until to its end; the batch runs with
# HEAVY_QUIET_EXEMPT=1. Accept the hold only when it is exactly that grant and the slot ends by it.
elif [ "${HEAVY_QUIET_EXEMPT:-0}" = 1 ] && [ "${E1_GRANT_UNTIL:-x}" = "$q" ] && [ "$end" -le "$q" ]; then
  ok "quiet-until $(date -u -d @$q +%TZ) is the E1 grant (HEAVY_QUIET_EXEMPT=1, slot ends by it)"
else bad "heavy.sh quiet hold until $(date -u -d @$q +%TZ)"; fi
day=$(date -u -d "$(date -u +%F)" +%s)
for s in $(( day - 86400 + 15*3600 )) $(( day + 3*3600 )) $(( day + 15*3600 )) $(( day + 86400 + 3*3600 )) $(( day + 86400 + 15*3600 )); do
  stop=$(( s - 300 )); over=$(( s + 90*60 ))
  if [ "$end" -gt "$stop" ] && [ "$now" -lt "$over" ]; then
    bad "slot overlaps standing quiet slot $(date -u -d @$s +%FT%H:%MZ) (stop starting at $(date -u -d @$stop +%H:%MZ))"
  elif [ "$now" -ge "$over" ] && [ "$now" -lt $(( s + 6*3600 )) ]; then
    # After a standing slot, resume only after its QUIET OVER line, when a log is named.
    if [ -n "${QUIET_LOG:-}" ]; then
      after=$(date -u -d @$stop +%FT%TZ)
      line=$(grep -E '^[0-9TZ:-]+ eon-overseer: QUIET OVER' "$QUIET_LOG" 2>/dev/null | awk -v a="$after" '$1 >= a' | tail -1)
      [ -n "$line" ] && ok "QUIET OVER after $(date -u -d @$s +%H:%MZ) slot: ${line%% *}" || bad "no QUIET OVER line after the $(date -u -d @$s +%H:%MZ) slot in $QUIET_LOG"
    else
      echo "NOTE QUIET_LOG unset: QUIET OVER after the $(date -u -d @$s +%H:%MZ) slot not checked (quiet-until checked above)"
    fi
  fi
done
while read -r bs bm agent pane st; do
  case "$bs" in ''|*[!0-9]*) continue;; esac
  be=$(( bs + bm * 60 ))
  if [ "$bs" -lt "$end" ] && [ "$be" -gt "$now" ]; then
    bad "booking $(date -u -d @$bs +%FT%H:%MZ) +${bm}m $agent ($st) overlaps the slot"
  fi
done < "$O/quiet-slots.txt"

# 3. Timers that prune target/, the Nix store or /usr must not fire inside the slot.
for t in "--user cargo-sweep.timer" "--user nix-profile-trim.timer" "--system apt-daily-upgrade.timer"; do
  set -- $t
  n=$(systemctl "$1" show -p NextElapseUSecRealtime --value "$2" 2>/dev/null)
  # A stopped timer reports an empty next elapse; `date -d ""` would read that as midnight.
  case "$n" in ''|n/a|0) ne=0;; *) ne=$(date -d "$n" +%s 2>/dev/null || echo 0);; esac
  if [ "$ne" -gt "$end" ]; then ok "$2 next $(date -u -d @$ne +%FT%TZ) after slot end"
  elif [ "$ne" = 0 ]; then echo "NOTE $2: no next elapse ('$n')"
  else bad "$2 due $(date -u -d @$ne +%FT%TZ), inside the slot"; fi
done

# 4. Gate worktree pinned and clean.
h=$(git -C "$G" rev-parse HEAD 2>/dev/null); d=$(git -C "$G" status --porcelain 2>/dev/null | wc -l)
[ "$h" = "$R" ] && [ "$d" = 0 ] && ok "gate worktree at R, clean" || bad "gate worktree HEAD $h dirty $d"

# 5. Run-dir prerequisites that 'run' also enforces: canaries for this boot/harness and a passing probe.
( cd "$G" && python3 -I - "$RUN" <<'EOF'
import json, sys
sys.path.insert(0, "trials/e1-checked")
from pathlib import Path
import gate_checks as g
run, key, bad = Path(sys.argv[1]), g.canary_key(), 0
for name in ["rust-canary.json", "tide-canary.json", "probe.json"]:
    try: rec = json.loads((run / name).read_text())
    except (OSError, ValueError): print(f"FAIL {name} missing"); bad = 1; continue
    good = rec.get("passed") is True and rec.get("key") == key
    print(("PASS " if good else "FAIL ") + f"{name} passed={rec.get('passed')} key_current={rec.get('key') == key}")
    bad |= not good
sys.exit(bad)
EOF
) || fail=1

# 6. Pre-run store scan (only with --scan, after every other check passed). One rerun on a lone
#    ENOENT under /nix/store/*.drv.chroot (a Nix build ending mid-scan); anything else is fatal.
if [ "$SCAN" = --scan ]; then
  if [ "$fail" = 0 ]; then
    for try in 1 2; do
      out=$(cd "$G" && python3 trials/e1-checked/coordinator.py store-scan "$RUN" </dev/null 2>&1); rc=$?
      echo "store-scan try $try exit $rc $(date -u +%TZ)${out:+: $out}"
      [ "$rc" = 0 ] && break
      if [ "$try" = 1 ] && [ "$(printf '%s\n' "$out" | grep -c .)" = 1 ] && \
         printf '%s' "$out" | grep -Eq "^E1 coordinator stopped: \[Errno 2\] No such file or directory: '/nix/store/[^/']+\.drv\.chroot(/[^']*)?'$"; then
        continue
      fi
      break
    done
    [ "$rc" = 0 ] && ok "store-scan" || bad "store-scan (fatal; do not start)"
  else
    echo "SKIP store-scan: an earlier check failed"
  fi
fi
[ "$fail" = 0 ] && echo "PREFLIGHT PASS" || echo "PREFLIGHT FAIL"
exit "$fail"
